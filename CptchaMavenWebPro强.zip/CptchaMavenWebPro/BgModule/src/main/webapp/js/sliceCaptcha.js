/*
* 这是一个自执行的匿名函数表达式（Immediately Invoked Function Expression，IIFE），通常用于创建一个独立的作用域，防止变量污染全局作用域。
* 该写法中，(function () {})() 的意思是：
* 外部的括号 () 将函数声明转换为一个表达式，这样可以在后面立即调用它。
* 内部的括号 function () {} 定义了一个匿名函数，该函数不具有名称。
* 最后的 () 立即调用了这个匿名函数。
* 这种写法通常用于隔离代码，确保内部声明的变量不会污染全局作用域。这在JavaScript中非常有用，因为JavaScript中的变量作用域是函数级别的，而不是块级别的（在ES6之前）。
* 通过使用IIFE，你可以在函数内部声明的变量在函数执行后会被销毁，不会影响全局作用域。
*/

/*
* `requestData`、`sendData`、`ready` 和 `checkResult` 这几个方法的作用以及外部何时调用它们，

1. `requestData` 方法：
   - 作用：用于请求初始化数据，如验证码背景图片、滑块位置等。
   - 何时调用：通常在初始化验证码时或在用户请求刷新验证码时调用。
   - 示例说明：

   ```javascript
   // 示例：使用 jQuery 的 AJAX 请求初始化数据
   requestData: function(callback) {
       $.ajax({
           url: 'url_to_get_captcha_data',
           success: function(data) {
               callback(data);
           },
           error: function() {
               // 处理错误情况
           }
       });
   }
   ```

2. `sendData` 方法：
   - 作用：用于发送用户的滑动数据以进行服务器端验证。
   - 何时调用：通常在用户完成滑动操作并准备将验证数据发送到服务器时调用。
   - 示例说明：

   ```javascript
   // 示例：在用户完成滑动操作后调用 sendData 发送验证数据
   captcha.sendData(data, function(serverResponse) {
       // 处理服务器响应结果，例如验证成功或失败
   });
   ```

3. `ready` 方法：
   - 作用：作为验证码准备就绪后的回调函数，用于在验证码可显示和操作时执行初始化操作。
   - 何时调用：通常在验证码准备好并可显示时自动触发，无需外部手动调用。
   - 示例说明：

   ```javascript
   // 示例：使用 ready 回调来显示验证码
   ready: function() {
       // 验证码已准备好，可以执行相应操作，例如显示验证码
       captcha.show(); // show 是一个假设的显示验证码的方法
   }
   ```

4. `checkResult` 方法：
   - 作用：用于处理用户验证的结果，通常在验证完成后，根据结果执行相应的操作。
   - 何时调用：通常在服务器返回验证结果后被调用，用于处理验证成功或失败的情况。
   - 示例说明：

   ```javascript
   // 示例：在 sendData 的回调中调用 checkResult 处理验证结果
   captcha.sendData(data, function(serverResponse) {
       // 处理服务器响应结果
       captcha.checkResult(serverResponse); // 处理验证结果
   });
   ```

* 这些方法用于不同阶段的验证码验证过程，并可以根据需要自定义其行为。
* `requestData` 用于初始化数据，
* `sendData` 用于发送验证数据，
* `ready` 在验证码准备就绪时执行初始化操作，
* `checkResult` 处理验证结果。
* */
/*
* 这段代码是一个JavaScript构造函数，它定义了一个名为`ICBCSliceCaptcha`的对象，用于创建滑动验证码组件。让我逐行解释它：
* `var ICBCSliceCaptcha = function (captchaBoxId, options) {`：定义了一个名为`ICBCSliceCaptcha`的构造函数，
* 它接受两个参数：`captchaBoxId`（验证码容器的DOM元素的ID）和`options`（一个包含各种配置选项的对象）。
* `this.opts = { ... }`：初始化了`opts`属性，该属性包含了组件的配置选项和默认值。
* `this.captchaBoxId = captchaBoxId;`：将传入的`captchaBoxId`参数存储在`this.captchaBoxId`属性中，以便后续使用。
* `this.captchaDOM = { captchaBox: null }`：初始化了`captchaDOM`属性，用于存储验证码相关的DOM元素，初始值为`null`。
* `this.deviceType = 'Windows';`：设置了`deviceType`属性的初始值为字符串`'Windows'`，表示设备类型为Windows。
* `this.imageObject = null;`：初始化了`imageObject`属性，该属性用于存储验证码背景图片对象，初始值为`null`。
* `this.userIsCan = true;`：初始化了`userIsCan`属性，表示用户是否可以操作，默认为`true`。
* `this.errorNum = 0;`：初始化了`errorNum`属性，用于记录验证错误的次数，默认为`0`。
* `this.keys = '';`：初始化了`keys`属性，用于存储密钥信息，初始值为空字符串。
* `this.startTime = new Date().getTime();`：初始化了`startTime`属性，用于记录组件启动的时间戳。
* `this.requestDataDone = false;`：初始化了`requestDataDone`属性，表示是否完成了初始化数据的请求，默认为`false`。
* `this.intervalDone = true;`：初始化了`intervalDone`属性，表示是否达到了等待间隔时间，默认为`true`。
* `this.picSort = null;`：初始化了`picSort`属性，用于存储图片排序信息，初始值为`null`。
* `this.lifeCycleA` 和 `this.lifeCycleB`：初始化了`lifeCycleA`和`lifeCycleB`属性，用于记录验证码的生命周期。
* `if (!window.console) { ... }`：这是一段用于检测浏览器是否支持`console`对象的代码。如果不支持，会创建一个空的`console`对象，以避免在不支持`console`的浏览器中出现错误。
* `for (var k in options) { ... }`：遍历传入的`options`对象，将其中的配置选项覆盖默认的配置选项。
* `this.initData();`：调用构造函数的`initData`方法，用于初始化验证码数据。
* 这段代码的主要作用是创建一个滑动验证码组件的构造函数，并初始化各种属性和配置选项。
* 这个构造函数可以用于创建滑动验证码的实例，通过传递不同的配置选项和容器ID来自定义验证码的外观和行为。
* */

/*
* 这个构造函数原型中的方法主要用于实现`ICBCSliceCaptcha`对象的各种功能。下面是每个方法的作用和每行代码的含义的解释：

1. `getVersion` 方法：
   - 作用：返回当前验证码组件的版本号。
   - 代码含义：简单地返回字符串 `'1.2.0'` 作为版本号。

2. `initMouseTrack` 方法：
   - 作用：初始化鼠标轨迹信息。
   - 代码含义：调用外部的 `mouseTrack` 对象的 `initMouseTrack` 方法来初始化鼠标轨迹信息。如果 `mouseTrack` 未定义，则会输出错误信息。

3. `clearMouseTrack` 方法：
   - 作用：清除鼠标轨迹信息。
   - 代码含义：调用外部的 `mouseTrack` 对象的 `clearTrackInfo` 方法来清除鼠标轨迹信息。如果 `mouseTrack` 未定义，则会输出错误信息。

4. `getMouseTrack` 方法：
   - 作用：获取鼠标轨迹信息。
   - 代码含义：调用外部的 `mouseTrack` 对象的 `mouseTrackInfo` 方法来获取鼠标轨迹信息。如果 `mouseTrack` 未定义，则会输出错误信息。

5. `extend` 方法：
   - 作用：将一个对象的属性扩展到另一个对象中。
   - 代码含义：接收两个参数，`target` 表示目标对象，`source` 表示源对象。遍历源对象的属性，如果属性不为空且目标对象中不存在相同属性，则将源对象的属性复制到目标对象中。

6. `createKey` 方法：
   - 作用：创建加密密钥。
   - 代码含义：接收两个参数，`key1` 和 `key2`，将它们拼接在一起。然后使用 SHA-256 哈希算法对拼接后的密钥进行哈希，取哈希值的一部分作为最终密钥，并返回。如果出现异常，会输出错误信息并返回空字符串。

7. `DES3encrypt` 方法：
   - 作用：使用3DES算法对数据进行加密。
   - 代码含义：接收两个参数，`key` 表示密钥，`str` 表示要加密的数据。使用3DES算法对数据进行加密，并返回加密后的结果。如果出现异常，会输出错误信息并返回空字符串。

1. `DES3decrypt` 方法：
   - 作用：使用3DES算法对数据进行解密。
   - 代码含义：
     - 定义变量 `des3en` 用于存储解密结果。
     - 尝试解密给定的密文 `str`，使用传入的密钥 `key`。如果解密过程中出现异常，会记录错误信息。
     - 返回解密后的结果 `des3en`。

2. `getGmFaKey` 方法：
   - 作用：生成GM/FA加密算法的密钥。
   - 代码含义：
     - 根据传入的 `key1` 和 `key2`，将它们拼接成一个密钥。
     - 使用 SHA-256 哈希算法对拼接后的密钥进行哈希，并返回前16位（32字符）的结果，以小写字母表示。

3. `createAES_SM4Key` 方法：
   - 作用：生成AES和SM4加密算法的密钥。
   - 代码含义：
     - 调用 `createKey` 方法，传入客户端ID `this.opts.clientID` 来生成一个密钥。
     - 返回生成的密钥的前16位（32字符），表示AES和SM4密钥。

4. `getDeviceType` 方法：
   - 作用：获取用户设备类型。
   - 代码含义：
     - 使用 `navigator.platform` 属性获取用户设备平台信息。
     - 根据平台信息判断用户设备类型（例如 Windows、Android、iPhone、Linux 等）并存储在 `this.deviceType` 中。

5. `isMobileDevice` 方法：
   - 作用：检查用户设备是否是移动设备。
   - 代码含义：
     - 使用 `navigator.platform` 属性获取用户设备平台信息。
     - 根据平台信息判断设备是否是移动设备（例如 iPhone 或 Android），如果是返回 `true`，否则返回 `false`。

6. `checkBrowser` 方法：
   - 作用：检查浏览器类型和版本。
   - 代码含义：
     - 获取用户的浏览器用户代理字符串（User Agent）并转换为小写。
     - 如果用户使用的是 Internet Explorer 且版本小于或等于8.0，将 `this.opts.useCanvas` 设置为 `false`，表示不使用Canvas。

7. `destroy` 方法：
   - 作用：销毁验证码组件。
   - 代码含义：
     - 清空验证码组件的HTML内容，通过 `this.captchaDOM.captchaBox` 获取验证码容器的引用。
     - 遍历对象的属性，将函数类型属性设置为空函数，将对象类型属性设置为空对象。这是一种销毁对象的方式，以防止内存泄漏。

1. `getEquipmentFinger` 方法：
   - 作用：获取设备指纹信息，包括浏览器和系统信息。
   - 代码含义：
     - 创建两个空对象 `NavigatorFinger` 和 `WindowFinger` 用于存储浏览器和系统信息。
     - 尝试获取浏览器指纹信息，如果 `navigatorFinger` 存在，则调用其 `get` 方法获取信息，否则记录错误信息。
     - 尝试获取系统指纹信息，如果 `windowFinger` 存在，则调用其 `get` 方法获取信息，否则记录错误信息。
     - 使用 `extend` 方法将浏览器和系统信息合并到 `WindowFinger` 对象中。
     - 返回合并后的 `WindowFinger` 对象，其中包含浏览器和系统信息。

2. `createCaptchaBox` 方法：
   - 作用：创建并初始化验证码的 HTML 结构。
   - 代码含义：
     - 创建一个变量 `html`，用于存储验证码的 HTML 结构。
     - 构建验证码的各个组件，包括背景、加载提示、滑动条、拖动按钮等。
     - 通过 `innerHTML` 属性将构建好的 HTML 结构设置到验证码容器 `captchaBox` 中。
     - 获取各个 HTML 元素的引用并存储在 `this.captchaDOM` 对象中，方便后续操作。
     - 设置各个元素的样式和属性，包括宽度、高度、背景颜色、圆角等。
     - 添加鼠标事件处理，禁止浏览器对图片的默认拖拽效果。
     - 最后，设置标题的文本内容、字体大小和颜色。

这个方法主要用于在指定的验证码容器内创建验证码的各个组件，并对这些组件进行初始化设置。它生成了验证码的外观和用户交互元素，以及一些样式和事件处理，以确保验证码正常显示和操作。

3. `showLoading` 方法：
   - 作用：控制加载提示的显示和隐藏。
   - 代码含义：
     - 获取加载提示元素和验证码画布元素的引用。
     - 如果 `isShow` 为真，显示加载提示，隐藏验证码画布；否则，隐藏加载提示，显示验证码画布。

4. `setLoadMessage` 方法：
   - 作用：设置加载提示信息的内容。
   - 代码含义：
     - 将加载提示信息的内容设置为传入的 `msg` 参数。

5. `setMsgShowText` 方法：
   - 作用：设置滑动条上显示的消息文本。
   - 代码含义：
     - 将滑动条上显示的文本内容设置为传入的 `msg` 参数。

6. `setFloatMessage` 方法：
   - 作用：设置浮动条上显示的消息文本。
   - 代码含义：
     - 将浮动条上显示的文本内容设置为传入的 `msg` 参数。

7. `setUserEvent` 方法：
   - 作用：设置用户事件处理程序，包括鼠标事件和触摸事件。
   - 代码含义：
     - 创建鼠标按下、鼠标移动、鼠标释放、刷新按钮点击的事件处理函数。
     - 使用 `addEventListener` 或 `attachEvent` 来绑定事件处理函数，具体根据浏览器支持情况来选择。
     - 设置 `this.userIsCan` 为 `false`，表示用户不可操作，用于控制用户是否可以滑动验证码。

8. `setUserCanOperation` 方法：
   - 作用：设置用户是否可以操作滑动验证码。
   - 代码含义：
     - 根据传入的 `isCan` 参数来决定是否显示刷新按钮。
     - 将 `this.userIsCan` 属性设置为传入的 `isCan` 值，表示用户是否可以操作。

9. `loadBGImage` 方法：
   - 作用：加载背景图片。
   - 代码含义：
     - 创建一个新的 `Image` 对象并设置其 `src` 属性为传入的 `imgurl`。
     - 注册图片加载完成时的回调函数，一旦图片加载完成，将调用 `drawCaptcha_NoCanvas` 方法绘制验证码。
     - 存储图片对象为 `this.imageObject`。

10. `refreshMethod` 方法：
    - 作用：刷新验证码。
    - 代码含义：
      - 首先检查是否提供了 `requestData` 函数，如果没有则记录错误并返回。
      - 设置加载状态，禁用用户操作。
      - 设置加载提示信息。
      - 构建请求参数 `paramObj`，其中包括验证码类型、宽高等信息。
      - 发送请求，获取新的验证码参数。
      - 解析服务器返回的参数，包括密钥等信息。
      - 调用 `loadBGImage` 方法加载新的背景图片。
      - 重置验证码状态，设置 `requestDataDone` 为 `true`，如果间隔时间已到，则设置用户可操作。
      - 最后，调用 `ready` 函数（如果提供）。

11. `analysisParam` 方法：
    - 作用：解析从服务器获取的参数。
    - 代码含义：
      - 解析服务器返回的 JSON 数据。
      - 根据加密类型（`crypto_kind`）解密数据。
      - 解析解密后的 JSON 数据，包括密钥、图片 URL、切片 URL 等信息。
      - 存储解析后的参数供后续使用。

这些方法主要负责控制验证码的加载、刷新、事件处理和用户交互等功能。它们协同工作以确保验证码能够正常显示和用户能够正确地完成验证。

以下是构造函数中其他原型方法的具体含义解释：

1. `hideImg` 方法：
   - 作用：隐藏验证码切片图片。
   - 代码含义：将验证码切片图片的样式的 `display` 设置为 `'none'`，从视图中隐藏切片图片。

2. `showImg` 方法：
   - 作用：显示验证码切片图片。
   - 代码含义：将验证码切片图片的样式的 `display` 设置为 `'block'`，在视图中显示切片图片。

3. `isArray` 方法：
   - 作用：判断一个对象是否为数组。
   - 代码含义：使用 `Object.prototype.toString` 方法来检查传入的参数 `obj` 是否是数组类型，返回布尔值。

4. `createCanvas` 方法：
   - 作用：创建一个指定宽度和高度的 HTML5 Canvas 元素。
   - 代码含义：创建一个 `<canvas>` 元素，设置其宽度和高度，并返回该 Canvas 元素。

5. `randomNum` 方法：
   - 作用：生成一个指定范围内的随机整数。
   - 代码含义：根据传入的 `min` 和 `max` 参数，计算出范围 `rangeNum`，然后使用 `Math.random()` 生成一个在范围内的随机整数，并返回。

6. `createSlice_Canvas` 方法：
   - 作用：创建一个验证码切片 Canvas 元素，并在其中绘制切片。
   - 代码含义：
     - 创建一个源 Canvas 元素，并在其中绘制完整验证码图片。
     - 设置源 Canvas 的合成模式为 `destination-in`，用于后续的裁剪。
     - 创建一个目标 Canvas 元素，并使用 `fillClip` 方法填充指定的形状。
     - 将目标 Canvas 绘制到源 Canvas 上，实现裁剪效果。
     - 获取裁剪后的图像数据，并将其绘制到验证码切片 Canvas 元素上。
     - 返回切片 Canvas 元素。

7. `updateSlice` 方法：
   - 作用：更新验证码切片的显示。
   - 代码含义：
     - 更新验证码切片的位置和样式。
     - 根据是否使用 Canvas，设置切片 Canvas 的背景图片或者直接修改 `src` 属性。
     - 设置切片 Canvas 的位置。

8. `drawCaptchaCutting` 方法：
   - 作用：根据切片信息绘制验证码。
   - 代码含义：
     - 创建一个源 Canvas 元素，并在其中绘制完整验证码图片。
     - 根据切片信息，将完整验证码图片的一部分绘制到目标位置。
     - 将绘制后的图像数据转换为 Data URL，并将其设置为验证码的 `src` 属性。

9. `drawCaptcha_NoCanvas` 方法：
   - 作用：绘制验证码（无 Canvas 版本）。
   - 代码含义：
     - 根据传入的图片对象，判断是否需要进行切片。
     - 如果需要切片，创建一个新的图片对象，加载完整验证码图片，并在加载完成后调用 `drawCaptchaCutting` 方法。
     - 否则，直接设置验证码的 `src` 为完整验证码图片的 URL。
     - 控制验证码和切片的显示和加载状态。

10. `setResultStatus` 方法：
    - 作用：设置验证码验证结果的状态。
    - 代码含义：
      - 根据传入的验证结果 `res`，设置相应的消息文本、浮动消息文本和样式类。
      - 如果验证结果为失败或禁止，设置定时器显示等待消息。
      - 最后，根据定时器的间隔时间，恢复用户操作权限，并重置滑动条。

以下是构造函数原型方法的具体含义解释：

1. `resetTrack` 方法：
   - 作用：重置滑块轨迹的样式。
   - 代码含义：将滑块轨迹元素的文本颜色恢复为黑色，边框颜色恢复为默认颜色，并将结果显示元素的类名重置。

2. `setSlicePos` 方法：
   - 作用：设置滑块和切片的位置。
   - 代码含义：根据传入的 `centerX` 参数，计算并设置滑块和切片的水平位置。

3. `reset` 方法：
   - 作用：重置验证码滑块的状态。
   - 代码含义：清除鼠标轨迹并将滑块位置重置为初始位置。

4. `moveStart` 方法：
   - 作用：处理鼠标按下或触摸事件的开始。
   - 代码含义：记录事件开始的时间，设置事件标志以指示事件已开始，获取当前鼠标位置并存储在 `eventinfo.currentX` 中。

5. `move` 方法：
   - 作用：处理鼠标移动事件。
   - 代码含义：如果事件已开始（即 `eventinfo.flag` 为真），则计算鼠标移动的距离，更新滑块和切片的位置，并确保滑块不会超出指定范围。

6. `moveEnd` 方法：
   - 作用：处理鼠标释放或触摸结束事件。
   - 代码含义：如果事件已开始，将事件标志设置为假，获取滑块的最终位置，计算用户完成滑动所需的时间，并构建包含验证数据的对象。然后将该对象进行加密（根据 `crypto_kind` 设置），并使用 `sendData` 方法发送到服务器进行验证。根据验证结果，更新消息和浮动消息，如果验证失败，根据错误次数判断是否需要刷新验证码。

7. `getStyle` 方法：
   - 作用：获取元素的指定 CSS 样式属性的值。
   - 代码含义：根据浏览器支持情况，获取指定元素的指定样式属性的值。

8. `setEleCannotselect` 方法：
   - 作用：禁止元素被选中。
   - 代码含义：根据浏览器支持情况，通过设置元素的 `onselectstart` 属性来禁止元素被选中。

9. `getWebDriver` 方法：
   - 作用：检测当前页面是否运行在 WebDriver 测试环境下。
   - 代码含义：尝试获取 `window.navigator.webdriver` 属性，如果存在则说明当前页面运行在 WebDriver 测试环境下，返回 `true`，否则返回 `false`。
* */
;(function () {
    "use strict";
    /*
    * 这是构造函数，通常用于创建对象实例。
    * 当你使用new ICBCSliceCaptcha(...)来创建一个实例时，构造函数会被调用，并执行一些初始化工作。
    * */
    var ICBCSliceCaptcha = function (captchaBoxId, options) {
        this.opts = {
            mode: 'fixed',//弹出式pop，固定fixed
            imageUrl: 'bgimg/demo.jpeg',//背景图片URL 从服务器获取
            sliceImageUrl: 'bgimg/demo.jpeg',//滑块图片URL 从服务器获取(不使用Canvas时)
            imageType: 'stream',//path路径方式，stream流方式
            bgWidth: 300, //验证码背景图片的宽，宽度如果是% 是相对于手机屏幕宽
            bgHeight: 200,//验证码背景图片的高，高度如果是% 是相对于宽度
            barHeight: 24,//滑动条的高度
            dragWidth: 34, //拖拽BTN的宽
            dragHeight: 24,//拖拽BTN的高
            dragBorderR: 12,//拖拽BTN的圆角半径
            dragColor: '#1296db',//拖拽BTN的颜色
            // trackHeight: 24,//拖拽轨道的高
            bgMarginW: 18,//图片边缘留白的宽度
            bgMarginBottom: 4,
            barBgDistance: 2,//滑动条和验证框的距离
            bgColor: /*'#e4e4e4'*/'#ffffff',//背景颜色
            trackColor: '#e4e4e4',
            captchaTitle: '滑动验证码',
            captchaTitleSize: 20,
            captchaTitleColor: '#000000',
            message: {
                loading: '加载中...',
                checking: '正在验证，请稍等...',
                tip: '按住滑块，拖动完成拼图',//提示信息
                success: '验证成功',
                fail: '位置不正确',
                forbidden: '操作异常',//怪兽吃掉了你的方块
                wait: '请稍后重试',
                finish: '秒完成',
                error: '网络错误'
            },
            clientID: null,//用于加密
            useCanvas: false,//是否使用Canvas
            cw: 60,//裁剪滑块的大小
            ch: 60,
            cRadius: 8,//裁剪滑块 耳朵的半径
            cTransparency: 0.8,//裁剪区域的透明度 0~1，值越大区域越黑
            useMixBlock: true,//是否使用混淆裁剪块
            allowSameRow: false,//是否允许混淆块与裁剪块在同一行
            cMixTransparency: 0.6,//混淆裁剪块的透明度 0~1，值越大区域越黑
            dragClip: true,//是否可以拖拽 裁剪滑块
            posx: 0,//抠图位置 从服务器获取
            posy: 0,
            blockStyle: [-1, 0, 0, 1],//滑块的样式，-1表示内凹 1表示外凸 0或其他表示不画耳朵，传空数组表示随机
            padding: 0,//滑块初始位置 距离左边缘的偏移
            needAgainNum: 2,//用户验证失败几次，需要重新拉取数据
            //useDES3: false,//是否使用3DES加密
            crypto_kind: 0,
            useDeviceInfo: true,//是否获取设备信息
            interval: 5,//操作错误时等待的时间 单位s
            requestData: null,//请求初始化数据的函数
            sendData: null,//发送用户滑动数据的函数
            ready: function () {
            },//验证码准备好了的回调函数
            checkResult: function (res) {
            },//用户验证结果的回调函数
            // success: function(){},//用户验证通过的回调函数
            // fail: function(){},//用户验证失败的回调函数
            eventinfo: {
                flag: false,
                currentX: 0
            }
        }
        this.captchaBoxId = captchaBoxId;
        this.captchaDOM = {
            captchaBox: null
        }
        this.deviceType = 'Windows';
        this.imageObject = null;
        this.userIsCan = true;//用户是否可以操作，比如当加载中等时机 不能操作
        this.errorNum = 0;//验证错误的次数
        this.keys = '';
        this.startTime = new Date().getTime();
        this.requestDataDone = false;//并且requestData()完成或不需要调requestData时 置为true
        this.intervalDone = true;//当opts.interval到期时 置为true
        this.picSort = null;
        this.lifeCycleA = new Date().getTime();
        this.lifeCycleB = new Date().getTime();
        this.sr = '';
        this.publicKeyExponent = '';
        this.publicKeyModulus = '';
        //对应ie6 ie7浏览器不支持 window.console
        if (!window.console) {
            window.console = {
                log: function () {
                },
                warn: function () {
                },
                error: function () {
                },
                info: function () {
                }
            };
        }

        for (var k in options) {
            if (this.opts.hasOwnProperty(k)) {
                this.opts[k] = options[k];
            }
        }
        this.initData();
    }
    /*
    * 在构造函数的原型上定义方法意味着这些方法将被所有ICBCSliceCaptcha对象共享，而不会在每个实例中重复创建。
    * 节省内存：不需要为每个对象实例创建一个独立的方法副本。
    * 代码复用：所有实例都可以共享相同的方法，提高了代码的重用性。
    * 使用方法：
    * 你可以通过创建ICBCSliceCaptcha对象实例来使用原型中定义的方法，例如：
    * var options = { 配置选项}
    * var captcha = new ICBCSliceCaptcha('captchaBox', options);
    * var version = captcha.getVersion();
    * console.log(version); // 输出 '1.2.0'
    */
    ICBCSliceCaptcha.prototype = {
        getVersion: function () {
            return '1.2.0';
        },
        initData: function () {
            //检查参数数据有效性
            if (typeof this.captchaBoxId !== 'string') {
                console.error("captchaBoxId is must be string");
                return;
            }
            this.captchaDOM.captchaBox = document.getElementById(this.captchaBoxId);
            if (!this.captchaDOM.captchaBox) {
                console.error("captchaBoxId is error");
                return;
            }
            if (!this.opts.requestData) {
                console.error("requestData is must");
                return;
            }
            if (!this.opts.sendData) {
                console.error("sendData is must");
                return;
            }
            if (!this.opts.clientID) {
                console.error('clientID is must');
                return "";
            }
            if (typeof this.opts.bgWidth == 'string') {
                if (this.opts.bgWidth.indexOf('%') != -1) {
                    if (!this.isMobileDevice()) {
                        console.error('fail width is % in pc');
                        return;
                    }
                    // var screanW = document.documentElement.clientWidth || document.body.clientWidth;
                    var screanW = window.screen.width;//在webview中，如果预加载页面，webview没有显示，此时文档宽为0
                    screanW = screanW / window.devicePixelRatio;
                    this.opts.bgWidth = parseInt(this.opts.bgWidth) / 100 * screanW;
                } else {
                    this.opts.bgWidth = parseInt(this.opts.bgWidth);
                }
            }
            if (typeof this.opts.bgHeight == 'string') {
                if (this.opts.bgHeight.indexOf('%') != -1) {
                    this.opts.bgHeight = parseInt(this.opts.bgHeight) / 100 * this.opts.bgWidth;
                } else {
                    this.opts.bgHeight = parseInt(this.opts.bgHeight);
                }
            }
            // this.setBlockStyle(this.opts.blockStyle);
            this.getDeviceType();  //设备平台windows,Linux,mobile
            this.checkBrowser();  //查看IE浏览器版本

            this.createCaptchaBox(this.captchaDOM.captchaBox);
            this.showLoading(true);
            this.setUserEvent();

            this.initMouseTrack();

            this.refreshMethod();

            if (this.opts.mode === 'pop' && !this.isMobileDevice()) {
                var _this = this;
                // var dragbar = document.getElementById('slice-dragbarID');
                // dragbar.addEventListener('mouseover', function(e){
                // 	_this.showImg();
                // });
                // dragbar.addEventListener('mouseout', function(e){
                // 	_this.hideImg();
                // });
                // this.captchaDOM.captchaBox.addEventListener('mouseover', function(e){
                // 	_this.showImg();
                // });
                // this.captchaDOM.captchaBox.addEventListener('mouseout', function(e){
                // 	_this.hideImg();
                // });
                this.captchaDOM.captchaBox.onmouseover = function (e) {
                    _this.showImg();
                };
                this.captchaDOM.captchaBox.onmouseout = function (e) {
                    _this.hideImg();
                };
            }
            if (this.opts.mode === 'pop' && !this.isMobileDevice()) {
                // this.htmlDoms.out_panel.css({'display': 'none', 'position': 'absolute', 'bottom': '42px'});
                this.captchaDOM.slicebody.style.display = 'none';
                this.captchaDOM.slicebody.style.position = 'absolute';
                this.captchaDOM.slicebody.style.bottom = this.opts.barHeight + this.opts.barBgDistance + 'px';
            } else {
                // this.htmlDoms.out_panel.css({'position': 'relative'});
                this.captchaDOM.slicebody.style.position = 'relative';
            }
        },
        // setClientID: function(id) {
        // 	this.opts.clientID = id;
        // },
        initMouseTrack: function () {
            try {
                if (mouseTrack) {
                    mouseTrack.initMouseTrack(this.captchaBoxId);
                } else {
                    console.error('mouseTrack undefined');
                }
            } catch (error) {
                console.error('mouseTrack.initMouseTrack error');
                console.log(error);
            }
        },
        clearMouseTrack: function () {
            try {
                if (mouseTrack) {
                    mouseTrack.clearTrackInfo();
                } else {
                    console.error('mouseTrack undefined');
                }
            } catch (error) {
                console.error('mouseTrack.clearTrackInfo error');
                console.log(error);
            }
        },
        getMouseTrack: function () {
            try {
                if (mouseTrack) {
                    return mouseTrack.mouseTrackInfo();
                } else {
                    console.error('mouseTrack undefined');
                }
            } catch (error) {
                console.error('mouseTrack.mouseTrackInfo error');
                console.log(error);
            }
        },
        extend: function (target, source) {
            if (source == null) {
                return target
            }
            for (var k in source) {
                if (source[k] != null && target[k] !== source[k]) {
                    target[k] = source[k];
                }
            }
            return target
        },
        createKey: function (key1, key2) {
            var key = key1;
            if (key2) key += key2;
            try {
                key = sha256_digest(key);
                key = key.substr(4, key.length - 8);
                //key = "1234567890abcdef12345678";
                //console.log("key = " + key);
                if(key.length > 24){
                    return key.substring(0, 24)
                }{
                    return key;
                }
                //return key;
            } catch (error) {
                console.error('init Key error');
                console.log(error);
                return "";
            }
        },
        DES3encrypt: function (key, str) {
            var des3en = "";
            // var base64en = "";
            try {
                des3en = DES3.encrypt(key, str);
            } catch (error) {
                console.error('D3et error');
                console.log(error);
                return "";
            }
            // try {
            // 	base64en = BASE64.encoder(des3en);
            // } catch (error) {
            // 	console.error('Base64转换时出现异常，详细信息如下：');
            // 	console.log(error);
            // }
            return des3en;
        },
        DES3decrypt: function (key, str) {
            var des3en = "";
            // var base64en = "";
            // try {
            // 	base64en = BASE64.decoder(str)
            // } catch (error) {
            // 	console.error('Base64转换时出现异常，详细信息如下：');
            // 	console.log(error);
            // 	return "";
            // }
            try {
                des3en = DES3.decrypt(key, str);
            } catch (error) {
                console.error('D3dt error');
                console.log(error);
            }
            return des3en;
        },
        getGmFaKey: function (key1, key2) {
        	var key = key1;
        	if (key2) key += key2;
            var i = sha256_digest(key);
            //console.log("sm4_key = " + i.substring(0, 16));
            return i.substring(0, 16).toLowerCase();
        },
        createAES_SM4Key: function () {
            var str = this.createKey(this.opts.clientID);
            //console.log("aes_sm4 key str = " + str);
            var str_aes_sm4 = str.substring(0, 16);
            //console.log("aes_sm4 key str_aes_sm4 = " + str_aes_sm4);
            return str_aes_sm4;
        },
        getDeviceType: function () {
            var platform = navigator.platform;
            if (platform.indexOf('Win') >= 0) {
                this.deviceType = 'Windows';
            } else if (platform.indexOf('Linux') >= 0 && platform.indexOf('arm') >= 0) {
                this.deviceType = 'Android';
            } else if (platform.indexOf('Linux') >= 0){
            	this.deviceType = 'Linux';
            } else if (platform.indexOf('iPhone') >= 0) {
                this.deviceType = 'iPhone';
            } else {
                this.deviceType = 'Unknown';
            }
        },
        isMobileDevice: function () {
            var platform = navigator.platform;
            if(platform.indexOf('iPhone') >= 0){
            	return true;
            }
            if (platform.indexOf('Linux') >= 0 && platform.indexOf('arm') >= 0) {
                return true;
            } else {
                return false;
            }
        },
        checkBrowser: function () {
            var DEFAULT_VERSION = 8.0;
            var ua = navigator.userAgent.toLowerCase();
            if (ua.indexOf("msie") > -1) {
                var safariVersion = ua.match(/msie ([\d.]+)/)[1];
                if (safariVersion <= DEFAULT_VERSION) {
                    this.opts.useCanvas = false;
                }
                ;
            }
        },
        destroy: function () {
            this.captchaDOM.captchaBox.innerHTML = '';
            for (var k in this) {
                if (typeof this[k] == 'function') {
                    this[k] = function () {
                    };
                } else if (typeof this[k] == 'object') {
                    this[k] = {};
                }
            }
        },
        getEquipmentFinger: function () {
            var NavigatorFinger = {};
            var WindowFinger = {};
            try {
                if (navigatorFinger) {
                    NavigatorFinger = navigatorFinger.get();
                } else {
                    console.error('nf undefined');
                }
            } catch (error) {
                console.error('nf.get error');
                console.log(error);
            }
            try {
                if (windowFinger) {
                    WindowFinger = windowFinger.get();
                } else {
                    console.error('wf undefined');
                }
            } catch (error) {
                console.error('wf.get error');
                console.log(error);
            }
            this.extend(WindowFinger, NavigatorFinger);
            return WindowFinger;
        },
        createCaptchaBox: function (captchaBox) {
            var html = "";
            html += '<div id="slice-body" class="slice-border-radius" style="background-color: rgb(229, 229, 229); position: relative; height: 240px">';//width: 300px; height: 200px;
            html += '  <div id="slice-loading" style="width: 100%; height: 100%; display: none;">';
            html += '    <div style="height: 50%;"></div><div id="slice-loadingMsg" class="slice-noselect" style="text-align: center;"></div>';
            html += '  </div>';
            html += '  <div id="slice-canvas-panel" style="width: 100%; height: 100%; display: block; position: relative;">';
            html += '    <div id="slice-title" style="z-index: 3;  position: absolute;"></div>';
            html += '    <div id="slice-refresh" style="z-index: 3; display: block; float: right;"></div>';
            html += '    <div id="slice-close" style="z-index: 3; display: block;  float: right;"></div>';
            html += '    <div id="slice-canvasbox" style="width: 100%; height: 100%;">';
            html += '      <canvas id="slice-canvas" width="100%" height="100%"></canvas>';// width="300" height="200"
            // html += '      <div id="slice-canvas" class="slice-background-size" ';
            // html += '        style="width: 100%; height: 100%; background-image: url(&quot;' + this.opts.imageUrl + '&quot;); background-size: 100% 100%;"> ';
            // html += '      </div>'
            html += '    </div>';
            html += '    <div id="slice-clipblock" style="left: 10px; top: 57px; position: absolute;">';
            html += '      <canvas id="slice-clipcanvas" class="drag-slider" width="50" height="50"></canvas>';
            // html += '      <div id="slice-clipcanvas" class="slice-background-size" ';
            // html += '        style="width: 100%; height: 100%; background-image: url(&quot;' + this.opts.imageUrl + '&quot;); background-size: 100% 100%;"> ';
            // html += '      </div>'
            html += '    </div>';
            html += '  </div>';
            html += '  <div id="slice-result" class="slice-result slice-noselect" style="text-align: center;"></div>';
            html += '</div>';
            html += '<div id="slice-dragbar" style="position: relative;">';
            html += '  <div id="slice-drag-track" class="slice-border-radius slice-noselect" style="width: 100%; height: 13px; position: relative; text-align: center; line-height: 24px; font-size: 12px; border-radius: 7px; border: 1px solid #ddd;"></div>';
            // html += '  <div type="button" id="slice-drag-slider" class="slice-background-size" readonly="" style="left: 18px;background-image: url(&quot;./icon/slider.png&quot;);background-size: 50%"></div>';//width: 34px; height: 24px;
            html += '  <div id="slice-drag-slider" class="slice-border-radius" style="left: 18px;top:1px">';// class="slice-border-radius"
            html += '    <div id="slice-drag-slider-img" style="position:relative; left:9px; top:6px; width:12px; height:12px; background-image: url(&quot;./icon/slider.png&quot;);background-size: 100%"></div>';
            html += '  </div>';
            html += '</div>';
            captchaBox.innerHTML = html;
            captchaBox.align = "left";//防止使用者在最外层加 align="center" 影响内部样式
            captchaBox.style.position = "relative";

            // if (!this.opts.useCanvas) {
                // var htmlsrc = '<div id="slice-canvas"';// class="slice-background-size"
                // htmlsrc += 'style="display:block;width: 100%; height: 100%; background-image: url(&quot;' + this.opts.imageUrl + '&quot;); background-size: 100% 100%;"> ';
                // htmlsrc += '</div>'
                var htmlsrc = '<img id="slice-canvas" width="0" height="0" src="" style="display:none"></img>';
                var canvasdiv = document.getElementById('slice-canvasbox');
                canvasdiv.innerHTML = htmlsrc;

                // var htmlsrc = '<div id="slice-clipcanvas"';
                // htmlsrc += 'style="width: 100%; height: 100%; background-image: url(&quot;' + this.opts.sliceImageUrl + '&quot;); background-size: 100% 100%;"> ';
                // htmlsrc += '</div>'
                var htmlsrc = '<img id="slice-clipcanvas" class="drag-slider" width="0" height="0" src=""></img>';
                var clipblock = document.getElementById('slice-clipblock');
                clipblock.innerHTML = htmlsrc;
            // }

            this.captchaDOM.slicebody = document.getElementById('slice-body');
            this.captchaDOM.loading = document.getElementById('slice-loading');
            this.captchaDOM.loadMsg = document.getElementById('slice-loadingMsg');
            this.captchaDOM.canvasPanel = document.getElementById('slice-canvas-panel');
            this.captchaDOM.track = document.getElementById('slice-drag-track');
            this.captchaDOM.slider = document.getElementById('slice-drag-slider');
            this.captchaDOM.sliderImg = document.getElementById('slice-drag-slider-img');
            this.captchaDOM.clipblock = document.getElementById('slice-clipblock');
            this.captchaDOM.result = document.getElementById('slice-result');
            this.captchaDOM.refresh = document.getElementById('slice-refresh');
            this.captchaDOM.close = document.getElementById('slice-close');
            this.captchaDOM.dragbar = document.getElementById('slice-dragbar');
            this.captchaDOM.canvas = document.getElementById('slice-canvas');
            this.captchaDOM.clipcanvas = document.getElementById('slice-clipcanvas');
            this.captchaDOM.resultClass = this.captchaDOM.result.className;

            captchaBox.style.padding = '0px';
            captchaBox.style.width = (this.opts.bgWidth + this.opts.bgMarginW * 2) + 'px';
            // captchaBox.style.height = (this.opts.bgHeight + this.opts.bgMarginW*2) + 'px';

            // if (!this.opts.useCanvas) {
            // 	this.captchaDOM.canvas.style.width = this.opts.bgWidth + 'px';
            // 	this.captchaDOM.canvas.style.height = this.opts.bgHeight + 'px';
            // 	this.captchaDOM.clipcanvas.style.width = this.opts.cw + 'px';
            // 	this.captchaDOM.clipcanvas.style.height = this.opts.ch + 'px';
            // } else {
            this.captchaDOM.canvas.width = this.opts.bgWidth;
            this.captchaDOM.canvas.height = this.opts.bgHeight;
            this.captchaDOM.clipcanvas.width = this.opts.cw;
            this.captchaDOM.clipcanvas.height = this.opts.ch;
            // }
            this.captchaDOM.slicebody.style.width = this.opts.bgWidth + 'px';
            this.captchaDOM.slicebody.style.height = this.opts.bgHeight + 'px';
            //this.captchaDOM.slicebody.style.padding = this.opts.bgMarginW + 'px';
            this.captchaDOM.slicebody.style.paddingTop = this.opts.bgMarginW + 'px';
            this.captchaDOM.slicebody.style.paddingLeft = this.opts.bgMarginW + 'px';
            this.captchaDOM.slicebody.style.paddingRight = this.opts.bgMarginW + 'px';
            this.captchaDOM.slicebody.style.paddingBottom =  this.opts.bgMarginBottom + 'px';
            this.captchaDOM.slicebody.style.borderRadius = this.opts.bgMarginW + 'px';
            this.captchaDOM.slicebody.style.backgroundColor = this.opts.bgColor;
            this.captchaDOM.clipblock.style.width = this.opts.cw + 'px';
            this.captchaDOM.clipblock.style.height = this.opts.ch + 'px';
            this.captchaDOM.dragbar.style.width = this.opts.bgWidth + 'px';
            this.captchaDOM.dragbar.style.height = this.opts.barHeight + 'px';
            this.captchaDOM.dragbar.style.left = this.opts.bgMarginW + 'px';
            this.captchaDOM.dragbar.style.paddingTop = this.opts.barBgDistance + 'px';
            this.captchaDOM.track.style.height = this.opts.barHeight + 'px';
            this.captchaDOM.track.style.lineHeight = this.opts.barHeight + 'px';
            //this.captchaDOM.track.style.backgroundColor = this.opts.bgColor;
            this.captchaDOM.track.style.backgroundColor = this.opts.trackColor;
            this.captchaDOM.slider.style.width = this.opts.dragWidth + 'px';
            this.captchaDOM.slider.style.height = this.opts.dragHeight + 'px';
            this.captchaDOM.slider.style.borderRadius = this.opts.dragBorderR + 'px';
            this.captchaDOM.slider.style.top = this.opts.barBgDistance + 1 + this.opts.barHeight / 2 - this.opts.dragHeight / 2 + 'px';
            this.captchaDOM.slider.style.backgroundColor = this.opts.dragColor;
            // this.captchaDOM.slider.style.top = 1 + 'px';
            this.captchaDOM.sliderImg.style.left = (this.opts.dragWidth - 12) / 2 + 'px';
            this.captchaDOM.sliderImg.style.top = (this.opts.dragHeight - 12) / 2 + 'px';
            this.captchaDOM.result.style.width = this.opts.bgWidth + 'px';
            this.captchaDOM.result.style.left = this.opts.bgMarginW + 'px';

            this.captchaDOM.canvas.onmousedown = this.captchaDOM.canvas.onmousemove = function (e) {//禁止浏览器对图片的默认拖拽效果
                var e = e || window.event;
                e.preventDefault ? e.preventDefault() : e.returnValue = false;
            }
            this.setEleCannotselect(this.captchaDOM.track);
            this.setEleCannotselect(this.captchaDOM.loadMsg);
            var _this = this;
            this.captchaDOM.close.onclick = function (e){
                captchaBox.style.display = 'none';

            }
            var sliceTitle = document.getElementById('slice-title');
            sliceTitle.innerText = this.opts.captchaTitle;
            sliceTitle.style.fontSize = this.opts.captchaTitleSize + 'px';
            sliceTitle.style.color = this.opts.captchaTitleColor;
        },
        showLoading: function (isShow) {
            var ele_loading = this.captchaDOM.loading;
            var ele_panel = this.captchaDOM.canvasPanel;
            if (isShow) {
                ele_loading.style.display = "block";
                ele_panel.style.display = "none";
                // ele_panel.style.width = '0px';
            } else {
                ele_loading.style.display = "none";
                ele_panel.style.display = "block";
                // ele_panel.style.width = this.opts.bgWidth + 'px';
            }
        },
        setLoadMessage: function (msg) {
            this.captchaDOM.loadMsg.innerHTML = msg;
        },
        //设置显示的消息
        setMsgShowText: function (msg) {
            this.captchaDOM.track.innerHTML = msg;//firefox10不支持innerText
        },
        setFloatMessage: function (msg) {//浮动条提示
            this.captchaDOM.result.innerHTML = msg;
        },
        setUserEvent: function () {
            var _this = this;

            function mouseDown(e) {
                _this.moveStart(e);
            };
            var mouseMove = function (e) {
                _this.move(e);
            };
            var mouseUp = function (e) {
                setTimeout(function () {//延迟一点验证 等mousetrack获取mouseup的鼠标信息
                    _this.moveEnd(e);
                }, 100);
            };
            var refresh = function (e) {
                _this.refreshMethod(e);
            };
            //对应手机端
            if (this.captchaDOM.slider.addEventListener) {                    // 所有主流浏览器，除了 IE8 及更早版本
                if (this.opts.dragClip) {
                    this.captchaDOM.clipblock.addEventListener('touchstart', mouseDown);
                }
                this.captchaDOM.slider.addEventListener("touchstart", mouseDown);
                this.captchaDOM.captchaBox.addEventListener("touchmove", mouseMove);
                this.captchaDOM.captchaBox.addEventListener("touchend", mouseUp);
            } else if (this.captchaDOM.slider.attachEvent) {                  // IE8 及更早版本
                if (this.opts.dragClip) {
                    this.captchaDOM.clipblock.attachEvent('ontouchstart', mouseDown);
                }
                this.captchaDOM.slider.attachEvent("ontouchstart", mouseDown);
                this.captchaDOM.captchaBox.attachEvent("ontouchmove", mouseMove);
                this.captchaDOM.captchaBox.attachEvent("ontouchend", mouseUp);
            }
            //对应PC端
            if (this.opts.dragClip) {
                // this.captchaDOM.clipblock.ontouchstart = mouseDown;//ontouchstart是实验性API
                this.captchaDOM.clipblock.onmousedown = mouseDown;
                this.captchaDOM.clipcanvas.onmousemove = function (e) {
                    var e = e || window.event;
                    e.preventDefault ? e.preventDefault() : e.returnValue = false;
                };
            } else {
                this.captchaDOM.clipblock.onmousedown = this.captchaDOM.clipblock.onmousemove = function (e) {
                    var e = e || window.event;
                    e.preventDefault ? e.preventDefault() : e.returnValue = false;
                };
            }
            // this.captchaDOM.slider.ontouchstart = mouseDown;
            // this.captchaDOM.captchaBox.ontouchmove = mouseMove;
            // this.captchaDOM.captchaBox.ontouchend = mouseUp;
            this.captchaDOM.slider.onmousedown = mouseDown;
            // this.captchaDOM.captchaBox.onmousemove = mouseMove;
            // this.captchaDOM.captchaBox.onmouseup = mouseUp;
            window.document.onmousemove = mouseMove;
            window.document.onmouseup = mouseUp;

            this.captchaDOM.refresh.onmousedown = refresh;
        },
        //设置用户是否可以操作
        setUserCanOperation: function (isCan) {
            if (isCan) {
                this.captchaDOM.refresh.style.display = 'block';
            } else {
                this.captchaDOM.refresh.style.display = 'none';
            }
            this.userIsCan = isCan;
        },
        loadBGImage: function (imgurl) {
            try {
                var img = new Image();
                img.src = imgurl;
                // img.onload = this.drawCaptcha;
                var _this = this;
                this.imageObject = img;
                // if (!_this.opts.useCanvas) {
                    _this.drawCaptcha_NoCanvas(img);
                // } else {
                    // if (img.complete) {
                        // _this.drawCaptcha(img);
                    // } else {
                        // $(img).on('load', function(e) {//JQuery1.4 不支持这个方法
                        // $(img).load(function (e) {
                            // _this.drawCaptcha(this);
                        // });
                    // }
                // }
            } catch (error) {
                console.error('load image error');
                console.log(error);
            }
        },
        generateRandom32Digits: function() {
            let result = '';
            const characters = '0123456789'; // 包含数字 0-9 的字符集
            for (let i = 0; i < 32; i++) {
                const randomIndex = Math.floor(Math.random() * characters.length);
                result += characters.charAt(randomIndex);
            }
            return result;
        },
        xorStrings:function(str1, str2) {
            const sb = [];
            const segmentLength = str1.length / 8; // 每个段的长度
            for (let i = 0; i < 8; i++) {
                // 计算子字符串的开始和结束索引
                const startIndex = i * segmentLength;
                const endIndex = (i + 1) * segmentLength;
                // 截取子字符串
                const segment1 = str1.substring(startIndex, endIndex);
                const segment2 = str2.substring(startIndex, endIndex);
                // 将子字符串转换为整数
                const intValue1 = parseInt(segment1);
                const intValue2 = parseInt(segment2);
                //console.log("intValue1: " + intValue1 + "+" + intValue2);
                const all = intValue1 ^ intValue2;
                //console.log("异或以后的值：" + all);
                sb.push(all);
            }
            let result = sb.join("");
            if (result.length < 32) {
                while (result.length < 32) {
                    result += "0";
                }
            } else if (result.length > 32) {
                result = result.substring(0, 32);
            }
            return result;
        },
        refreshMethod: function () {
            try {
                if (!this.opts.requestData) {
                    console.error('requestData is must');
                    return;
                }
                var _this = this;
                this.errorNum = 0;
                this.showLoading(true);
                this.setUserCanOperation(false);
                this.setLoadMessage(this.opts.message.loading);
                this.setMsgShowText(this.opts.message.loading);
                var paramObj = {
                    captchaType: 0,//0表示图片流 a表示canvas
                    width: this.opts.bgWidth,
                    height: this.opts.bgHeight,
                    cw: this.opts.cw,
                    ch: this.opts.ch
                }
                this.requestDataDone = false;
                console.log("js requestData之前参数",paramObj);
                this.opts.requestData(paramObj, function (data) {
                    console.log("js requestData之后参数",paramObj);
                    console.log(data);
                    const parsedData = JSON.parse(data);
                    console.log("js requestData回调数据",parsedData);
                    _this.analysisParam(data);

                    _this.loadBGImage(_this.opts.imageUrl);
                    // _this.showLoading(false);//2019.4.18 加载完图片再将状态置为可操作
                    // _this.setMsgShowText(_this.opts.message.tip);
                    _this.reset();

                    _this.requestDataDone = true;
                    if (_this.intervalDone) {
                        _this.setUserCanOperation(true);
                    }

                    try {
                        _this.opts.ready();
                    } catch (error) {
                        console.error('ready error');
                        console.log(error);
                    }
                }, function (error) {
                    _this.setLoadMessage(this.opts.message.error);
                    _this.setMsgShowText(this.opts.message.error);
                }, this);
            } catch (error) {
                console.error('requestData error');
                console.log(error);
            }
        },
        //解析从服务器获取的参数
        analysisParam: function (res) {
            try {
                //console.log("res " + res);
                var jsonData = JSON.parse(res);
                //var keys = [this.opts.clientID];
                //console.log("jsonData " + jsonData.data);
                //console.log(this.opts.crypto_kind);
                switch (this.opts.crypto_kind) {
                    case 0:
                        //3des
                        jsonData.data = this.DES3decrypt(this.createKey(this.opts.clientID), jsonData.data);
                        break;
                    case 1:
                        //sm4
                        jsonData.data = crypto_api.sm4_decrypt_ecb(jsonData.data, /*"1234567890abcdef"*/this.getGmFaKey(this.opts.clientID));
                        break;
                    case 2:
                        //aes
                        jsonData.data = jsonData.data;
                        break;
                }
                //console.log("jsonData 解密= " + jsonData.data);
                jsonData.data = JSON.parse(jsonData.data);
            } catch (error) {
                console.log("error = " + error.toString());
                console.error('JSON error');
                return;
            }
            this.keys = jsonData.data.keys;
            this.opts.imageUrl = jsonData.imageUrl;
            this.opts.sliceImageUrl = jsonData.sliceImageUrl;
            this.picSort = jsonData.data.picSort;
            if (!this.opts.imageUrl) {
                console.error("imageUrl is must");
                return;
            }
            if (!this.opts.sliceImageUrl && !this.opts.useCanvas) {
                console.error("sliceImageUrl is must and not cavas");
                return;
            }
            if (this.opts.useCanvas) {
                if (jsonData.data.pointX < this.opts.cw / 2 || jsonData.data.pointX > (this.opts.bgWidth - this.opts.cw / 2) ||
                    jsonData.data.pointY < this.opts.ch / 2 || jsonData.data.pointY > (this.opts.bgHeight - this.opts.ch / 2)) {
                    console.error("center error(" + jsonData.data.pointX + "," + jsonData.data.pointY + ")");
                    return;
                }
            }
            this.opts.posx = jsonData.data.pointX;
            this.opts.posy = jsonData.data.pointY;
            //console.log(jsonData);
            if (this.opts.crypto_kind == 2) {
                this.sr = jsonData.data.sr;
                this.publicKeyExponent = jsonData.data.publicKeyExponent;
                this.publicKeyModulus = jsonData.data.publicKeyModulus;
            }
        },
        //固定式
        hideImg: function () {
            this.captchaDOM.slicebody.style.display = 'none';
            // opts.captchaBox.lastChild.style.display = 'none';
        },
        //弹出式
        showImg: function () {
            this.captchaDOM.slicebody.style.display = 'block';
            // opts.captchaBox.lastChild.style.display = 'block';
        },
        isArray: function (obj) {
            return Object.prototype.toString.call(obj) === '[object Array]';
        },
        createCanvas: function (w, h) {
            var canvas = document.createElement("canvas");
            canvas.width = w;
            canvas.height = h;
            return canvas;
        },

        randomNum: function (min, max) {
            var rangeNum = max - min;
            var num = min + Math.round(Math.random() * rangeNum);
            return num;
        },

        createSlice_Canvas: function (img, canvasW, canvasH, startx, starty, blockStyle) {
            var sourceCanvas = this.createCanvas(canvasW, canvasH);
            var sctx = sourceCanvas.getContext('2d');
            sctx.drawImage(img, 0, 0, canvasW, canvasH);
            sctx.globalCompositeOperation = 'destination-in';

            var destCanvas = this.createCanvas(this.opts.cw, this.opts.ch);
            this.fillClip(destCanvas, 0, 0, blockStyle, 1);

            sctx.drawImage(destCanvas, startx, starty);

            var clipCanvas = this.captchaDOM.clipcanvas;
            // var clipCanvas = this.createCanvas(this.opts.cw, this.opts.ch);
            // clipCanvas.id = 'slice-clipcanvas';
            var imgdata = sctx.getImageData(startx, starty, this.opts.cw, this.opts.ch);
            clipCanvas.getContext('2d').putImageData(imgdata, 0, 0);

            this.strokeClip(clipCanvas, 0, 0, blockStyle);
            return clipCanvas;
        },
        updateSlice: function (img, startx, starty, blockStyle) {
            var clipblock = this.captchaDOM.clipblock;
            this.lifeCycleA = new Date().getTime();
            // if (this.opts.useCanvas) {
                // this.createSlice_Canvas(img, this.opts.bgWidth, this.opts.bgHeight, startx, starty, blockStyle);
                // 	clipblock.appendChild(clipCanvas);
            // } else {
                this.captchaDOM.clipcanvas.className = 'slice-background-size';
                // this.captchaDOM.clipcanvas.style.backgroundImage = "url('" + this.opts.sliceImageUrl + "')";//'url(&quot;' + this.opts.sliceImageUrl + '&quot;);';
                // if (this.opts.imageType == 'path') {
                this.captchaDOM.clipcanvas.src = this.opts.sliceImageUrl;
                // } else {
                // 	this.captchaDOM.clipcanvas.src = this.getStreamInterface(2);
                // }
                // var clipCanvas = this.createSlice_NoCanvas(this.opts.sliceImageUrl);
                // clipblock.innerHTML = clipCanvas;
            // }
            clipblock.style.top = starty + 'px';
            clipblock.style.left = this.opts.padding + 'px';
        },
        drawCaptchaCutting: function (imageT, pics){
            //console.log("drawCaptchaCutting:" + pics);
            //console.log("drawCaptchaCutting-length:" + pics.length);
            var sourceCanvas = this.createCanvas(this.opts.bgWidth, this.opts.bgHeight);
            var sctx = sourceCanvas.getContext('2d');
            var pixelWidth = this.opts.bgWidth;
            var pixelHeight = this.opts.bgHeight;
            var imgSheetWidth = pixelWidth/pics.length;
            var imgSheetHeight = pixelHeight;
            for(var i=0; i<pics.length; i++){
                var loca = imgSheetWidth*pics[i];
                //console.log("loca1" + i + "-" + loca1);
                //console.log("loca2" + i + "-" + loca2);
                //console.log("loca" + i + "-" + loca);
                sctx.drawImage(imageT,imgSheetWidth*i,0,imgSheetWidth,pixelHeight,loca,0,imgSheetWidth,imgSheetHeight);
            }
            var imgDataUrl = sourceCanvas.toDataURL();
            this.captchaDOM.canvas.src = imgDataUrl;
        },
        drawCaptcha_NoCanvas: function (newImage) {
            // if (this.opts.posx == 0 || this.opts.posy == 0) return;

            var startPoint = {startx: this.opts.posx - this.opts.cw / 2, starty: this.opts.posy - this.opts.ch / 2};
            if (!startPoint) {
                console.error("can not get the start point");
                return;
            }
            // this.captchaDOM.canvas.style.backgroundImage = "url('" + this.opts.imageUrl + "')";//'url(&quot;' + this.opts.sliceImageUrl + '&quot;);';
            // this.captchaDOM.canvas.src = this.opts.imageUrl;
            if(this.opts.useCanvas){
                var pics = this.picSort;
                if(pics == undefined || pics == null){
                    this.captchaDOM.canvas.src = this.opts.imageUrl;
                } else {
                    var imageT = new Image();
                    imageT.src = this.opts.imageUrl;
                    imageT.onload = function(){
                        _this.drawCaptchaCutting(imageT, pics);
                    };
                }
            } else {
                this.captchaDOM.canvas.src = this.opts.imageUrl;
            }


            this.captchaDOM.canvas.className = 'slice-background-size';//for ie7 ie8

            var _this = this//背景图片加载完成后，图片才显示，防止背景图片一点一点加载 防止滑块图片先显示
            this.captchaDOM.canvas.style.display = 'none';
            this.captchaDOM.clipcanvas.style.display = 'none';
            this.captchaDOM.canvas.onload = function () {
                _this.captchaDOM.canvas.style.display = 'block'
                _this.captchaDOM.clipcanvas.style.display = 'block'
                _this.showLoading(false);
                _this.setMsgShowText(_this.opts.message.tip);
            }

            this.updateSlice(newImage, startPoint.startx, startPoint.starty);
        },

        setResultStatus: function (res, succesMsg) {
            if (res == 'success') {
                this.setMsgShowText(succesMsg + ',' + this.opts.message.success);
                this.setFloatMessage(this.opts.message.success);
                // this.captchaDOM.result.innerHTML = this.opts.message.success;
                this.captchaDOM.result.className = this.captchaDOM.resultClass + ' success';
                //this.captchaDOM.track.style.color = '#4cae4c';
                //this.captchaDOM.track.style.borderColor = '#4cae4c';
                this.captchaDOM.track.style.color = '#c9c2b0';
                this.captchaDOM.track.style.borderColor = '#c9c2b0';
            } else if (res == 'fail') {
                this.setMsgShowText(this.opts.message.fail);
                // this.captchaDOM.result.innerHTML = this.opts.message.fail;
                this.captchaDOM.result.className = this.captchaDOM.resultClass + ' fail';
                //this.captchaDOM.track.style.color = '#d9534f';
                //this.captchaDOM.track.style.borderColor = '#d9534f';
                this.captchaDOM.track.style.color = '#c9c2b0';
                this.captchaDOM.track.style.borderColor = '#c9c2b0';
            } else {
                this.setMsgShowText(this.opts.message.forbidden);
                // this.captchaDOM.result.innerHTML = this.opts.message.forbidden;
                this.captchaDOM.result.className = this.captchaDOM.resultClass + ' fail';
                //this.captchaDOM.track.style.color = '#d953ff';
                //this.captchaDOM.track.style.borderColor = '#d953ff';
                this.captchaDOM.track.style.color = '#c9c2b0';
                this.captchaDOM.track.style.borderColor = '#c9c2b0';
            }
            // this.captchaShake();
            var _this = this;
            var interval = this.opts.interval;
            this.intervalDone = false;

            function intervalS() {
                var msg = (res == 'fail' ? _this.opts.message.fail : _this.opts.message.forbidden) + ', ' + _this.opts.message.wait + ' ' + interval + 's';
                // var msg = (res == 'fail' ? _this.opts.message.fail : _this.opts.message.forbidden) + ', ' + interval + 's 后重试';
                _this.setFloatMessage(msg);
                var int = setInterval(function () {
                    interval--;
                    var msg = (res == 'fail' ? _this.opts.message.fail : _this.opts.message.forbidden) + ', ' + _this.opts.message.wait + ' ' + interval + 's';
                    _this.setFloatMessage(msg);
                    if (interval <= 0) {
                        _this.intervalDone = true;
                        if (_this.requestDataDone) {
                            _this.setUserCanOperation(true);
                        }

                        _this.resetTrack();
                        clearInterval(int);
                    }
                }, 1000);
            }

            if (res != 'success') {
                intervalS();
            }
        },
        resetTrack: function () {
            this.captchaDOM.track.style.color = '#000';
            //this.captchaDOM.track.style.borderColor = '#ddd';
//            this.captchaDOM.track.style.color = '#c9c2b0';
            this.captchaDOM.track.style.borderColor = '#c9c2b0';
            this.captchaDOM.result.className = this.captchaDOM.resultClass;
        },
        setSlicePos: function (centerX) {
            this.captchaDOM.slider.style.left = (centerX - this.opts.dragWidth / 2) + "px";
            this.captchaDOM.clipblock.style.left = (centerX - this.opts.cw / 2) + "px";
        },
        reset: function () {
            this.clearMouseTrack();
            this.setSlicePos(this.opts.padding + this.opts.cw / 2);
        },

        moveStart: function (e) {
            var e = e || window.event;
            if (!this.userIsCan) {
                e.preventDefault ? e.preventDefault() : e.returnValue = false;
                return;
            }
            this.startTime = new Date().getTime();
            this.setMsgShowText("");
            this.opts.eventinfo.flag = true;
            if (e.touches) {
                this.opts.eventinfo.currentX = e.touches[0].clientX;
            } else {
                this.opts.eventinfo.currentX = e.clientX;
            }
            e.preventDefault ? e.preventDefault() : e.returnValue = false;
        },
        move: function (e) {
            var e = e || window.event;
            if (!this.userIsCan) {
                e.preventDefault ? e.preventDefault() : e.returnValue = false;
                return;
            }
            if (this.opts.eventinfo.flag) {
                if (e.touches) {
                    var disX = e.touches[0].clientX - this.opts.eventinfo.currentX;
                } else {
                    var disX = e.clientX - this.opts.eventinfo.currentX;
                }
                var startX = this.opts.padding + this.opts.cw / 2;
                disX += startX;
                if (disX < startX || disX > (this.opts.bgWidth - this.opts.padding - this.opts.cw / 2)) {//限制滑块不能超出范围
                    return false
                }
                this.setSlicePos(disX);

                e.preventDefault ? e.preventDefault() : e.returnValue = false;
                return false;
            }
        },
        moveEnd: function (e) {
            var e = e || window.event;
            if (!this.userIsCan) {
                return;
            }
            if (this.opts.eventinfo.flag) {
                this.opts.eventinfo.flag = false;

                var disX = parseFloat(this.getStyle(this.captchaDOM.clipblock, 'left'));
                disX += this.opts.cw / 2;
                this.lifeCycleB = new Date().getTime();
                if(this.lifeCycleB <= this.lifeCycleA || (this.lifeCycleB - this.lifeCycleA) < 1000){
                    this.lifeCycleA = 0;
                    this.lifeCycleB = 0;
                }
                var resData = {
                    deviceInfo: this.opts.useDeviceInfo ? this.getEquipmentFinger() : undefined,
                    mouseInfo: this.getMouseTrack(),
                    isMobile: this.isMobileDevice(),
		            isWebDriver: this.getWebDriver(),
                    left: disX,
                    captchaType: 'slice_check',
                    lifeCycleStart: this.lifeCycleA,
                    lifeCycleEnd: this.lifeCycleB
                }
                //console.log("验证参数==",resData);
                resData = JSON.stringify(resData);
                var rsaParams = {};
                // console.log("resData = " + resData);
                /*if (this.opts.useDES3) {
                    resData = this.DES3encrypt(this.createKey(this.opts.clientID, this.keys), resData);
                    // resData = crypto_api.aes_encrypt_ecb(resData, this.createAESKey(this.opts.clientID, this.keys));
                }*/
                // var keys = [this.opts.clientID];
                switch (this.opts.crypto_kind) {
                    case 0:
                        resData = this.DES3encrypt(this.createKey(this.opts.clientID, this.keys), resData);
                        break;
                    case 1://SM4
                        resData = crypto_api.sm4_encrypt_ecb(resData, /*"1234567890abcdef"*/this.getGmFaKey(this.opts.clientID, this.keys));
                        break;
                    case 2://AES
                    {
                        const cr = this.generateRandom32Digits();
                        if (this.opts.crypto_kind == 2 && this.publicKeyModulus !== undefined && this.publicKeyExponent !== undefined) {
                            setMaxDigits(512);
                            var key = new RSA2048KeyPair(this.publicKeyExponent,"",this.publicKeyModulus);
                            //pub加密sr cr
                            rsaParams = {
                                sr: encryptedString(key,this.sr),
                                cr: encryptedString(key, cr),
                            }
                            // 将公钥加密的数据转为json
                            rsaParams = JSON.stringify(rsaParams);
                        }
                        //获取到服务器的SR，此时生成js的CR
                        if (this.sr !== undefined) {
                            const xorStr = this.xorStrings(this.sr,cr);
                            resData = crypto_api.aes_encrypt_cbc(resData,xorStr)
                        }
                        // rsaParams.resDataString = resData;
                        // const a = crypto_api.aes_decrypt_cbc(resData,xorStr)
                        // console.log("解密 ==",JSON.parse(a));
                    }
                    break;
                }
                //console.log("验证参数加密==",resData);
                 //console.log("resData = " + resData);
                var _this = this;
                var totalTime = new Date().getTime() - this.startTime;
                var successMsg = Math.round(totalTime / 100) / 10 + _this.opts.message.finish;
                this.setUserCanOperation(false);
                this.setMsgShowText(this.opts.message.checking);
                try {
                    var allParams = {};
                    if (this.opts.crypto_kind == 2) {
                        allParams = {
                            "rsaParams":rsaParams,
                            "resData":resData
                        }
                        allParams = JSON.stringify(allParams);
                        resData = allParams;
                        // console.log("==2提交给后台参数",resData);
                    }else {
                        resData = resData;
                        // console.log("!=2提交给后台参数",resData);
                    }
                    this.opts.sendData && this.opts.sendData(resData, function (serverRes) {
                        //console.log("移动结束",resData);
                        // ERROR_1距离无效   ERROR_2轨迹无效   ERROR_3超时   SUCCESS
                        var obj = {Data: 'success'};
                        if (serverRes == 'SUCCESS') {
                            obj.Data = 'success';
                        } else if (serverRes == 'ERROR_1') {
                            obj.Data = 'fail';
                        } else if (serverRes == 'ERROR_2') {//被怪兽吃掉
                            obj.Data = 'forbid';
                        } else {
                            obj.Data = 'forbid';
                        }
                        try {
                            // var resObj = JSON.parse(serverRes);
                            var resStr = obj.Data;
                        } catch (error) {
                            console.error('analysis server data');
                            console.log(error);
                            return;
                        }
                        _this.setResultStatus(resStr, successMsg);
                        if (resStr !== 'success') {
                            _this.errorNum = _this.errorNum + 1;
                            setTimeout(function () {
                                if (_this.opts.needAgainNum <= _this.errorNum) {
                                    _this.refreshMethod();
                                } else {
                                    _this.requestDataDone = true;//此时没有调requestData 算做调用完成
                                    _this.reset();
                                    // _this.setUserCanOperation(true);//等opts.interval秒后 再让用户操作
                                    _this.setMsgShowText(_this.opts.message.tip);
                                }
                            }, 500);
                        } else {
                            // setTimeout(function () {//////////////
                            // 	_this.refreshMethod();
                            // }, 500);
                        }
                        try {
                            _this.opts.checkResult(resStr);
                        } catch (error) {
                            console.error('checkResult error');
                            console.log(error);
                        }
                    });
                } catch (error) {
                    console.error('sendData error');
                    console.log(error);
                }
            }
        },
        getStyle: function (elem, name) {
            if (elem.style[name]) {//如果该属性存在于style[]中，则它最近被设置过(且就是当前的)
                return elem.style[name];
            } else if (elem.currentStyle) {//尝试IE的方式
                return elem.currentStyle[name];
            } else if (document.defaultView && document.defaultView.getComputedStyle) {//或者W3C的方法，如果存在的话
                //它使用传统的"text-Align"风格的规则书写方式，而不是"textAlign"
                // name = name.replace(/([A-Z])/g,"-$1");
                // name = name.toLowerCase();
                //获取style对象并取得属性的值(如果存在的话)
                var s = document.defaultView.getComputedStyle(elem, "");
                return s && s.getPropertyValue(name);
                //否则，就是在使用其它的浏览器
            } else {
                return null;
            }
        },
        setEleCannotselect: function (element) {
            if (typeof(element.onselectstart) != "undefined") {
                // IE下禁止元素被选取
                element.onselectstart = new Function("return false");
            } else {
                // firefox下禁止元素被选取的变通办法 ---目前用CSS样式控制 不需要这个方法
                // element.onmousedown = new Function("return false");
                // element.onmouseup = new Function("return true");
            }
        },
	    getWebDriver: function () {
          	  var res = false;
	            try {
                res = window.navigator.webdriver
            } catch (e) {
                console.log("navigator :" + e);
            }
            return res;
        }
    }

    var _CaptchaObj = {
        curBrowser: 'unknown',
        browserVer: 0,
        debug_log: function (log) {
            if (window.console) console.log(log);
        },
        debug_error: function (err) {
            if (window.console) console.error(err);
        },
        debug_warn: function (warn) {
            if (window.console) console.warn(warn);
        },
        checkBrowser: function () {
            var ua = navigator.userAgent.toLowerCase();
            if (ua.indexOf("msie") > -1) {
                this.curBrowser = 'ie';
                var safariVersion = ua.match(/msie ([\d.]+)/)[1];
                this.browserVer = safariVersion;
            } else {
                this.curBrowser = 'other';
            }
        }
    }


    if (typeof exports == "object") {
        module.exports = ICBCSliceCaptcha;
    } else if (typeof define == "function" && define.amd) {
        define([], function () {
            return ICBCSliceCaptcha;
        });
    } else if (window) {
        window.ICBCSliceCaptcha = ICBCSliceCaptcha;
        window._CaptchaObj = _CaptchaObj;
    }
})();