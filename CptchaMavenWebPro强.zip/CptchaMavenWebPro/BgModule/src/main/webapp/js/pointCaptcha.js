
;(function ($, window, document) {
    "use strict";
    //定义Points的构造函数
    var ICBCPointCaptcha = function (divID, opt) {
        this.$element = $('#' + divID);

        this.defaults = {
            mode: 'fixed',//弹出式pop，固定fixed
            wordList: [],//图片上的文字信息 从服务器获取
            imageUrl: 'bgimg/demo1.jpeg',//背景图片URL 从服务器获取
            msgImageUrl: 'bgimg/demo1.jpeg',//提示信息图片URL 从服务器获取
            bgWidth: 300, //验证码背景图片的宽，宽度如果是% 是相对于手机屏幕宽
            bgHeight: 200,//验证码背景图片的高，高度如果是% 是相对于宽度
            barHeight: 24,//提示栏的高度
            bgMarginW: 12,//图片边缘留白的宽度
            bgMarginBottom: 10,
            barBgDistance: 2,//滑动条和验证框的距离
            bgColor: '#e4e4e4',//背景颜色
            trackColor: '#e4e4e4',
            captchaTitle: '点选验证码',
            captchaTitleSize: 20,
            captchaTitleColor: '#000000',
            message: {
                loading: '加载中...',
                checking: '正在验证 请稍等...',
                tip: '请顺序点击',//提示信息
                success: '验证成功',
                fail: '位置不正确',
                forbidden: '操作异常',
                finish: '秒完成',
                error: '网络错误'
            },
            tipCanvas: false,//提示点击的文字 是否使用Canvas，如果是按语序点击文字 设置为false
            clientID: null,//用于加密
            useCanvas: true,//是否使用Canvas
            useIdiom: false,//是否使用成语类
            pointShape: 'circle',//点击标志的形状 circle square
            pointH: 20,//点击标志的圆圈直径 或 方形边长
            pointColor: '#1abd6c',//点击标志的颜色
            wordProperty: {
                textH: [15, 40],//最小/大文字高度
                alpha: [0.7, 0.9],//最小/大文字透明度
                rotate: [-Math.PI / 2, Math.PI / 2],//最小/大文字旋转角度
                usefuzzy: false,//模糊
                fontstyle: 'oblique',//是否斜体 normal不使用斜体 ---random随机
                bold: 'normal',//bold normal bolder 400 ---random随机
                fontfamily: ['microsoft yahei', 'arial'],//字体列表
                colorMode: 'autoColor',//selectColor选择一种颜色 autoColor从背景颜色选取 gradientColor颜色渐变
                selectColor: ['#FF0033', '#006699'],//colorMode=='selectColor'时有效，选取颜色列表
                autoColor: [90, 0, 0],//colorMode=='autoColor'时有效，和背景颜色的差异
                gradientColor: {direction: 8, colorList: ['#FF00FF', '#FFFF00', '#00FF00']}//colorMode=='gradientColor'时有效，颜色渐变
            },
            //useDES3: true,//是否使用3DES加密
            crypto_kind: 0,
            useDeviceInfo: true,//是否获取设备信息
            needAgainNum: 2,//用户验证失败几次，需要重新拉取数据
            requestData: null,//请求初始化数据的函数
            sendData: null, //发送用户点选数据的函数
            ready: function () {
            },//验证码准备好了的回调函数
            checkResult: function (res) {
            }//用户验证结果的回调函数
            // success: function(){},//用户验证通过的回调函数
            // fail: function(){}//用户验证失败的回调函数
        },
            this.divID = divID;
        this.options = $.extend({}, this.defaults, opt);
        this.deviceType = 'Windows';
        this.choosePosList = [];
        this.htmlDoms = {};
        this.userIsCan = false;//用户是否可以操作，比如当加载中等时机 不能操作
        this.msgFontsize = 12;//提示文字的大小
        this.defaultNum = 4;//默认的文字数量
        this.checkNum = 3;//校对的文字数量
        this.errorNum = 0;//验证错误的次数
        this.keys = '';
        this.startTime = new Date().getTime();
        this.picSort = null;
        this.lifeCycleA = new Date().getTime();
        this.lifeCycleB = new Date().getTime();
        this.sr = '';
        this.publicKeyExponent = '';
        this.publicKeyModulus = '';
        //对应ie6 ie7浏览器不支持 window.console
        if (!window.console) {
            window.console = {
                log: function () {
                },
                warn: function () {
                },
                error: function () {
                },
                info: function () {
                }
            };
        }

        this.init();
        this.code_color = ['#FF0033', '#006699', '#993366', '#FF9900', '#66CC66', '#FF33CC'];
    };

    //定义pointsVerify的方法
    ICBCPointCaptcha.prototype = {
        getVersion: function () {
            return '1.2.0';
        },
        init: function () {
            //检查参数数据有效性
            // var parentWidth = this.$element.parent().width() || $(window).width();
            if (typeof this.options.bgWidth == 'string') {
                if (this.options.bgWidth.indexOf('%') != -1) {
                    if (!this.isPhone()) {
                        console.error('fail width is % in pc');
                        return;
                    }
                    // var screanW = document.documentElement.clientWidth || document.body.clientWidth;
                    var screanW = window.screen.width;//在webview中，如果预加载页面，webview没有显示，此时文档宽为0
                    screanW = screanW / window.devicePixelRatio;
                    this.options.bgWidth = parseInt(this.options.bgWidth) / 100 * screanW;
                } else {
                    this.options.bgWidth = parseInt(this.options.bgWidth);
                }
            }
            if (typeof this.options.bgHeight == 'string') {
                if (this.options.bgHeight.indexOf('%') != -1) {
                    this.options.bgHeight = parseInt(this.options.bgHeight) / 100 * this.options.bgWidth;
                } else {
                    this.options.bgHeight = parseInt(this.options.bgHeight);
                }
            }

            if (typeof this.options.wordProperty != 'object') {
                console.error('wordProperty is not object');
            }
            if (!this.options.wordProperty.textH || this.options.wordProperty.textH.length != 2) {
                console.error('textH must mod 2');
            }
            if (!this.options.wordProperty.alpha || this.options.wordProperty.alpha.length != 2) {
                console.error('alpha must mod 2');
            }
            if (!this.options.wordProperty.rotate || this.options.wordProperty.rotate.length != 2) {
                console.error('rotate must mod 2');
            }
            if (!this.options.wordProperty.fontfamily || this.options.wordProperty.fontfamily.length <= 0) {
                console.error('fontfamily length error');
            }
            if (this.options.wordProperty.colorMode == 'autoColor' && this.options.wordProperty.autoColor.length != 3) {
                console.error('colorMode为"autoColor"时，autoColor must mod 3');
            }
            if (this.options.wordProperty.colorMode == 'selectColor' && this.options.wordProperty.selectColor.length <= 0) {
                console.error('colorMode为"selectColor"，selectColor length error');
            }
            if (this.options.wordProperty.colorMode == 'gradientColor' && this.options.wordProperty.gradientColor.colorList.length < 2) {
                console.error('colorMode is gradientColor, gradientColor.colorList length error');
            }
            if (!this.options.clientID) {
                console.error('clientID null');
                return "";
            }

            this.getDeviceType();
            this.checkBrowserVersion();

            //加载页面
            this.loadDom();
            this.setUserEvent();

            this.initMouseTrack();

            this.refresh();

            var _this = this;
            if (this.options.mode == 'pop' && !this.isPhone()) {
                this.$element[0].onmouseenter = function (e) {
                    _this.showImg();
                };
                this.$element[0].onmouseleave = function (e) {
                    _this.hideImg();
                };
                // this.$element.on('mouseenter', function(e){
                // 	_this.showImg();
                // });
                // this.$element.on('mouseleave', function(e){
                // 	_this.hideImg();
                // });

                // this.htmlDoms.ele_body.on('mouseover', function(e){
                // 	_this.showImg();
                // });
                // this.htmlDoms.ele_body.on('mouseout', function(e){
                // 	_this.hideImg();
                // });
            }
        },
        // setClientID: function(id) {
        // 	this.options.clientID = id;
        // },
        initMouseTrack: function () {
            try {
                if (mouseTrack) {
                    mouseTrack.initMouseTrack(this.divID);
                } else {
                    console.error('mouseTrack undefined');
                }
            } catch (error) {
                console.error('mouseTrack.initMouseTrack error');
                console.log(error);
            }
        },
        getMouseTrack: function () {
            try {
                if (mouseTrack) {
                    return mouseTrack.mouseTrackInfo();
                } else {
                    console.error('mouseTrack undefined');
                }
            } catch (error) {
                console.error('mouseTrack.mouseTrackInfo error');
                console.log(error);
            }
        },
        clearMouseTrack: function () {
            try {
                if (mouseTrack) {
                    mouseTrack.clearTrackInfo();
                } else {
                    console.error('mouseTrack undefined');
                }
            } catch (error) {
                console.error('mouseTrack.clearTrackInfo error');
                console.log(error);
            }
        },
        extend: function (target, source) {
            if (source == null) {
                return target
            }
            for (var k in source) {
                if (source[k] != null && target[k] !== source[k]) {
                    target[k] = source[k]
                }
            }
            return target
        },
        createKey: function (key1, key2) {
            var key = key1;
            if (key2) key += key2;
            try {
                key = sha256_digest(key);
                key = key.substr(4, key.length - 8);
                //key = "1234567890abcdef12345678";
                
                if(key.length > 24){
                    //console.log("key = " + key.substring(0, 24));
                    return key.substring(0, 24)
                }{
                    //console.log("key = " + key);
                    return key;
                }
                //return key;
            } catch (error) {
                console.error('init Key error');
                console.log(error);
                return "";
            }
        },
        createAES_SM4Key: function () {
            var str = this.createKey(this.options.clientID);
            //console.log("aes_sm4 key str = " + str);
            var str_aes_sm4 = str.substring(0, 16);
            //console.log("aes_sm4 key str_aes_sm4 = " + str_aes_sm4);
            return str_aes_sm4;

        },
        getGmFaKey: function (keys,keywyj) {
            if (keys.length < 1 || keys.length > 2) {
                return "";
            }
            var str = "";
            var allKey = keys;
            if (keywyj) allKey += keywyj;
            for (var i = 0; i < allKey.length; i++) {
                str += allKey[i];
            }
            // for (var i = 0; i < keys.length; i++) {
            //     str += keys[i];
            // }
            var i = sha256_digest(str);
            //console.log("sm4_key = " + i.substring(0, 16));
            return i.substring(0, 16).toLowerCase();
            // var i = SHA1(str);
            // //console.log("sm4_key = " + i.substring(0, 16));
            // return i.substring(0, 16).toLowerCase();
        },
        DES3encrypt: function (key, str) {
            var des3en = "";
            // var base64en = "";
            try {
                des3en = DES3.encrypt(key, str);//已经自带了Base64转换 当IE8时 不支持btoa 则使用BASE64.js
            } catch (error) {
                console.error('D3et error');
                console.log(error);
                return "";
            }
            // console.log(des3en)
            // try {
            // 	base64en = BASE64.encoder(des3en);
            // } catch (error) {
            // 	console.error('Base64转换时出现异常，详细信息如下：');
            // 	console.log(error);
            // }
            return des3en;
        },
        DES3decrypt: function (key, str) {
            var des3en = "";
            // var base64en = "";
            // try {
            // 	base64en = BASE64.decoder(str)
            // } catch (error) {
            // 	console.error('Base64转换时出现异常，详细信息如下：');
            // 	console.log(error);
            // 	return "";
            // }
            try {
                des3en = DES3.decrypt(key, str);
            } catch (error) {
                console.error('D3dt error');
                console.log(error);
            }
            return des3en;
        },
        getDeviceType: function () {
            var platform = navigator.platform;
            if (platform.indexOf('Win') >= 0) {
                this.deviceType = 'Windows';
            } else if (platform.indexOf('Linux') >= 0 && platform.indexOf('arm') >= 0) {
                this.deviceType = 'Android';
            } else if (platform.indexOf('Linux') >= 0){
            	this.deviceType = 'Linux';
            } else if (platform.indexOf('iPhone') >= 0) {
                this.deviceType = 'iPhone';
            } else {
                this.deviceType = 'Unknown';
            }
        },
        getEquipmentFinger: function () {
            var NavigatorFinger = {};
            var WindowFinger = {};
            try {
                if (navigatorFinger) {
                    NavigatorFinger = navigatorFinger.get();
                } else {
                    console.error('nf undefined');
                }
            } catch (error) {
                console.error('nf.get error');
                console.log(error);
            }
            try {
                if (windowFinger) {
                    WindowFinger = windowFinger.get();
                } else {
                    console.error('wf undefined');
                }
            } catch (error) {
                console.error('wf.get error');
                console.log(error);
            }
            this.extend(WindowFinger, NavigatorFinger);
            return WindowFinger;
        },
        checkBrowserVersion: function () {
            var DEFAULT_VERSION = 8.0;
            var ua = navigator.userAgent.toLowerCase();
            if (ua.indexOf("msie") > -1) {
                var safariVersion = ua.match(/msie ([\d.]+)/)[1];
                if (safariVersion <= DEFAULT_VERSION) {
                    this.options.useCanvas = false;
                }
                ;
            }
        },
        isPhone: function () {
        	var platform = navigator.platform;
            if(platform.indexOf('iPhone') >= 0){
            	return true;
            }
            if (platform.indexOf('Linux') >= 0 && platform.indexOf('arm') >= 0) {
                return true;
            } else {
                return false;
            }
        },
        //加载页面
        loadDom: function () {
            var panelHtml = '';
            panelHtml += '<div id="verify-body" class="verify-border-radius" style="background-color: #e5e5e5">';
            panelHtml += '  <div id="verify-loading" style="width:100%; height:100%;">';
            panelHtml += '    <div style="height: 50%;"></div><div id="verify-loadingMsg" class="verify-noselect" style="text-align: center;"></div>';
            panelHtml += '  </div>';
            panelHtml += '  <div id="verify-img-panel" style="position: relative; margin:0;">';
            panelHtml += '    <div id="verify-refresh" style="z-index:3">';
            // panelHtml += '      <i class="iconfont"></i>';// icon-refresh
            panelHtml += '    </div>';
            //panelHtml += '    <div id="verify-close" style="z-index:3; display: block;">    </div>';
            panelHtml += '    <div id="verify-canvasbox" style="width: 100%; height: 100%;">';
            panelHtml += '      <canvas id="verify-canvas" width="' + this.options.bgWidth + '" height="' + this.options.bgHeight + '"></canvas>';
            panelHtml += '    </div>';
            panelHtml += '  </div>';
            panelHtml += '    <div id="point-title" style="z-index: 3;  position: absolute;"></div>';
            panelHtml += '    <div id="verify-close" style="z-index:3; display: block;">';
            panelHtml += '    </div>';
            panelHtml += '</div>';
            panelHtml += '<div id="verify-bar-area" style="position: relative;">';
            panelHtml += '  <div id="verify-track" class="verify-border-radius" style="width:100%; height:100%;">';
            panelHtml += '    <div id="verify-msg-left" class="verify-noselect" style="float:left;width:50%;"></div>';
            panelHtml += '    <div id="verify-msg-right" style="float:right;">';
            panelHtml += '      <canvas id="verify-msg-canvas" width="100" height="30"></canvas>';
            panelHtml += '    </div>';
            panelHtml += '  </div>';
            panelHtml += '</div>';

            this.$element.append(panelHtml);
            this.$element.attr("align", "left");//防止使用者在最外层加 align="center" 影响内部样式

            // if (!this.options.useCanvas) {
                // var htmlsrc = '<div id="verify-canvas"';// class="verify-background-size"
                // htmlsrc += 'style="display:block;width: 100%; height: 100%; background-image: url(&quot;' + this.options.imageUrl + '&quot;); background-size: 100% 100%;"> ';
                // htmlsrc += '</div>'
                var htmlsrc = '<img id="verify-canvas" width="' + this.options.bgWidth + '" height="' + this.options.bgHeight + '" src=""></img>';
                var canvasdiv = document.getElementById('verify-canvasbox');
                canvasdiv.innerHTML = htmlsrc;

                var htmlsrc = '<img id="verify-msg-canvas" width="100" height="30" src=""></img>';
                var msgRight = document.getElementById('verify-msg-right');
                msgRight.innerHTML = htmlsrc;
            // }

            this.htmlDoms = {
                ele_loading: this.$element.find('#verify-loading'),
                ele_loadMsg: this.$element.find('#verify-loadingMsg'),
                ele_refresh: this.$element.find('#verify-refresh'),
                //ele_close: this.$element.find('#verify-close'),
                ele_body: this.$element.find('#verify-body'),
                ele_panel: this.$element.find('#verify-img-panel'),
                ele_canvas: this.$element.find('#verify-canvas')[0],
                ele_bar: this.$element.find('#verify-bar-area'),
                ele_track: this.$element.find('#verify-track'),
                ele_msgLeft: this.$element.find('#verify-msg-left'),
                ele_msgRight: this.$element.find('#verify-msg-right'),
                ele_msgCanvas: this.$element.find('#verify-msg-canvas')
                
                
            };

            var ele_close =  document.getElementById('verify-close');
            var _this_ = this;
            ele_close.onclick = function (e){//点击关闭按钮的功能，具体功能咋编写？
                
                _this_.$element.css('display', 'none');
            };
            var  pointTitle = document.getElementById('point-title');
            pointTitle.innerHTML = this.options.captchaTitle;
            pointTitle.style.fontSize = this.options.captchaTitleSize + 'px';
            pointTitle.style.color = this.options.captchaTitleColor;

            this.$element.css('position', 'relative');
            this.$element.css({'width': (this.options.bgWidth + this.options.bgMarginW * 2) + 'px'});
            // 'height': (this.options.bgHeight+this.options.bgMarginW*2) + 'px'});
            if (this.options.mode == 'pop' && !this.isPhone()) {
                this.htmlDoms.ele_body.css({
                    'display': 'none',
                    'position': 'absolute',
                    'bottom': (this.options.barHeight + this.options.barBgDistance) + 'px'
                });
            } else {
                this.htmlDoms.ele_body.css({'position': 'relative'});
                // this.$element.css({'padding': this.options.bgMarginW + 'px',
                // 									'border-radius': this.options.bgMarginW + 'px',
                // 									'background-color': this.options.bgColor + 'px'});
            }
            this.htmlDoms.ele_body.css({
                'height': parseInt(this.options.bgHeight) + 'px',
                'width': this.options.bgWidth + 'px',
                'paddingTop': this.options.bgMarginW + 'px',
                'paddingLeft': this.options.bgMarginW + 'px',
                'paddingRight': this.options.bgMarginW + 'px',
                'paddingBotton': this.options.bgMarginBottom + 'px',
                'border-radius': this.options.bgMarginW + 'px',
                'background-color': this.options.bgColor
            });
            this.htmlDoms.ele_panel.css({
                'width': this.options.bgWidth + 'px',
                'height': this.options.bgHeight + 'px',
                'background-size': this.options.bgWidth + 'px ' + this.options.bgHeight + 'px',
                'margin-bottom': '0px'
            });
            this.htmlDoms.ele_bar.css({
                'left': this.options.bgMarginW + 'px',
                'width': this.options.bgWidth + 'px',
                'height': this.options.barHeight + 'px',
                'padding-top': this.options.barBgDistance + 'px',
                'line-height': this.options.barHeight + 'px'
            });
            // 'background-color': this.options.bgColor});
            this.htmlDoms.ele_track.css({'background-color': this.options.trackColor});
            this.htmlDoms.ele_msgLeft.css({'font-size': this.msgFontsize + 'px'});

            //禁止浏览器对图片的默认拖拽效果 IE7时onmousemove有效 其他浏览器onmousedown有效
            this.htmlDoms.ele_canvas.onmousedown = this.htmlDoms.ele_canvas.onmousemove = function (e) {
                var e = e || window.event;
                e.preventDefault ? e.preventDefault() : e.returnValue = false;
            }
            this.setEleCannotselect(this.htmlDoms.ele_loadMsg[0]);
            this.setEleCannotselect(this.htmlDoms.ele_msgLeft[0]);
        },
        showLoading: function (isShow) {
            if (isShow) {
                this.htmlDoms.ele_loading.show();
                this.htmlDoms.ele_panel.hide();
                // this.htmlDoms.ele_panel.css({'height': '0px'});
            } else {
                this.htmlDoms.ele_loading.hide();
                this.htmlDoms.ele_panel.show();
                // this.htmlDoms.ele_panel.css({'height': this.options.bgHeight + 'px'});
            }
        },
        //设置显示的消息
        setLoadMessage: function (msg) {
            this.htmlDoms.ele_loadMsg.text(msg);
        },
        setMsgShowText: function (msg1, msg2) {
            if (msg2) {
                this.htmlDoms.ele_msgLeft.css({'width': '50%', 'text-align': 'right'});
                this.htmlDoms.ele_msgCanvas.css({'display': 'block'});
                this.htmlDoms.ele_msgLeft.text(msg1);
                if (this.options.useCanvas) {
                    var ctx = this.htmlDoms.ele_msgCanvas[0].getContext("2d");
                    ctx.clearRect(0, 0, this.options.bgWidth / 2, this.options.barHeight);
                    var font = 'italic small-caps bold {0}px microsoft yahei';
                    ctx.font = font.replace("{0}", this.msgFontsize);
                    ctx.fillStyle = this.code_color[1];
                    ctx.fillText(msg2, 0, this.options.barHeight / 2 + this.msgFontsize / 2);
                } else {
                    var msgImage = this.htmlDoms.ele_msgCanvas[0];
                    msgImage.src = this.options.msgImageUrl;
                }
            } else {
                this.htmlDoms.ele_msgLeft.css({'width': '100%', 'text-align': 'center', 'margin-left': ''});
                this.htmlDoms.ele_msgCanvas.css({'display': 'none'});
                this.htmlDoms.ele_msgLeft.text(msg1);
            }
        },
        //设置用户是否可以操作
        setUserCanOperation: function (isCan) {
            if (isCan) {
                //点击事件比对
                this.htmlDoms.ele_refresh.show();
            } else {
                this.htmlDoms.ele_refresh.hide();
            }
            this.userIsCan = isCan;
        },
        // 生成随机数
        generateRandom32Digits: function() {
            let result = '';
            const characters = '0123456789'; // 包含数字 0-9 的字符集
            for (let i = 0; i < 32; i++) {
                const randomIndex = Math.floor(Math.random() * characters.length);
                result += characters.charAt(randomIndex);
            }
            return result;
        },
        // 异或操作
        xorStrings:function(str1, str2) {
            const sb = [];
            const segmentLength = str1.length / 8; // 每个段的长度
            for (let i = 0; i < 8; i++) {
                // 计算子字符串的开始和结束索引
                const startIndex = i * segmentLength;
                const endIndex = (i + 1) * segmentLength;
                // 截取子字符串
                const segment1 = str1.substring(startIndex, endIndex);
                const segment2 = str2.substring(startIndex, endIndex);
                // 将子字符串转换为整数
                const intValue1 = parseInt(segment1);
                const intValue2 = parseInt(segment2);
                //console.log("intValue1: " + intValue1 + "+" + intValue2);
                const all = intValue1 ^ intValue2;
                //console.log("异或以后的值：" + all);
                sb.push(all);
            }
            let result = sb.join("");
            if (result.length < 32) {
                while (result.length < 32) {
                    result += "0";
                }
            } else if (result.length > 32) {
                result = result.substring(0, 32);
            }
            return result;
        },
        //设置点选 刷新 响应事件
        setUserEvent: function () {
            var _this = this;
            //点击事件比对
            console.log("608")
            _this.htmlDoms.ele_panel.on('click', function (e) {
                if (!_this.userIsCan) return;

                var pos = _this.getMousePos(this, e);
                var indexPos = _this.pointChoosed(pos);
                if (indexPos >= 0) {
                    _this.deletePoint(indexPos);
                } else {
                    _this.choosePosList.push(pos);
                    _this.createPoint(pos);
                }
                if (indexPos < 0 && _this.choosePosList.length == 1) {//是 添加选点 并且选点列表中仅一个元素
                    _this.startTime = new Date().getTime();
                }

                if (_this.choosePosList.length >= _this.checkNum) {
                    try {
                        if (!_this.options.sendData) {
                            console.error('sendData is must');
                            return;
                        }
                        var totalTime = new Date().getTime() - _this.startTime;
                        var successMsg = Math.round(totalTime / 100) / 10 + _this.options.message.finish;
                        // var jsonRes = JSON.stringify(_this.choosePosList);
                        _this.setUserCanOperation(false);
                        _this.setMsgShowText(_this.options.message.checking);
                        if (_this.isPhone()) {
                            try {
                                var sensorData = sensor.getData();
                                sensor.destroySensor();
                            } catch (error) {
                                console.error('sensor get info error');
                            }
                        }
                        _this.lifeCycleB = new Date().getTime();
                        if(_this.lifeCycleB <= _this.lifeCycleA || (_this.lifeCycleB - _this.lifeCycleA) < 1000){
                            _this.lifeCycleA = 0;
                            _this.lifeCycleB = 0;
                        }
                        var resData = {
                            deviceInfo: _this.options.useDeviceInfo ? _this.getEquipmentFinger() : undefined,
                            mouseInfo: _this.getMouseTrack(),
                            motion: _this.isPhone() ? sensorData : undefined,
                            isMobile: _this.isPhone(),
			                isWebDriver: _this.getWebDriver(),
                            captchaInfo: _this.choosePosList,
                            captchaType: 'point_check',
                            lifeCycleStart: _this.lifeCycleA,
                            lifeCycleEnd: _this.lifeCycleB
                        }
                        resData = JSON.stringify(resData);
                        var rsaParams = {};
                        // console.log("resData = " + resData);
                        /* if (_this.options.useDES3) {
                             resData = _this.DES3encrypt(_this.createKey(_this.options.clientID, _this.keys), resData);
                         }*/
                        var keys = [_this.options.clientID];
                        switch (_this.options.crypto_kind) {
                            case 0:
                                resData = _this.DES3encrypt(_this.createKey(_this.options.clientID, _this.keys), resData);
                                break;
                            case 1://SM4

                                resData = crypto_api.sm4_encrypt_ecb(resData, /*"1234567890abcdef"*/_this.getGmFaKey(keys,_this.keys));
                                break;
                            case 2://AES
                                //   resData = crypto_api.aes_encrypt_ecb(resData, "6D6EEA0E029A3C3A"/*_this.createAES_SM4Key()*/);
                            {
                                const cr = _this.generateRandom32Digits();
                                if (_this.options.crypto_kind == 2 && _this.publicKeyModulus !== undefined && _this.publicKeyExponent !== undefined) {
                                    setMaxDigits(512);
                                    var key = new RSA2048KeyPair(_this.publicKeyExponent,"",_this.publicKeyModulus);
                                    //pub加密sr cr
                                    rsaParams = {
                                        sr: encryptedString(key,_this.sr),
                                        cr: encryptedString(key, cr),
                                    }
                                    // 将公钥加密的数据转为json
                                    rsaParams = JSON.stringify(rsaParams);
                                    // console.log("验证参数json未加密===2:",rsaParams);
                                    // console.log("验证参数json未加密===2:",resData);
                                }
                                //获取到服务器的SR，此时生成js的CR
                                const xorStr = _this.xorStrings(_this.sr,cr);
                                resData = crypto_api.aes_encrypt_cbc(resData,xorStr)
                            }
                                break;
                        }
                        //console.log("***************************************************");
                        //console.log("resData = " + resData);

                        var allParams = {};
                        if (_this.options.crypto_kind == 2) {
                            allParams = {
                                "rsaParams":rsaParams,
                                "resData":resData
                            }
                            allParams = JSON.stringify(allParams);
                            resData = allParams;
                        }else {
                            resData = resData;
                        }
                        console.log("提交的数据",resData);
                        _this.options.sendData(resData, function (res) {
                            var resObj = {
                                Data: 'success'
                            }
                            if (res == 'SUCCESS') {
                                resObj.Data = 'success';
                            } else if (res == 'ERROR_1') {
                                resObj.Data = 'fail';
                            } else if (res == 'ERROR_2') {
                                resObj.Data = 'forbid';
                            } else {
                                resObj.Data = 'forbid';
                            }
                            // var resJson = JSON.stringify(resObj);

                            try {
                                // var resObj = JSON.parse(res);
                                var flag = resObj.Data;
                            } catch (error) {
                                console.error('analysis server data');
                                console.log(error);
                                return;
                            }
                            _this.checkSuccessOrFail(flag, successMsg);
                        });
                    } catch (error) {
                        console.error('sendData error');
                        console.log(error);
                    }
                }
            });
            //刷新
            // _this.htmlDoms.ele_refresh.show();
            _this.htmlDoms.ele_refresh.on('click', function () {
                // if (!_this.userIsCan) return;
                _this.refresh();
            });
            // } else {
            // 	// _this.htmlDoms.ele_refresh.hide();
            // 	_this.htmlDoms.ele_refresh.unbind('click');
            // 	_this.htmlDoms.ele_panel.unbind('click');
            // }

            
        },
        //更新背景图片
        updateBGImage: function (imgUrl, msgImageUrl) {
            try {
                var _this = this;
                // var img = new Image();

                // img.src = imgUrl;
                // 加载完成开始绘制
                _this.drawImage_NoCanvas(imgUrl, msgImageUrl);
                _this.lifeCycleA = new Date().getTime();
//                if (!_this.options.useCanvas) {
//                    _this.drawImage_NoCanvas(img);
//                } else {
//                    if (img.complete) {
//                        _this.drawImage(img);
//                    } else {
//                        $(img).on('load', function (e) {
//                            _this.drawImage(this);
//                            // _this.showLoading(false);
//                        });
//                    }
//                }
            } catch (error) {
                console.error('update image error');
                console.log(error);
            }
        },

        //根据从服务器获取的数据 更新界面
        updateDataFromServer: function () {
            try {
                if (!this.options.requestData) {
                    console.error('requestData is must');
                    return;
                }
                this.errorNum = 0;
                this.setUserCanOperation(false);
                this.setLoadMessage(this.options.message.loading);
                this.setMsgShowText(this.options.message.loading);
                var paramObj = {
                    width: this.options.bgWidth,
                    height: this.options.bgHeight
                }
                var _this = this;
                this.options.requestData(paramObj, function (res) {
                    console.log("组件 requesetdata",paramObj);
                    console.log("组件 requesetdata",res);
                    _this.analysisParam(res);

                    //_this.initWordList();
                    _this.showLoading(false);
                    _this.updateBGImage(_this.options.imageUrl, _this.options.msgImageUrl);
                    _this.setUserCanOperation(true);
                    _this.setUserOperationMsg();

                    try {
                        _this.options.ready();
                    } catch (error) {
                        console.error('ready error');
                        console.log(error);
                    }
                }, function (error) {
                    _this.setLoadMessage(this.options.message.error);
                    _this.setMsgShowText(this.options.message.error);
                });
            } catch (error) {
                console.error('requestData error');
                console.log(error);
            }
        },

        //解析从服务器获取的参数
        analysisParam: function (res) {
            try {
                var jsonData = JSON.parse(res);
                //console.log("jsondata===:",jsonData);
                //console.log("jsonData " + jsonData.data);
                var keys = [this.options.clientID];
                //console.log(this.options.clientID);
                switch (this.options.crypto_kind) {
                    case 0:
                        //3des
                        jsonData.data = this.DES3decrypt(this.createKey(this.options.clientID), jsonData.data);
                        break;
                    case 1:
                        //sm4
                        jsonData.data = crypto_api.sm4_decrypt_ecb(jsonData.data, /*"1234567890abcdef"*/this.getGmFaKey(keys));

                        break;
                    case 2:
                        //aes
                        jsonData.data = jsonData.data;
                        break;
                
                }
                console.log("jsonData.data = " + jsonData.data);
                jsonData.data = JSON.parse(jsonData.data);
            } catch (error) {
                console.log("error = " + error.toString());
                console.error('JSON error');
                return;
            }
            this.keys = jsonData.data.keys;
            this.picSort = jsonData.data.picSort;
            this.options.imageUrl = jsonData.imageUrl;
            this.options.msgImageUrl = jsonData.msgImageUrl;
            console.log("232323333");
            if (!this.options.imageUrl) {
                console.error("imageUrl is must");
                return;
            }
            if (!this.options.msgImageUrl && this.options.tipCanvas && !this.options.useCanvas) {
                console.error("msgImageUrl is must");
                return;
            }
            this.checkNum = 0;
            var jsonObjArray = [];
            var _this = this;
            var textH = this.options.wordProperty.textH[1] / 2;
            // jsonData.pointArray
            // jsonData.pointArray.forEach(function(word) {
            console.log("877")
            for (var i = 0; i < jsonData.data.pointArray.length; i++) {
                var word = jsonData.data.pointArray[i];
                if (this.options.useCanvas) {
                    if (_this.options.bgHeight - textH < word.pointY || textH > word.pointY ||
                        _this.options.bgWidth - textH < word.pointX || textH > word.pointX) {
                        console.error('point out of boundary' + word.txt + '(' + word.pointX + ',' + word.pointY + ')');
                    }
                }
                var obj = {
                    isUse: word.isCheck == 1,
                    posx: word.pointX,
                    posy: word.pointY,
                    text: word.txt
                }
                jsonObjArray.push(obj);

                _this.checkNum = obj.isUse ? _this.checkNum + 1 : _this.checkNum;
            }
            ;
            console.log("897");
            console.log(jsonObjArray);
            this.options.wordList = jsonObjArray;
            if (this.options.crypto_kind == 2) {
                this.sr = jsonData.data.sr;
                this.publicKeyExponent = jsonData.data.publicKeyExponent;
                this.publicKeyModulus = jsonData.data.publicKeyModulus;
            }
        },
        //判断一个点是否已经被选中
        pointChoosed: function (pos) {
            for (var i = 0; i < this.choosePosList.length; i++) {
                if (Math.abs(pos.x - this.choosePosList[i].x) < this.options.pointH / 3 * 2 &&
                    Math.abs(pos.y - this.choosePosList[i].y) < this.options.pointH / 3 * 2) {
                    return i;
                }
            }
            ;
            return -1;
        },
        //验证成功或失败的动作
        checkSuccessOrFail: function (res, successMsg) {
            if (res == 'success') {	//验证成功
                //this.htmlDoms.ele_track.css({'color': '#4cae4c', 'border-color': '#5cb85c'});
                this.htmlDoms.ele_track.css({'background-color': this.options.trackColor});
                this.setMsgShowText(successMsg + ',' + this.options.message.success);
            } else if (res == 'fail') {	//验证失败
                //this.htmlDoms.ele_track.css({'color': '#d9534f', 'border-color': '#d9534f'});
                this.htmlDoms.ele_track.css({'background-color': this.options.trackColor});
                this.setMsgShowText(this.options.message.fail);
            } else {
                //this.htmlDoms.ele_track.css({'color': '#d953ff', 'border-color': '#d953ff'});
                this.htmlDoms.ele_track.css({'background-color': this.options.trackColor});
                this.setMsgShowText(this.options.message.forbidden);
            }

            try {
                this.options.checkResult(res);
            } catch (error) {
                console.error('checkResult error');
                console.log(error);
            }
            if (res == 'success') {
                //成功时 什么都不做
            } else {
                this.errorNum = this.errorNum + 1;
                var _this = this;
                setTimeout(function () {
                    _this.htmlDoms.ele_track.css({'color': '#000', 'border-color': '#ddd'});
                    //_this.htmlDoms.ele_track.css({'background-color': this.options.trackColor});
                    if (_this.options.needAgainNum <= _this.errorNum) {
                        _this.refresh();
                    } else {
                        _this.deletePoint(0);
                        _this.setUserOperationMsg();
                        _this.setUserCanOperation(true);
                    }
                }, 1000);
            }
        },

        //如果没有传文字，随机选择几个文字
        initWordList: function () {
            if (this.options.wordList.length > 0) {
                return;
            }
            var avg = Math.floor(parseInt(this.options.bgWidth) / (parseInt(this.defaultNum) + 1));
            var fontStr = '天地玄黄宇宙洪荒日月盈昃辰宿列张寒来暑往秋收冬藏闰余成岁律吕调阳云腾致雨露结为霜金生丽水玉出昆冈剑号巨阙珠称夜光果珍李柰菜重芥姜海咸河淡鳞潜羽翔龙师火帝鸟官人皇始制文字乃服衣裳推位让国有虞陶唐吊民伐罪周发殷汤坐朝问道垂拱平章爱育黎首臣伏戎羌遐迩体率宾归王';	//不重复的汉字
            var fontChars = [];
            for (var i = 1; i <= this.defaultNum; i++) {
                var text = this.getChars(fontStr, fontChars);
                var tmp_index = Math.floor(Math.random() * 3);

                if (Math.floor(Math.random() * 2) == 1) {
                    var tmp_y = Math.floor(parseInt(this.options.bgHeight) / 2) + tmp_index * 20 + 20;
                } else {
                    var tmp_y = Math.floor(parseInt(this.options.bgHeight) / 2) - tmp_index * 20;
                }
                var tmp_x = avg * i;
                fontChars.push({
                    text: text,
                    posx: tmp_x,
                    posy: tmp_y,
                    isUse: i == 2
                });
            }
            this.options.wordList = fontChars;
        },

        createCanvas: function (w, h) {
            var canvas = document.createElement("canvas");
            canvas.width = w;
            canvas.height = h;
            return canvas;
        },
        drawCaptchaCutting: function (imageT, pics){
            //console.log("drawCaptchaCutting:" + pics);
            //console.log("drawCaptchaCutting-length:" + pics.length);
            var sourceCanvas = this.createCanvas(this.options.bgWidth, this.options.bgHeight);
            var sctx = sourceCanvas.getContext('2d');
            var pixelWidth = this.options.bgWidth;
            var pixelHeight = this.options.bgHeight;
            var imgSheetWidth = pixelWidth/pics.length;
            var imgSheetHeight = pixelHeight;
            for(var i=0; i<pics.length; i++){
                var loca = imgSheetWidth*pics[i];
                //console.log("loca1" + i + "-" + loca1);
                //console.log("loca2" + i + "-" + loca2);
                //console.log("loca" + i + "-" + loca);
                sctx.drawImage(imageT,imgSheetWidth*i,0,imgSheetWidth,pixelHeight,loca,0,imgSheetWidth,imgSheetHeight);
            }
            var imgDataUrl = sourceCanvas.toDataURL();
            var canvasbox = document.getElementById('verify-canvas');
            canvasbox.src = imgDataUrl;
            canvasbox.className = "verify-background-size";

            // this.captchaDOM.canvas.src = imgDataUrl;
        },
        //绘制合成的图片
        drawImage_NoCanvas: function (imgUrl, msgImageUrl) {
            if(this.options.useCanvas){
                var pics = this.picSort;
                if(pics == undefined || pics == null){
                    var canvasbox = document.getElementById('verify-canvas');
                    canvasbox.src = imgUrl;
                    canvasbox.className = "verify-background-size";
                } else {
                    var _this = this;
                    var imageBg = new Image();
                    imageBg.src = imgUrl;
                    imageBg.onload = function(){
                        _this.drawCaptchaCutting(imageBg, pics);
                    };
                }
                
            } else {
                var canvasbox = document.getElementById('verify-canvas');
                canvasbox.src = imgUrl;
                canvasbox.className = "verify-background-size";
            }


            var canvasmsg = document.getElementById('verify-msg-canvas');
            canvasmsg.src = msgImageUrl;

            // var canvasbox = document.getElementById('verify-canvas');
            // canvasbox.src = this.options.imageUrl;
            // canvasbox.className = "verify-background-size";
            // var canvasmsg = document.getElementById('verify-msg-canvas');
            // canvasmsg.src = this.options.msgImageUrl;
            // canvasmsg.className = "verify-background-size";
        },
        setUserOperationMsg: function () {
            var msgStr = '';
            for (var i = 0; i < this.options.wordList.length; i++) {
                if (this.options.wordList[i].isUse) {
                    msgStr += this.options.wordList[i].text + ',';
                }
            }
            if (this.options.tipCanvas) {
                this.setMsgShowText(this.options.message.tip, '【' + msgStr.substring(0, msgStr.length - 1) + '】');
                // this.htmlDoms.ele_msgLeft.text('请顺序点击【' + msgStr.substring(0,msgStr.length-1) + '】');
            } else {
                //this.setMsgShowText(this.options.message.tip);
                //this.htmlDoms.ele_msgLeft.css({'width': '', 'margin-left': '20%'});
                //this.htmlDoms.ele_msgCanvas.css({'display': '', 'margin-top': '-8px'});
                //this.htmlDoms.ele_msgRight.css({'float': 'left'});
                //this.setMsgShowText(this.options.message.tip + '【' + msgStr.substring(0,msgStr.length-1) + '】');
                // this.setMsgShowText('请按语序点击下图文字');
                if (this.options.useIdiom){
                    this.setMsgShowText('请按【成语语序】依次点击文字'); 
                } else{
                    this.setMsgShowText(this.options.message.tip);
                    this.htmlDoms.ele_msgLeft.css({'width': '', 'margin-left': '20%'});
                    this.htmlDoms.ele_msgCanvas.css({'display': '', 'margin-top': '-8px'});
                    this.htmlDoms.ele_msgRight.css({'float': 'left'});
                }
            }
        },

        //获取坐标
        getMousePos: function (obj, event) {
            var e = event || window.event;
            var scrollX = document.documentElement.scrollLeft || document.body.scrollLeft;
            var scrollY = document.documentElement.scrollTop || document.body.scrollTop;
            var x = e.clientX - ($(obj).offset().left - $(window).scrollLeft());
            var y = e.clientY - ($(obj).offset().top - $(window).scrollTop());
            return {'x': x, 'y': Math.round(y)};
        },

        //递归去重
        getChars: function (fontStr, fontChars) {
            var tmp_rand = parseInt(Math.floor(Math.random() * fontStr.length));
            if (tmp_rand > 0) {
                tmp_rand = tmp_rand - 1;
            }

            var tmp_char = fontStr.charAt(tmp_rand);
            if ($.inArray(tmp_char, fontChars) == -1) {
                return tmp_char;
            } else {
                return ICBCPointCaptcha.prototype.getChars(fontStr, fontChars);
            }
        },

        //洗牌数组
        shuffle: function (arr) {
            var m = arr.length, i;
            var tmpF;
            while (m) {
                i = (Math.random() * m--) >>> 0;
                tmpF = arr[m];
                arr[m] = arr[i];
                arr[i] = tmpF;
                //[arr[m], arr[i]] = [arr[i], arr[m]];	//低版本浏览器不支持此写法
            }
            return arr;
        },

        //创建坐标点
        createPoint: function (pos) {
            var num = this.choosePosList.length;
            var pointHtml = '<div class="verify-area verify-border-radius verify-noselect" style="color:#fff; z-index:9999; text-align:center; position:absolute; border:1.5px solid #ffffff;';
            pointHtml += this.options.pointShape == 'square' ? '' : 'border-radius:50%;';//border-radius:50%;
            pointHtml += 'background-color:' + this.options.pointColor + ';';//background-color:#1abd6c;
            pointHtml += 'width:' + this.options.pointH + 'px;';
            pointHtml += 'height:' + this.options.pointH + 'px;';
            pointHtml += 'line-height:' + this.options.pointH + 'px;';
            pointHtml += 'top:' + parseInt(pos.y - this.options.pointH / 2) + 'px;';
            pointHtml += 'left:' + parseInt(pos.x - this.options.pointH / 2) + 'px;';
            pointHtml += '">' + num + '</div>';
            this.htmlDoms.ele_panel.append(pointHtml);
            // var pointList = document.getElementsByClassName('verify-area');
            // this.setEleCannotselect(pointList[pointList.length-1]);
        },

        //清除坐标点
        deletePoint: function (index) {
            if (index < 0) index = 0;
            for (; this.choosePosList.length >= index + 1;) {
                this.choosePosList.pop();
            }
            var findList = this.$element.find('.verify-area');//document.getElementsByClassName('verify-area');
            for (var i = findList.length - 1; i >= 0; i--) {
                var element = findList[i];
                if (element.innerHTML >= index + 1) {
                    element.parentNode.removeChild(element);
                }
            }
            ;
        },

        //清除所有坐标点
        clearPoint: function () {
            this.$element.find('.verify-area').remove();
        },

        //弹出式
        showImg: function () {
            this.htmlDoms.ele_body.css({'display': 'block'});
        },
        //固定式
        hideImg: function () {
            this.htmlDoms.ele_body.css({'display': 'none'});
        },

        //刷新
        refresh: function () {
            if (this.isPhone()) {
                try {
                    sensor.initSensor();
                    sensor.start();
                } catch (error) {
                    console.error('sensor init error');
                }
            }
            this.deletePoint(0);
            this.clearMouseTrack();

            this.showLoading(true);
            this.updateDataFromServer();
        },
        getWebDriver: function () {
            var res = false;
            try {
                res = window.navigator.webdriver
            } catch (e) {
                console.log("navigator :" + e);
            }
            return res;
        },
        setEleCannotselect: function (element) {
            if (typeof(element.onselectstart) != "undefined") {
                // IE下禁止元素被选取
                element.onselectstart = new Function("return false");
            } else {
                // firefox下禁止元素被选取的变通办法 ---目前用CSS样式控制 不需要这个方法
                // element.onmousedown = new Function("return false");
                // element.onmouseup = new Function("return true");
            }
        }
    };

    if (typeof exports == "object") {
        module.exports = ICBCPointCaptcha;
    } else if (typeof define == "function" && define.amd) {
        define([], function () {
            return ICBCPointCaptcha;
        });
    } else if (window) {
        window.ICBCPointCaptcha = ICBCPointCaptcha;
    }

    // //在插件中使用clickVerify对象
    // $.fn.ICBCPointCaptcha = function(divID, options) {
    // 	var points = new Points(divID, options);
    // 	points.init();
    // };
})(jQuery, window, document);
