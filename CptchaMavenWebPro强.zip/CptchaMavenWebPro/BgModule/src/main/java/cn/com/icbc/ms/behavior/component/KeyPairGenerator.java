package cn.com.icbc.ms.behavior.component;
import cn.com.icbc.ms.behavior.base.bean.KeyPairInfo;
import cn.com.icbc.ms.behavior.utils.StringUtils;
import cn.com.icbc.ms.behavior.utils.SysLog;

import java.security.*;
import java.security.interfaces.RSAPublicKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.RSAPublicKeySpec;
import java.security.spec.RSAPrivateKeySpec;
import javax.crypto.Cipher;
import java.math.BigInteger;

public class KeyPairGenerator {
    private String algorithm;
    private KeyPairInfo keyPairInfo;
    public KeyPairInfo getKeyPairInfo() {
        return keyPairInfo;
    }
    private KeyPairGenerator(){}
    private KeyPairGenerator(KeyPairInfo keyPairInfo) {
        this.algorithm = keyPairInfo.getAlgorithm();
        this.keyPairInfo = keyPairInfo;
    }
    public static KeyPairGenerator createKeyPairGenerator(KeyPairInfo keyPairInfo) {
        if (keyPairInfo == null || keyPairInfo.getAlgorithm() == null) {
            return null;
        }
        if (!keyPairInfo.getAlgorithm().equals("RSA")) {
            return null;
        }
        return new KeyPairGenerator(keyPairInfo);
    }
    /*
     * 使用模数和指数值创建公钥
     * */
    public RSAPublicKey createPublicKey(String modulus, String exponent) {
        if ("RSA".equalsIgnoreCase(algorithm)) {
            try {
                // 将十六进制字符串解码为字节数组
                byte[] modulusBytes = new BigInteger(modulus, 16).toByteArray();
                byte[] exponentBytes = new BigInteger(exponent, 16).toByteArray();
                BigInteger modulusBigInt = new BigInteger(modulusBytes);
                BigInteger exponentBigInt = new BigInteger(exponentBytes);
                KeyFactory keyFactory = KeyFactory.getInstance("RSA");
                RSAPublicKeySpec keySpec = new RSAPublicKeySpec(modulusBigInt, exponentBigInt);
                return (RSAPublicKey) keyFactory.generatePublic(keySpec);
            } catch (Exception e) {
                SysLog.println("create public key failure:" + e.toString());
                return null;
            }
        }
        return null;
    }
    /*
     * 使用模数和指数值创建私钥
     * */
    public RSAPrivateKey createPrivateKey(String modulus, String exponent) {
        if ("RSA".equalsIgnoreCase(algorithm)) {
            try {
                byte[] modulusBytes = new BigInteger(modulus, 16).toByteArray();
                byte[] exponentBytes = new BigInteger(exponent, 16).toByteArray();
                BigInteger modulusBigInt = new BigInteger(modulusBytes);
                BigInteger exponentBigInt = new BigInteger(exponentBytes);
                KeyFactory keyFactory = KeyFactory.getInstance("RSA");
                RSAPrivateKeySpec keySpec = new RSAPrivateKeySpec(modulusBigInt, exponentBigInt);
                return (RSAPrivateKey) keyFactory.generatePrivate(keySpec);
            } catch (Exception e) {
                SysLog.println("create private key failure:" + e.toString());
                return null;
            }
        }
        return null;
    }
    /*
     * 使用RSA私钥解密数据
     * 填充方式通常在执行加密和解密操作时指定，而不是在生成密钥对时指定。
     * */
    public static byte[] decryptWithRSA(PrivateKey privateKey, byte[] encryptedData) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        return cipher.doFinal(encryptedData);
    }
    /*
     * 字符串分组执行异或操作
     * */
    public static String xorStrings(String str1, String str2) {
        if (StringUtils.isEmpty(str1) || StringUtils.isEmpty(str2)) return "";
        if (str1.length() != 32 || str2.length() != 32) return "";
        StringBuilder sb = new StringBuilder();
        int segmentLength = str1.length() / 8; // 每个段的长度
        for (int i = 0; i < 8; i++) {
            int startIndex = i * segmentLength;
            int endIndex = (i + 1) * segmentLength;
            String segment1 = str1.substring(startIndex, endIndex);
            String segment2 = str2.substring(startIndex, endIndex);
            int intValue1 = Integer.parseInt(segment1);
            int intValue2 = Integer.parseInt(segment2);
            int all = intValue1 ^ intValue2;
            sb.append(all);
        }
        String result = sb.toString();
        if (result.length() < 32) {
            while (result.length() < 32) {
                result += "0";
            }
        } else if (result.length() > 32) {
            result = result.substring(0, 32);
        }
        return result;
    }
}
