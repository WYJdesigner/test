/**
* @author Dabing
* @E-mail chenbinging@outlook.com
* @date 2018-10-30下午5:24:11
* 浏览器信息验证
*/
package cn.com.icbc.ms.behavior.utils;

import cn.com.icbc.ms.behavior.base.bean.BrowserBean;

import com.alibaba.fastjson.JSONObject;

public class BrowserUtils {

	public boolean verifyInfo(String data) {
		int x = 0;
		if (StringUtils.isEmpty(data)) {
			return false;
		}
//		ArrayList<softInfo> list = JSONObject.parseObject(jsonData, new TypeReference<ArrayList<softInfo>>() {});
		SysLog.println("browser:" + data);
		BrowserBean browserInfo = JSONObject.parseObject(data, BrowserBean.class);
		if(checkUserAgent(browserInfo.getUser_agent())) {
			SysLog.println("checkUserAgent");
			x += 10;
		}
		if(checkLanguage(browserInfo.getLanguage())) {
			SysLog.println("checkLanguage");
			x += 10;
		}
		if(checkTimeOffset(browserInfo.getTimezone_offset())) {
			SysLog.println("checkTimeOffset");
			x += 10;
		}
		if(checkAddBehavior(browserInfo.getAdd_behavior())) {
			SysLog.println("checkAddBehavior");
			x += 10;
		}
		if(checkCpuClass(browserInfo.getCpu_class())) {
			SysLog.println("checkCpuClass");
			x += 10;
		}
		/*if(checkPlugins(browserInfo.getRegular_plugins())) {
			x += 10;
		}*/
		if(checkColorDepth(browserInfo.getColor_depth())) {
			SysLog.println("checkColorDepth");
			x += 10;
		}
		if(checkResolution(browserInfo.getResolution())) {
			SysLog.println("checkResolution");
			x += 10;
		}
		if(checkNavigatorPlatform(browserInfo.getNavigator_platform())) {
			SysLog.println("checkNavigatorPlatform");
			x += 10;
		}
		if(checkDoNotTrack(browserInfo.getDo_not_track())) {
			SysLog.println("checkDoNotTrack");
			x += 10;
		}
		if(checkStorage(browserInfo.getSession_storage(), browserInfo.getLocal_storage(), browserInfo.getIndexed_db(), browserInfo.getOpen_database())) {
			SysLog.println("checkStorage");
			x += 10;
		}
		if ( x >= 20) {
			return false;
		} else {
			return true;
		}
	}
	
	private boolean checkUserAgent(String data) {
		if (StringUtils.isEmpty(data)) {
			return true;
		} else {
			String mozilla = data.substring(0, 8);
			if (mozilla.equals("Mozilla/")) {
				String mozillaVersion = data.substring(8, 11);
				float v = Float.valueOf(mozillaVersion);
				if (v >= 4.0) {
					return false;
				} else {
					return true;
				}
			} else {
				return true;
			}
		}
	}
	
	private boolean checkLanguage(String data) {
		if (StringUtils.isEmpty(data)) {
			return true;
		} else {
			return false;
		}
	}
	
	private boolean checkTimeOffset(int timeOffset) {
		if (timeOffset < -540 && timeOffset > -360) {
			return true;
		} else {
			return false;
		}
	}
	
	private boolean checkAddBehavior(int i) {
		if (i != 0) {
			return true;
		} else {
			return false;
		}
	}
	
	private boolean checkCpuClass(String data) {
		if (StringUtils.isEmpty(data)) {
			return true;
		} else {
			return false;
		}
	}
	
	private boolean checkNavigatorPlatform(String data) {
		if (StringUtils.isEmpty(data)) {
			return true;
		} else {
			if (data.equals("Win32") || data.equals("Win64") || data.equals("iPhone") || data.contains("Linux")) {
				return false;
			} else {
				return false;
			}
		}
	}
	
	private boolean checkDoNotTrack(String data) {
		if (StringUtils.isEmpty(data)) {
			return true;
		} else {
			return false;
		}
	}
	
	private boolean checkPlugins(String data) {
		if (StringUtils.isEmpty(data)) {
			return true;
		} else {
			return false;
		}
	}
	
	private boolean checkColorDepth(int i) {
		if (i != 16 && i != 24 && i != 32) {
			return true;
		} else {
			return false;
		}
	}
	
	private boolean checkResolution(String data) {
		if (StringUtils.isEmpty(data)) {
			return true;
		} else {
			return false;
		}
	}
	
	private boolean checkStorage(int sessionStorage, int localStorage, int indexedDb, int openDatabase) {
		if (sessionStorage == 0 || sessionStorage == 1) {
			if (localStorage == 0 || localStorage == 1) {
				if (indexedDb == 0 || indexedDb == 1) {
					if (openDatabase == 0 || openDatabase == 1) {
						return false;
					} else {
						return true;
					}
				} else {
					return true;
				}
			} else {
				return true;
			}
		} else {
			return true;
		}
		
	}
}
