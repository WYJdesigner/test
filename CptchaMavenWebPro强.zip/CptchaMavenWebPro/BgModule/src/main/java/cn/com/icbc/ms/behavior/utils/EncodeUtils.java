/**
* @author Dabing
* @E-mail chenbinging@outlook.com
* @date 2018-12-7下午5:49:36
* 加密工具类
*/
package cn.com.icbc.ms.behavior.utils;

import java.security.*;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class EncodeUtils {
	static {
		Security.addProvider(new BouncyCastleProvider());
	}
	/*
	* 作用：对输入的字符串进行 SHA-256 散列加密。
	* 操作步骤：
	* 使用 MessageDigest 获取 SHA-256 加密实例。
	* 将输入的字符串转换为 UTF-8 编码的字节数组。
	* 对字节数组进行 SHA-256 散列加密。
	* 返回值：返回加密后的字节数组。
	* */
	public static byte[] encryptBySha(String str) {
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] bts = digest.digest(str.getBytes("UTF-8"));
			return bts;
		} catch (Exception e) {
		}
		return null;
	}
	/*
	* 作用：使用 3DES（Triple DES）算法以 ECB 模式对字节数组进行加密。
	* 操作步骤：
	* 生成 3DES 密钥，使用 keyStr 字节数组。
	* 获取 3DES 加密实例，使用 ECB 模式和 PKCS5Padding 填充方式。
	* 使用密钥初始化加密实例。
	* 对输入的字节数组进行加密操作。
	* 返回值：返回加密后的字节数组。
	* */
	public static byte[] encryptBy3DesECB(byte[] keyStr, byte[] src) {
		try {
			// 生成密钥
			SecretKey deskey = new SecretKeySpec(keyStr, "DESede");
			// 加密
			Cipher c1 = Cipher.getInstance("DESede/ECB/PKCS5Padding");
			c1.init(Cipher.ENCRYPT_MODE, deskey);
			return c1.doFinal(src);// 在单一方面的加密或解密
		} catch (Exception e) {
		}
		return null;
	}
	/*
	* 作用：使用 3DES（Triple DES）算法以 CBC 模式对字节数组进行加密。
	* 操作步骤：
	* 生成 3DES 密钥，使用 keyStr 字节数组。
	* 获取 3DES 加密实例，使用 CBC 模式、PKCS5Padding 填充方式，以及初始化向量（IV）参数。
	* 使用密钥和初始化向量初始化加密实例。
	* 对输入的字节数组进行加密操作。
	* 返回值：返回加密后的字节数组。
	* */
	public static byte[] encryptBy3DesCBC(byte[] keyStr, byte[] src) {
		try {
			// 生成密钥
			SecretKey deskey = new SecretKeySpec(keyStr, "DESede");
			// 加密
			Cipher c1 = Cipher.getInstance("DESede/CBC/PKCS5Padding");
			IvParameterSpec spec = new IvParameterSpec("12345678".getBytes());
			c1.init(Cipher.ENCRYPT_MODE, deskey, spec);
			return c1.doFinal(src);// 在单一方面的加密或解密
		} catch (Exception e) {
		}
		return null;
	}
	/*
	* 作用：使用 3DES（Triple DES）算法以 ECB 模式对字节数组进行解密。
	* 操作步骤：
	* 生成 3DES 密钥，使用 keybyte 字节数组。
	* 获取 3DES 解密实例，使用 ECB 模式和 PKCS5Padding 填充方式。
	* 使用密钥初始化解密实例。
	* 对输入的字节数组进行解密操作。
	* 返回值：返回解密后的字节数组。
	* */
	public static byte[] decryptBy3DesECB(byte[] keybyte, byte[] src) {
		try {
			// 生成密钥
			SecretKey deskey = new SecretKeySpec(keybyte, "DESede");
			// 解密
			Cipher c1 = Cipher.getInstance("DESede/ECB/PKCS5Padding");
			c1.init(Cipher.DECRYPT_MODE, deskey);
			return c1.doFinal(src);
		} catch (Exception e) {
		}
		return null;
	}

	/*
	* 作用：使用 3DES（Triple DES）算法以 CBC 模式对字节数组进行解密。
	* 操作步骤：
	* 生成 3DES 密钥，使用 keybyte 字节数组。
	* 获取 3DES 解密实例，使用 CBC 模式、PKCS5Padding 填充方式，以及初始化向量（IV）参数。
	* 使用密钥和初始化向量初始化解密实例。
	* 对输入的字节数组进行解密操作。
	* 返回值：返回解密后的字节数组。
	* */
	public static byte[] decryptBy3DesCBC(byte[] keybyte, byte[] src) {
		try {
			// 生成密钥
			SecretKey deskey = new SecretKeySpec(keybyte, "DESede");
			// 解密
			Cipher c1 = Cipher.getInstance("DESede/CBC/PKCS5Padding");
			IvParameterSpec spec = new IvParameterSpec("12345678".getBytes());
			c1.init(Cipher.DECRYPT_MODE, deskey, spec);
			return c1.doFinal(src);
		} catch (Exception e) {
		}
		return null;
	}

	/*
	* 作用：将字节数组转换为 Base64 编码的字符串。
	* 操作步骤：
	* 使用 Base64.encode 方法将字节数组进行 Base64 编码。
	* 将编码后的字节数组转换为字符串。
	* 返回值：返回 Base64 编码的字符串。
	* */
	public static String encode2Base64(byte[] bytes) {
		byte[] bts = Base64.encode(bytes);
		return new String(bts);
	}

	/*
	* 作用：将 Base64 编码的字符串解码为字节数组。
	* 操作步骤：
	* 将输入的 Base64 编码的字符串转换为字节数组。
	* 使用 Base64.decode 方法将字符串解码为字节数组。
	* 返回值：返回解码后的字节数组。
	* */
	public static byte[] decode2Base64(String str) {
		byte[] bts = Base64.decode(str);
		return bts;
	}


	/*aes*/
	private static final String DESV = "aaaaaaaa";

	/**
	 * Aes加密算法
	 *
	 * @param mode
	 *            加密长度
	 * @param content
	 *            需要加密的字符串
	 * @param password
	 *            密钥信息
	 * @return
	 */
	public static byte[] encryptByAesECB(String content,
										 byte[] password) {

		// 创建AES的key生产者
		try {
			// 转换为AES专用的密钥
			SecretKeySpec spec = new SecretKeySpec(password, "AES");
			// 创建密码器
			Cipher cipher = Cipher.getInstance("AES/ECB/NoPadding");
			// 初始化为加密模式的密码器
			cipher.init(Cipher.ENCRYPT_MODE, spec);
			byte[] btsContent = content.getBytes("utf-8");
			byte[] ret = (byte[]) null;
			int p = 16 - btsContent.length % 16;
			ret = new byte[btsContent.length + p];
			System.arraycopy(btsContent, 0, ret, 0, btsContent.length);
			for (int i = 0; i < p; i++) {
				ret[btsContent.length + i] = (byte) p;
			}
			// 加密
			byte[] btsResp = cipher.doFinal(ret);
			return btsResp;
		} catch (NoSuchAlgorithmException e) {
			SysLog.println(e.toString());
		} catch (NoSuchPaddingException e) {
			SysLog.println(e.toString());
		} catch (InvalidKeyException e) {
			SysLog.println(e.toString());
		} catch (IllegalBlockSizeException e) {
			SysLog.println(e.toString());
		} catch (BadPaddingException e) {
			SysLog.println(e.toString());
		} catch (UnsupportedEncodingException e) {
			SysLog.println(e.toString());
		}

		return null;
	}

	public static byte[] encryptByAesCBC(String content,
										 String password) {

		// 创建AES的key生产者
		try {
			IvParameterSpec ipSc = new IvParameterSpec(
					"1234567890123456".getBytes());

			// 转换为AES专用的密钥
			SecretKeySpec spec = new SecretKeySpec(password.getBytes(), "AES");
			// 创建密码器
//			Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding","BC");
			// 初始化为加密模式的密码器
			cipher.init(Cipher.ENCRYPT_MODE, spec, ipSc);
			byte[] btsContent = content.getBytes("utf-8");
			byte[] ret = (byte[]) null;
			int p = 16 - btsContent.length % 16;
			ret = new byte[btsContent.length + p];
			System.arraycopy(btsContent, 0, ret, 0, btsContent.length);
			for (int i = 0; i < p; i++) {
				ret[btsContent.length + i] = (byte) p;
			}
			// 加密
			byte[] btsResp = cipher.doFinal(ret);
			return btsResp;
		} catch (NoSuchAlgorithmException e) {
			SysLog.println(e.toString());
		} catch (NoSuchPaddingException e) {
			SysLog.println(e.toString());
		} catch (InvalidKeyException e) {
			SysLog.println(e.toString());
		} catch (IllegalBlockSizeException e) {
			SysLog.println(e.toString());
		} catch (BadPaddingException e) {
			SysLog.println(e.toString());
		} catch (UnsupportedEncodingException e) {
			SysLog.println(e.toString());
		} catch (InvalidAlgorithmParameterException e) {
			SysLog.println(e.toString());
		} catch (NoSuchProviderException e) {
			SysLog.println(e.toString());
		}

		return null;
	}

	/**
	 * Aes解密算法
	 *
	 * @param mode
	 *            加密类型
	 * @param btsContent
	 *            需要解密的字符串
	 * @param password
	 *            密钥信息
	 * @return
	 */
	public static byte[] decryptByAesECB(byte[] btsContent,
										 byte[] password) {
		try {
			SecretKeySpec spec = new SecretKeySpec(password, "AES");
			Cipher cipher = Cipher.getInstance("AES/ECB/NoPadding");
			cipher.init(Cipher.DECRYPT_MODE, spec);
			byte[] btsResp = cipher.doFinal(btsContent);
			int a = btsResp.length;
			int b = btsResp[btsResp.length - 1];
			byte[] ret = new byte[a - b];
			for (int i = 0; i < a - b; i++) {
				ret[i] = btsResp[i];
			}

			return ret;
			// return btsResp;
		} catch (NoSuchAlgorithmException e) {
			SysLog.println(e.toString());
		} catch (NoSuchPaddingException e) {
			SysLog.println(e.toString());
		} catch (InvalidKeyException e) {
			SysLog.println(e.toString());
		} catch (IllegalBlockSizeException e) {
			SysLog.println(e.toString());
		} catch (BadPaddingException e) {
			SysLog.println(e.toString());
		}

		return null;
	}

	public static byte[] decryptByAesCBC(byte[] btsContent,
										 String password) {
		try {
			String ss = "1234567890123456";
			IvParameterSpec ipSc = new IvParameterSpec(ss.getBytes());
			SecretKeySpec spec = new SecretKeySpec(password.getBytes(), "AES");
//			Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding","BC");
			cipher.init(Cipher.DECRYPT_MODE, spec, ipSc);
			byte[] btsResp = cipher.doFinal(btsContent);
			return btsResp;
//			System.out.println("308" + btsResp);
//			int a = btsResp.length;
//			System.out.println("310" + a);
//			int b = btsResp[btsResp.length - 1];
//			System.out.println("312" + b);
//			byte[] ret = new byte[a - b];
//			for (int i = 0; i < a - b; i++) {
//				ret[i] = btsResp[i];
//			}
//			return ret;
		} catch (NoSuchAlgorithmException e) {
			SysLog.println(e.toString());
		} catch (NoSuchPaddingException e) {
			SysLog.println(e.toString());
		} catch (InvalidKeyException e) {
			SysLog.println(e.toString());
		} catch (IllegalBlockSizeException e) {
			SysLog.println(e.toString());
		} catch (BadPaddingException e) {
			SysLog.println(e.toString());
		} catch (InvalidAlgorithmParameterException e) {
			SysLog.println(e.toString());
		} catch (NoSuchProviderException e) {
			SysLog.println(e.toString());
		}

		return null;
	}
}

