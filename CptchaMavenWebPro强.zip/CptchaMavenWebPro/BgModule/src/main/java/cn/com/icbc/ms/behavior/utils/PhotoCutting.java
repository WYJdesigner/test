package cn.com.icbc.ms.behavior.utils;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/*
* 用于图像切割的工具类，用于将一张大图切割成多个小图块的功能
* 这个类的主要作用是实现图像切割功能，可以根据需要设置切割的行数、列数和切割类型，
* 然后使用 splitImage 方法进行切割，并得到切割后的小图块。
 * */
public class PhotoCutting {
	/*
	* 这两个私有变量用于存储切割图像的行数和列数，默认值都是1，表示不切割。
	 * */
	private int slice_x = 1;
	private int slice_y = 1;
	/*
	* 私有变量，存储切割类型的值，默认值是0，表示不切割。
	 * */
	private int slice_type = 0;
	/*
	* 私有变量，用于存储切割后小图块的排序号数组，初始化为null。
	* */
	private int[] slice_sort_number = null;

	/*
	* 公共方法，用于获取切割图像的行数。
	* */
	public int getSliceX() {
		return slice_x;
	}
	/*
	* 公共方法，用于设置切割图像的行数。
	* */
	public void setSliceX(int slice_x) {
		this.slice_x = slice_x;
	}
	/*
	* 公共方法，用于获取切割图像的列数。
	* */
	public int getSliceY() {
		return slice_y;
	}
	/*
	* 公共方法，用于设置切割图像的列数。
	* */
	public void setSliceY(int slice_y) {
		this.slice_y = slice_y;
	}
	/*
	* 公共方法，用于获取切割类型。
	* */
	public int getSliceType() {
		return slice_type;
	}
	/*
	* 公共方法，用于获取切割后小图块的排序号数组。
	* */
	public int[] getSliceNum(){
		return slice_sort_number;
	}

	/*
	* 公共方法，用于设置切割类型。
	* */
	/**
	 * type 0代表不切割，1代表切割3等份，2代表切割5等分，3代表切割10等份，4代表切割20等份，5代表切割50等份
	 * @param slice_type
	 */
	public void setSliceType(int slice_type) {
		this.slice_type = slice_type;
	}
	/**
     * 乱序算法（shuffle）
     * @param length
     * @return
     */
	/*
	* 公共方法，实现乱序算法，将传入的 length 参数作为数组长度，生成一个乱序的整数数组。
	* 方法首先创建一个整数数组 iArray，用于存储 0 到 length-1 的整数。
	* 通过 SecureRandom 实例来生成随机数，将数组元素打乱，最终返回一个乱序的整数数组。
	* */
	public int[] shuffleArray(Integer length){
        if(length<=0) return null;
        int[] iArray = new int[length];
        for (int i = 0; i < length; i ++) {
            iArray[i] = i;
        }
        SecureRandom sRandom = null;
        try {
			sRandom = SecureRandom.getInstance("SHA1PRNG");
			for (int j = 0; j < length; j++) {
				// String s = String.valueOf(Math.floor(Math.random()*(j+1)));
				String s = String.valueOf(sRandom.nextDouble() * (j+1));
				int randomIndex = Integer.valueOf(s.substring(0,s.indexOf("."))).intValue() ;
				int temp = iArray[randomIndex];
				iArray[randomIndex] = iArray[j];
				iArray[j] = temp;
			}
			
		} catch (NoSuchAlgorithmException e) {
			SysLog.println(e.toString());
			SysLog.println("Captcha--PhotoCutting--shuffleArray--error==" + e.toString());
		}
        return iArray;
    }
    /*
    * 公共方法，用于将原始图像切割成多个小图块。
	* 方法接受两个参数：originalImg 是要切割的原始图像，sliceNum 是切割后小图块的排序号数组。
	* 方法首先根据 slice_x 和 slice_y 来计算切割后的行数 rows 和列数 cols，以及小图块的宽度和高度。
	* 然后，它根据计算的参数，将原始图像切割成多个小图块，并存储在 imgs 数组中。
	* 根据 sliceNum 数组的排序顺序，将小图块按顺序拼接成一张大图，并返回该大图。
    * */
	public BufferedImage splitImage(BufferedImage originalImg, int[] sliceNum){

        // 读入大图
//        File file = new File(originalImg);
//        FileInputStream fis = new FileInputStream(file);
//        BufferedImage image = ImageIO.read(fis);
    	if(originalImg == null){
    		return null;
    	}
    	
    	if(slice_x == 1 && slice_y == 1){
    		return originalImg;
    	}
        int rows = slice_x;
        int cols = slice_y;
        int chunks = rows * cols;

        // 计算每个小图的宽度和高度
        int chunkWidth = originalImg.getWidth() / cols;
        int chunkHeight = originalImg.getHeight() / rows;

        int count = 0;
        BufferedImage imgs[] = new BufferedImage[chunks];
        for (int x = 0; x < rows; x++) {
            for (int y = 0; y < cols; y++) {
                //设置小图的大小和类型
                imgs[count] = new BufferedImage(chunkWidth, chunkHeight, originalImg.getType());

                //写入图像内容
                Graphics2D gr = imgs[count++].createGraphics();
                gr.drawImage(originalImg, 0, 0,
                        chunkWidth, chunkHeight,
                        chunkWidth * y, chunkHeight * x,
                        chunkWidth * y + chunkWidth,
                        chunkHeight * x + chunkHeight, null);
                gr.dispose();
            }
        }

//        int[] numArray = shuffleArray(imgs.length);
        int[] numArray = sliceNum;
//        for (int t:numArray){
//            System.out.println(t);
//        }
        
        int type = imgs[0].getType();
        //设置拼接后图的大小和类型
        BufferedImage finalImg = new BufferedImage(chunkWidth * cols, chunkHeight * rows, type);
        int num = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                finalImg.createGraphics().drawImage(imgs[numArray[num]], chunkWidth * j, chunkHeight * i, null);
                num++;
            }
        }
        
        // 输出小图
//        for (int i = 0; i < imgs.length; i++) {
//            ImageIO.write(imgs[i], "jpg", new File(cuttingPath + numArray[i] + ".jpg"));
//        }

//        System.out.println("完成分割！");
        return finalImg;
    }
}
