/**
* @author Dabing
* @E-mail chenbinging@outlook.com
* @date 2018-9-13下午5:32:36
* 验证方法类
*/
package cn.com.icbc.ms.behavior.utils;

import java.util.ArrayList;

import cn.com.icbc.ms.behavior.base.PointBean;

public class BehaviorUtils {
	
	private ArrayList<SpeedTimeX> aryListX = new ArrayList<SpeedTimeX>();
	private ArrayList<SpeedTimeY> aryListY = new ArrayList<SpeedTimeY>();
	private ArrayList<Integer> accelerateX = new ArrayList<Integer>();
	private ArrayList<Integer> accelerateY = new ArrayList<Integer>();
	private int len;
	private int offsetX, offsetY;
	private int v1, v2, v3, v4;
	private boolean isMobile = false;
	private int count;
	
	public void setParameter(int v1, int v2, int v3, int v4) {
		if (v1 > 0) {
			this.v1 = v1;
		}
		if (v2 > 0) {
			this.v2 = v2;
		}
		if (v3 > 0) {
			this.v3 = v3;
		}
		if (v4 > 0) {
			this.v4 = v4;
		}
	}
	
	public void setMobile(boolean isMobile) {
		this.isMobile = isMobile;
	}
	
	public void setCount(int i) {
		this.count = i;
	}
	
	/**
	 * 验证用户行为
	 * @param data 行为数据
	 * @param type 验证码类型 0代表滑动验证码/1代表图文点选验证码
	 * @return
	 */
	public UserBehavior checkUserBehavior (ArrayList<PointBean> data, int type) {
		UserBehavior ub = new UserBehavior();
		ub.bcheck = true;
		len = data.size();
		if (len < 2) {
			return null;
		}
		calcMoveSpeed(data);
		if (checkSpeed()) {
			ub.bcheck = false;
		}
		
		calcMoveAccelerate();
		if (checkAccelerate()) {
			ub.bcheck = false;
		}
		//位移绝对值
		calcMoveOffset(data);
		/*if (offsetX < v1) {
			ub.bcheck = false;
		}
		if (offsetY < v2) {
			ub.bcheck = false;
		}*/
		if ((offsetX + offsetY) < (v1 + v2)) {
			ub.bcheck = false;
		}
		//持续时间
		int Duration = calcMoveDuration(data);
		if (Duration < v3) {
			ub.bcheck = false;
		}
		
		int Interval = calcMouseClickInterval(data, type);
		if (Interval < v4) {
			ub.bcheck = false;
		}
		
		if (!isMobile && Duration - Interval < 30) {
			ub.bcheck = false;
		}
		
		/*if (type == 1) {
			calcClickCount(data);
		}*/
		
		ub.speedX = aryListX;
		ub.speedY = aryListY;
		ub.accelerateX = accelerateX;
		ub.accelerateY = accelerateY;
		ub.offsetX = offsetX;
		ub.offsetY = offsetY;
		ub.Duration = Duration;
		ub.Interval = Interval;
		return ub;
	}
	
	private boolean calcClickCount(ArrayList<PointBean> data) {
		ArrayList<PointBean> temp = new ArrayList<PointBean>();
		for (int i = 0; i < len - 1; i++) {
			if (data.get(i).getType().equals("mousedown") && data.get(i+1).getType().equals("mouseup")) {
				temp.add(data.get(i));
				temp.add(data.get(i+1));
			}
		}
		
		if (temp.size() == 0 || temp.size() != count) {
			return true;
		}
		
		for (int i = 0; i < temp.size() - 1; i++) {
			if (temp.get(i+1).getTimeStamp() - temp.get(i).getTimeStamp() < 100) {
				return true;
			}
		}
		
		long clickTime = temp.get(temp.size() - 1).getTimeStamp() - temp.get(0).getTimeStamp();
		if (clickTime / count < 500) {
			return true;
		}
		
		return false;
	}

	private void calcMoveSpeed (ArrayList<PointBean> data) {
		int distanceX, distanceY;
		int pos1, pos2;
		long time;
		
		for (int i = 0; i < (len - 2); i++) {
			SpeedTimeX stx = new SpeedTimeX();
			SpeedTimeY sty = new SpeedTimeY();
			pos1 = i;
			pos2 = i + 1;
			
			distanceX = data.get(pos2).getX() - data.get(pos1).getX();
			distanceY = data.get(pos2).getY() - data.get(pos1).getY();
			
			time = data.get(pos2).getTimeStamp() - data.get(pos1).getTimeStamp();
			
			if (time == 0) {
				continue;
			}
			
			if (distanceX != 0) {
				stx.speed = (int) (distanceX * 1000 / time);
				stx.time = data.get(pos2).getTimeStamp();
				
				aryListX.add(stx);
			}
			
			if (distanceY != 0) {
				sty.speed = (int) (distanceY * 1000 / time);
				sty.time = data.get(pos2).getTimeStamp();
				
				aryListY.add(sty);
			}
		}
	}
	
	private boolean checkSpeed() {
		ArrayList<Integer> temp = new ArrayList<Integer>();
		int countX = 0, countY = 0;
		int lenX = aryListX.size() - 1;
		for (int i=0; i < lenX; i++) {
			if(aryListX.get(i).speed == aryListX.get(i+1).speed) {
				countX++;
			} else {
				if (countX > 8) {
					temp.add(countX);
				}
				countX = 0;
			}
		}
		
		int lenY = aryListY.size() - 1;
		for (int j = 0; j < lenY; j++) {
			if(aryListY.get(j).speed == aryListY.get(j+1).speed) {
				countY++;
			} else {
				if (countY > 8) {
					temp.add(countY);
				}
				countY = 0;
			}
		}
		
		if (temp.size() > 0){
			return true;
		}
		
		return false;
	}
	
	private void calcMoveAccelerate () {
		int speed1, speed2, time;
		int lenX = aryListX.size();
		for (int i = 0; i < lenX - 1; i++) {
			speed1 = aryListX.get(i+1).speed - aryListX.get(i).speed;
			time = (int) (aryListX.get(i+1).time - aryListX.get(i).time);
			if (time == 0) {
				continue;
			}
			if (speed1 != 0) {
				accelerateX.add(speed1 * 1000 / time);
			}
		}
		
		int lenY = aryListY.size();
		for (int i = 0; i < lenY - 1; i++) {
			speed2 = aryListY.get(i+1).speed - aryListY.get(i).speed;
			time = (int) (aryListY.get(i+1).time - aryListY.get(i).time);
			if (time == 0) {
				continue;
			}
			if (speed2 != 0) {
				accelerateY.add(speed2 * 1000 / time);
			}
		}
	}
	
	private boolean checkAccelerate () {
		ArrayList<Integer> temp = new ArrayList<Integer>();
		int countX = 0, countY = 0;
		int lenX = accelerateX.size() - 1;
		for (int i = 0; i < lenX; i++) {
			if (accelerateX.get(i) == accelerateX.get(i+1)) {
				countX++;
			} else {
				if (countX > 3) {
					temp.add(countX);
				}
				countX = 0;
			}
		}
		
		int lenY = accelerateY.size() - 1;
		for (int j = 0; j < lenY; j++) {
			if (accelerateY.get(j) == accelerateY.get(j+1)) {
				countY++;
			} else {
				if (countY > 3) {
					temp.add(countY);
				}
				countY = 0;
			}
		}
		
		if (temp.size() > 0) {
			return true;
		}
		
		return false;
	}
	
	private void calcMoveOffset (ArrayList<PointBean> data) {
//		SysLog.println("--clacMoveOffset--");
		
		offsetX = 0;
		offsetY = 0;
		int pos1, pos2;
		
		for (int i = 0; i < len -2; i++) {
			pos1 = i;
			pos2 = i + 1;
			offsetX+=Math.abs(data.get(pos2).getX() - data.get(pos1).getX());
			offsetY+=Math.abs(data.get(pos2).getY() - data.get(pos1).getY());
		}
		
//		SysLog.println("offsetX" + offsetX);
//		SysLog.println("offsetY" + offsetY);
	}
	
	private int calcMoveDuration(ArrayList<PointBean> data) {
//		SysLog.println("--calcMoveDuration--");
		int time0 = (int) data.get(0).getTimeStamp();
//		SysLog.println("time0:" + time0);
		
		int time1 = (int) data.get(len - 1).getTimeStamp();
//		SysLog.println("time1:" + time1);
//		SysLog.println("time1 - time0:" + (time1 - time0));
		
		int returnInt = time1 - time0;
//		int tempInt = 0;
//		for (int i = 0; i < data.size(); i++) {
//			int timedata = (int) data.get(i).getTimeStamp();
//			int timeData = 0;
//			if(i+1== data.size()){
//				continue;
//			}
//		}
		return returnInt;
	}
	
	private int calcMouseClickInterval(ArrayList<PointBean> data, int type) {
//		SysLog.println("--calcMouseClickInterval--");
		int time1 = 0;
		int time2 = 0;
		
		if (isMobile) {
			for (int i = 0; i < len; i++) {
				String mouseType = data.get(i).getType();
				if (mouseType.equals("touchstart")) {
					time1 = (int)data.get(i).getTimeStamp();
					break;
				}
			}
			for (int i = len - 1; i > 0; i--) {
				String mouseType = data.get(i).getType();
				if (mouseType.equals("touchend")) {
					time2 = (int)data.get(i).getTimeStamp();
					break;
				}
			}
		} else {
			for (int i = 0; i < len; i++) {
				String mouseType = data.get(i).getType();
				if (mouseType.equals("mousedown")) {
					time1 = (int)data.get(i).getTimeStamp();
					break;
				}
			}
			for (int i = len - 1; i > 0; i--) {
				String mouseType = data.get(i).getType();
				if (mouseType.equals("mouseup")) {
					time2 = (int)data.get(i).getTimeStamp();
					break;
				}
			}
		}
		if (time2 == 0) {
			time2 = (int)data.get(len - 1).getTimeStamp();
		}
//		if(time1 == 0) {
//			time1 = (int)data.get(0).getTimeStamp();
//		}
		return time2 - time1;
	}
	
	public class UserBehavior {
		private boolean bcheck;
		private ArrayList<SpeedTimeX> speedX;
		private ArrayList<SpeedTimeY> speedY;
		private ArrayList<Integer> accelerateX;
		private ArrayList<Integer> accelerateY;
		private int offsetX;
		private int offsetY;
		private int Duration;
		private int Interval;
		public boolean isBcheck() {
			return bcheck;
		}
		public void setBcheck(boolean bcheck) {
			this.bcheck = bcheck;
		}
		public ArrayList<SpeedTimeX> getSpeedX() {
			return speedX;
		}
		public void setSpeedX(ArrayList<SpeedTimeX> speedX) {
			this.speedX = speedX;
		}
		public ArrayList<SpeedTimeY> getSpeedY() {
			return speedY;
		}
		public void setSpeedY(ArrayList<SpeedTimeY> speedY) {
			this.speedY = speedY;
		}
		public ArrayList<Integer> getAccelerateX() {
			return accelerateX;
		}
		public void setAccelerateX(ArrayList<Integer> accelerateX) {
			this.accelerateX = accelerateX;
		}
		public ArrayList<Integer> getAccelerateY() {
			return accelerateY;
		}
		public void setAccelerateY(ArrayList<Integer> accelerateY) {
			this.accelerateY = accelerateY;
		}
		public int getOffsetX() {
			return offsetX;
		}
		public void setOffsetX(int offsetX) {
			this.offsetX = offsetX;
		}
		public int getOffsetY() {
			return offsetY;
		}
		public void setOffsetY(int offsetY) {
			this.offsetY = offsetY;
		}
		public int getDuration() {
			return Duration;
		}
		public void setDuration(int duration) {
			Duration = duration;
		}
		public int getInterval() {
			return Interval;
		}
		public void setInterval(int interval) {
			Interval = interval;
		}
	}
	
	public class SpeedTimeX {
		private int speed;
		private long time;
		@Override
		public String toString() {
			return "SpeedTimeX [speed=" + speed + ", time=" + time + "]";
		}
	}
	
	public class SpeedTimeY {
		private int speed;
		private long time;
		@Override
		public String toString() {
			return "SpeedTimeY [speed=" + speed + ", time=" + time + "]";
		}
		
		
	}
	
}