/**
* @author Dabing
* @E-mail chenbinging@outlook.com
* @date 2018-9-13下午6:08:04
* 类说明
*/
package cn.com.icbc.ms.behavior.base;

public class PointBean {

	private long timeStamp;
	private String type;
	private int x;
	private int y;
	public long getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	
}
