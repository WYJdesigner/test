package cn.com.icbc.ms.behavior.utils;
//import com.sun.source.tree.BreakTree;

import java.math.BigInteger;
/**
 * 
* @author Dabing
* @E-mail chenbinging@outlook.com
* @date 2018-12-2上午10:56:50
* 十六进制转换
 */
/*
* HexStringUtil 的类，其中包含了三个静态方法，
* 用于十六进制字符串和字节数组之间的相互转换。
* */
public class HexStringUtil {
	/*
	* 方法将一个十六进制字符串转换为字节数组。
	* */
	public static byte[] hexStringToBytes(String hexString) {
		if (hexString == null || hexString.equals("")) {
			return null;
		}
		hexString = hexString.toUpperCase();
		int length = hexString.length() / 2;
		char[] hexChars = hexString.toCharArray();
		byte[] d = new byte[length];
		for (int i = 0; i < length; i++) {
			int pos = i * 2;
			d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
		}
		return d;
	}
	/*
	* 方法将一个字节数组转换为十六进制字符串。
	* */
	public static String byte2HexNew(byte[] bArray) {
		StringBuffer sb = new StringBuffer(bArray.length);
		String sTemp;
		for (int i = 0; i < bArray.length; i++) {
			sTemp = Integer.toHexString(0xFF & bArray[i]);
			if (sTemp.length() < 2)
				sb.append(0);
			sb.append(sTemp);
		}
		return sb.toString();
	}
	/*
	* 方法将一个字符转换为字节，通过查找字符在字符串 "0123456789ABCDEF" 中的位置来实现。
	* */
	public static byte charToByte(char c) {
		return (byte) "0123456789ABCDEF".indexOf(c);
	}

	/*
	* 将数字字符串转为16进制
	* */
	public static String convertToHexadecimal(String decimalString) {
		if (StringUtils.isEmpty(decimalString)) {
			return "0";
		}
		BigInteger bigIntValue = new BigInteger(decimalString);
		return bigIntValue.toString(16);
	}

	/*
	 * 将十六进制字符串转为字节数组
	 * */
	public  static byte[] hexStringToByteArray(String hexString) {
		// 检查输入是否为null，是否是空字符串
		if (hexString == null) return null;
		if (hexString.isEmpty()) return new byte[0];
		int len = hexString.length();
		// 检查字符串长度是否为偶数，因为每两个十六进制字符表示一个字节。比如1A3F7
		// 将每两个字符转换为一个字节。例如，"1A"被转换为一个字节，
		// "3F"被转换为一个字节，"72"被转换为一个字节，最终返回一个包含这三个字节的字节数组。
		if (len % 2 != 0) {
			SysLog.println("Input hexString must have an even length.");
			return null;
		}
		// 创建一个字节数组，长度为输入字符串长度的一半
		byte[] data = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			char firstChar = hexString.charAt(i);
			char secondChar = hexString.charAt(i + 1);
			if (!isHexChar(firstChar) || !isHexChar(secondChar)) {
				SysLog.println("Input hexString contains non-hexadecimal characters.");
				return null;
			}
			// 将两个字符转换为一个字节并存储到字节数组中
			data[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4)
					+ Character.digit(hexString.charAt(i + 1), 16));
		}
		for (byte b : data) {
//			System.out.println("b:" + b);
			// 将字节值转换为无符号整数以确保正确的打印
			int unsignedByte = b & 0xFF;
			// 将字节值以十六进制格式打印，确保为两位
//			System.out.print(String.format("%02X ", unsignedByte));
		}

		return data;
	}
	/*
	* 检查这两个字符是否是有效的十六进制字符
	* 会返回字符 c 在十六进制下的数值，如果 c 不是有效的十六进制字符，那么返回值就是 -1。
	* 具体用途是将十六进制字符串中的两个字符（一个字节）转换为对应的字节值
	* 在十六进制表示中，一个字节由两个十六进制字符组成。每个字符表示 4 位二进制。
	* 为了将两个字符合并成一个字节，需要将第一个字符的值左移 4 位，然后与第二个字符的值相加。
	* 考虑十六进制字符串 "1A"。其中，'1' 表示十进制的 1，'A' 表示十进制的 10。在二进制中，'1' 对应于 "0001"，'A' 对应于 "1010"。
	* 为了将它们合并成一个字节，我们将 '1' 左移 4 位，得到 "00010000"，然后将其与 'A' 的二进制值 "1010" 相加，最终得到字节的值 "00011010"，
	* 即十进制的 26。
	* 00010000
	* 00001010
	* 00011010
	* 26
	* 左移 4 位是由于每个十六进制字符表示 4 位二进制，而一个字节由两个字符组成。左移 4 位相当于乘以 16，这正好是将一个十六进制字符的值移动到字节的高位。
	* */
	public static boolean isHexChar(char c) {
		int a = Character.digit(c, 16);
		if (a == -1) {
			return false;
		}else {
			return true;
		}
	}

}
