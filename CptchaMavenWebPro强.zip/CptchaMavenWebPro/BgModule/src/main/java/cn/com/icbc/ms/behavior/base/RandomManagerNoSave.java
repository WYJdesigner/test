package cn.com.icbc.ms.behavior.base;

import java.awt.geom.GeneralPath;
import java.util.ArrayList;

import cn.com.icbc.ms.behavior.base.bean.LatticeSegmentationBean;
import cn.com.icbc.ms.behavior.utils.ConfigUtil;
import cn.com.icbc.ms.behavior.utils.SysLog;
/*
* 总的来说，这个类似乎是一个用于管理生成和验证随机验证码的实用工具类。
* 它包括了设置超时时间、生成随机验证码和验证随机验证码的方法。
* 此类的具体实现可能需要与其他相关类一起使用才能完全理解其功能。
* 这段代码是一个Java类，名为 RandomManagerNoSave，它似乎是一个用于生成和验证随机验证码的管理器类。
 * */
public class RandomManagerNoSave {
	/*
	* 这些是类的静态成员变量，
	* 其中包括随机验证码的超时时间（m_randomTimeout）、
	* 默认超时时间（m_defaultTimeout）、
	* 清理间隔时间（m_cleanInterval）
	* 以及一个单例管理器实例（manager）。
	* */
	private static long m_randomTimeout = 0;
	private static int m_defaultTimeout = 5 * 60 * 1000;
	private static int m_cleanInterval = 2 * 1000;
	private static RandomManagerNoSave manager = null;

	/*
	* 这是一个公有方法，用于设置随机验证码的超时时间。
	* */
	public void setRandomTimeout(long timeout) {
		RandomManagerNoSave.m_randomTimeout = timeout;
	}

	/*
	* 这是 RandomManagerNoSave 类的 finalize 方法，用于对象销毁时的清理操作，但它并没有实现具体的清理逻辑。
	 * */
	@Override
	protected void finalize() throws Throwable {
		super.finalize();
	}

	/*
	* 这是一个公有静态方法 getInstance()，用于获取 RandomManagerNoSave 类的单例实例。
	* 如果 manager 为 null，则创建一个新的实例并返回，否则返回已存在的实例。
	* */
	public static RandomManagerNoSave getInstance() throws Exception {
		if (manager == null) {
			manager = new RandomManagerNoSave();
		}
		return manager;
	}

	/*
	* 这是 RandomManagerNoSave 类的私有构造函数。
	* 它初始化了默认超时时间，从配置文件中获取或者使用默认值，并将其赋值给 m_defaultTimeout 和 m_randomTimeout 变量。
	 * */
	private RandomManagerNoSave() throws Exception {
		// 开启清理服务
		try {
			m_defaultTimeout = ConfigUtil.getParamAsStr("m_defaultTimeout") == null?5 * 60 * 1000:Integer.parseInt(ConfigUtil.getParamAsStr("m_defaultTimeout"));
			m_randomTimeout = m_defaultTimeout;
		} catch (Exception e) {
			SysLog.println(e.toString());
			SysLog.println("Captcha--RandomManagerNoSave--getParamAsStr--error==" + e.toString());
		}
	}

	/*
	* 接下来的一系列方法 setRandomCode4Item 似乎用于生成不同类型的随机验证码，并返回包含随机验证码信息的 RandomItem 对象。
	 * */
	public RandomItem setRandomCode4Item(String uniqueid, int[] rPoint)
			throws Exception {
		String randomStr = "";
		if (uniqueid == null || uniqueid.length() == 0) {
			return null;
		}
		RandomItem item = null;
		try {
			item = new RandomItem(System.currentTimeMillis(), rPoint);
			randomStr = RandomStrGenerater.generateString();
			item.setRandomStr(randomStr);
		} catch (Exception e) {
			SysLog.println(e.toString());
			SysLog.println("Captcha--RandomManagerNoSave--setRandomCode4Item--error==" + e.toString());
		}
		return item;
	}
	
	public RandomItem setRandomCode4Item(String uniqueid, int[] rPoint, int width, int height, int blockW, int blockH, GeneralPath path)
			throws Exception {
		String randomStr = "";
		if (uniqueid == null || uniqueid.length() == 0) {
			return null;
		}

		RandomItem item = null;
		try {
			item = new RandomItem(System.currentTimeMillis(), rPoint, width, height, blockW, blockH);
			randomStr = RandomStrGenerater.generateString();
			item.setRandomStr(randomStr);
		} catch (Exception e) {
			SysLog.println(e.toString());
			SysLog.println("Captcha--RandomManagerNoSave--setRandomCode4Item--error==" + e.toString());
		}
		return item;
	}
	
	public RandomItem setRandomCode4Item(String uniqueid, ArrayList<LatticeSegmentationBean> rPoint)
			throws Exception {
		if (uniqueid == null || uniqueid.length() == 0) {
			return null;
		}
		
		RandomItem item = null;
		try {
			item = new RandomItem(System.currentTimeMillis(), rPoint);
		} catch (Exception e) {
			SysLog.println(e.toString());
			SysLog.println("Captcha--RandomManagerNoSave--setRandomCode4Item--error==" + e.toString());
		}
		return item;
	}
	
	public RandomItem setRandomCode4Item(String uniqueid, ArrayList<LatticeSegmentationBean> rPoint, int width, int height, int countPoint, int checkPoint, int fontSize)
			throws Exception {
		String randomStr = "";
//		if (uniqueid == null || uniqueid.length() == 0) {
//			return null;
//		}
		
		RandomItem item = null;
		try {
			item = new RandomItem(System.currentTimeMillis(), rPoint, width, height, countPoint, checkPoint, fontSize);
			randomStr = RandomStrGenerater.generateString();
			item.setRandomStr(randomStr);
		} catch (Exception e) {
			SysLog.println(e.toString());
			SysLog.println("Captcha--RandomManagerNoSave--setRandomCode4Item--error==" + e.toString());
		}
		return item;
	}

	/*
	* 这是一个验证随机验证码的方法 verifyRandomCodeItem，它接受一个 RandomItem 对象作为参数，
	* 检查随机验证码是否有效，根据时间戳和超时时间来判断是否有效。
	* */
	public RandomItem verifyRandomCodeItem(RandomItem item) throws Exception {

		try {
			if (null == item) {
				return null;
			}
			long currentTime = System.currentTimeMillis();
			if (currentTime < item.getTimeStamp() || (currentTime - item.getTimeStamp()) < m_cleanInterval || (currentTime - item.getTimeStamp()) > m_randomTimeout) {
				return null;
			}
			return item;
		} catch (Exception e) {
			SysLog.println(e.toString());
			SysLog.println("Captcha--verifyRandomCodeItem--TimeMillis--error==" + e.toString());
			return null;
		}

	}
}
