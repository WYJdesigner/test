/**
* @author Dabing
* @E-mail chenbinging@outlook.com
* @date 2019-4-18下午3:07:02
* 系统日志打印
*/
package cn.com.icbc.ms.behavior.utils;

//import org.apache.logging.log4j.Level;
//import org.apache.logging.log4j.Logger;

import java.io.PrintStream;
/**
 * 日志打印公共类
 * 1、需要设置打印参数 c=1
 * 2、如果程序内部loger对象不是null则按照showlogType的级别打印默认是info；否则是控制台打印
 * @author kfzx-zhangzj
 *
 */
public class SysLog {

	private static int c = 0;
	private static String staticInfo = "";

//	private static Logger loger = null ;
//	private static Level showlogType = Level.INFO;
	/**
	 * 
	 * @param c 1代表打印日志 其他不打印
	 */
	public static void logCon (int c) {
		SysLog.c = c;
	}
	static  {
		StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
		StackTraceElement caller = stackTraceElements[2]; // The caller of printlnWithLineNumber
		staticInfo = "\n\t" + caller.getClassName() + "." + caller.getMethodName() + "\n\t" + "(" + caller.getFileName() + ":" + caller.getLineNumber() + ")";
	}
	public static void println(String s) {
		StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
		StackTraceElement caller = stackTraceElements[2]; // The caller of printlnWithLineNumber
		staticInfo = "\n\t" + caller.getClassName() + "." + caller.getMethodName() + "\n\t" + "(" + caller.getFileName() + ":" + caller.getLineNumber() + ")";
		s = s + staticInfo;
		if(c == 0) {
//			if(null != loger){
//				if(showlogType == Level.INFO){
//					loger.info(s);
//				} else if(showlogType == Level.DEBUG){
//					loger.debug(s);
//				} else if(showlogType == Level.ERROR){
//					loger.error(s);
//				} else if(showlogType == Level.TRACE){
//					loger.trace(s);
//				} else if(showlogType == Level.WARN){
//					loger.warn(s);
//				} else{
//					loger.info(s);
//				}
//			}else{
				System.out.println(s);
//			}
		}
	}
	/**
	 * 
	 * @param loger 打印日志的log4j对象
	 */
//	public static void setLoger(Logger loger){
//		SysLog.loger = loger;
//	}
//	public static Logger getLoger(){
//		return SysLog.loger;
//	}
	/**
	 * @param t org.apache.log4j.Level 级别信息 例如 info级别打印送Level.INFO_INT
	 */
//	public static void setLogerType(Level t){
//		SysLog.showlogType = t;
//	}
}
