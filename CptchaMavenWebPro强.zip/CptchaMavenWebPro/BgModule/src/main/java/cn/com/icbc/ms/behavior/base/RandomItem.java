package cn.com.icbc.ms.behavior.base;

import java.awt.geom.GeneralPath;
import java.util.ArrayList;

import cn.com.icbc.ms.behavior.base.bean.LatticeSegmentationBean;
import cn.com.icbc.ms.behavior.utils.ConfigUtil;

/*
* 随机验证码的数据结构
* 总的来说，这个类似乎是用于存储与生成随机验证码相关的数据的容器。
* 它提供了不同的构造函数，以便根据不同的需求来初始化对象。
* 这些属性存储了有关验证码的各种信息，包括时间戳、随机字符串、坐标点、宽度、高度等。它还提供了一些方法来获取和设置这些属性。
* 这个类的具体用途可能需要结合其他代码来理解，因为它存储了与验证码生成和验证相关的各种信息。
* 类的属性：
	timeStamp：用于存储时间戳，表示创建该随机验证码的时间。
	randomStr：存储生成的随机字符串。
	rPoint：存储一组整数，可能用于描述随机验证码的位置信息。
	width 和 height：表示验证码的宽度和高度。
	blockW 和 blockH：表示验证码的块宽度和块高度。
	rPointAry：存储一组 LatticeSegmentationBean 对象，可能用于描述随机验证码的分割信息。
	path：一个 GeneralPath 对象，用于描述验证码的路径。
	countPoint 和 checkPoint：用于描述验证码的点数和检查点。
	fontSize：表示字体大小。
	picPath：存储验证码图片的路径。
	cacheIMGUsedNum：表示缓存图片使用数量。
t：一个整数数组。
* */
public class RandomItem {

	private long timeStamp;
	
	private String randomStr;
	
	private int[] rPoint;
	
	private int width;
	
	private int height;
	
	private int blockW;
	
	private int blockH;
	
	private ArrayList<LatticeSegmentationBean> rPointAry;
	
	private GeneralPath path;
	
	private int countPoint;
	
	private int checkPoint;
	
	private int fontSize;
	
	public String picPath= "";
	
	private int cacheIMGUsedNum;
	
	private int[] t = new int[4];

	private String sr = "";
	/*
	* 类有多个构造函数，允许根据不同的参数组合来创建 RandomItem 对象。
	* 这些构造函数将接受不同的参数并初始化对象的属性。
	* */
	public RandomItem(){}

	public RandomItem(long timeStamp, int[] rPoint) {
		this.timeStamp = timeStamp;
		this.rPoint = rPoint;
		this.cacheIMGUsedNum = ConfigUtil.getParamAsStr("behavior.cacheIMGUsedNum") ==null ?0:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.cacheIMGUsedNum"));
	}
	
	public RandomItem(long timeStamp, int width, int height) {
		this.timeStamp = timeStamp;
		this.width = width;
		this.height = height;
		this.cacheIMGUsedNum = ConfigUtil.getParamAsStr("behavior.cacheIMGUsedNum") ==null ?5:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.cacheIMGUsedNum"));
	}
	
	public RandomItem(long timeStamp, int[] rPoint, int width, int height, int blockW, int blockH) {
		this.timeStamp = timeStamp;
		this.rPoint = rPoint;
		this.width = width;
		this.height = height;
		this.blockW = blockW;
		this.blockH = blockH;
//		this.path = path;
		this.cacheIMGUsedNum = ConfigUtil.getParamAsStr("behavior.cacheIMGUsedNum") ==null ?5:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.cacheIMGUsedNum"));
	}
	
	public RandomItem(long timeStamp, ArrayList<LatticeSegmentationBean> rPointAry) {
		this.timeStamp = timeStamp;
		this.rPointAry = rPointAry;
		this.cacheIMGUsedNum = ConfigUtil.getParamAsStr("behavior.cacheIMGUsedNum") ==null ?5:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.cacheIMGUsedNum"));
	}
	
	public RandomItem(long timeStamp, ArrayList<LatticeSegmentationBean> rPointAry, int width, int height, int countPoint, int checkPoint, int fontSize) {
		this.timeStamp = timeStamp;
		this.rPointAry = rPointAry;
		this.width = width;
		this.height = height;
		this.countPoint = countPoint;
		this.checkPoint = checkPoint;
		this.fontSize = fontSize;
		this.cacheIMGUsedNum = ConfigUtil.getParamAsStr("behavior.cacheIMGUsedNum") ==null ?5:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.cacheIMGUsedNum"));
	}
	

	public long getTimeStamp() {
		return timeStamp;
	}

	public int[] getrPoint() {
		return rPoint;
	}

	public ArrayList<LatticeSegmentationBean> getrPointAry() {
		return rPointAry;
	}

	public void setrPointAry(ArrayList<LatticeSegmentationBean> rPointAry) {
		this.rPointAry = rPointAry;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public GeneralPath getPath() {
		return path;
	}

	public int getCountPoint() {
		return countPoint;
	}

	public int getCheckPoint() {
		return checkPoint;
	}

	public int getFontSize() {
		return fontSize;
	}

	public int getBlockW() {
		return blockW;
	}

	public int getBlockH() {
		return blockH;
	}

	public String getRandomStr() {
		return randomStr;
	}

	public void setRandomStr(String randomStr) {
		this.randomStr = randomStr;
	}

	public String getSr() {
		return sr;
	}

	public void setSr(String sr) {
		this.sr = sr;
	}
	public int getCacheIMGUsedNum() {
		return cacheIMGUsedNum;
	}

	public void setCacheIMGUsedNum(int cacheIMGUsedNum) {
		this.cacheIMGUsedNum = cacheIMGUsedNum;
	}

	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}

	public void setrPoint(int[] rPoint) {
		this.rPoint = rPoint;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public void setBlockW(int blockW) {
		this.blockW = blockW;
	}

	public void setBlockH(int blockH) {
		this.blockH = blockH;
	}

	public void setCountPoint(int countPoint) {
		this.countPoint = countPoint;
	}

	public void setCheckPoint(int checkPoint) {
		this.checkPoint = checkPoint;
	}

	public void setFontSize(int fontSize) {
		this.fontSize = fontSize;
	}

	public int[] getT(){
		return t;
	}
	
	public void setT(int[] t){
		this.t = t;
	}
	
	public String getPicPath() {
		return picPath;
	}
	
	public void setPicPath(String picPath) {
		this.picPath = picPath;
	}
	
}
