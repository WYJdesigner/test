/**
 * @author Dabing
 * @E-mail chenbinging@outlook.com
 * @date 2018-10-26上午11:02:29
 * 外部对接类
 */
package cn.com.icbc.ms.behavior.component;

import java.awt.Font;
import java.io.UnsupportedEncodingException;
import com.alibaba.fastjson.JSONObject;
import cn.com.icbc.ms.behavior.base.RandomManagerNoSave;
import cn.com.icbc.ms.behavior.exception.BehaviorFailException;
import cn.com.icbc.ms.behavior.utils.ConfigUtil;
import cn.com.icbc.ms.behavior.utils.StringUtils;
import cn.com.icbc.ms.behavior.utils.SysLog;
import cn.com.icbc.ms.behavior.base.bean.KeyPairInfo;
import com.re.domain.VerifyDomain;
import com.re.impl.*;
import com.re.inter.CaptchaSuperBehavior;
import com.re.modules.*;
import com.re.domain.CommonDomain;


/*
* 1。三个接口，定义三个实现累，一个父累，
* 2。rnutils还是传递接口，传递父接口，，
* 3，工程改为maven工程。
* 4。图，中间改为实现累，接口放在中间，
* 5。模块依赖去除掉。
*
* //划分5个模块
* //滑块模块放入到背景图模块
* // 根据模块划分对应的接口，每个模块单独的接口放到单独模块对应的接口中
* // 根据模块划分单独的实现类
* */
public class CaptchaCommonBehaviorRNUtils implements CaptchaSuperBehavior {

	private String version = "1.2.5";
	private String imageFilePath;
	private final String codeSequenceDefault = "天地玄黄宇宙洪荒日月盈昃辰宿列张寒来暑往秋收冬藏闰余成岁律吕调阳云腾致雨露结为霜金生丽水玉出昆冈剑号巨阙珠称夜光果珍李柰菜重芥姜海咸河淡鳞潜羽翔龙师火帝鸟官人皇始制文字乃服衣裳推位让国有虞陶唐吊民伐罪周发殷汤坐朝问道垂拱平章爱育黎首臣伏戎羌遐迩体率宾归王";
	private final String strIdiomDefault = "万象更新,千军万马,亡羊补牢,杯弓蛇影,鹤立鸡群,对牛弹琴,如鱼得水,鸟语花香,为虎作伥,黔驴技穷,画龙点睛,虎背熊腰,守株待兔,鹤发童颜,画蛇添足,鹬蚌相争,龙马精神,龙腾虎跃,车水马龙,指鹿为马,鸡犬不宁,心猿意马,狼吞虎咽,胸无点墨,头重脚轻,手足情深,袖手旁观,飞蛾扑火,金蝉脱壳,蜻蜓点水,螳臂挡车,蛛丝马迹,螳螂捕蝉,黄雀在后,见多识广,察言观色,高瞻远瞩,调兵遣将,粉身碎骨,千辛万苦,眼疾手快,生龙活虎,惊天动地,胡言乱语,改朝换代,道听途说,千呼后拥,东倒西歪,眼高手低,口是心非,有头无尾,南辕北辙,积少成多,大材小用,先人后己,有口无心,天经地义,弄假成真,举足轻重,南腔北调,声东击西,转危为安,反败为胜,以少胜多,千钧一发,刻不容缓,迫不及待,十万火急,火烧眉毛,燃眉之急,心旷神怡,心平气和,目不转睛,眉开眼笑,愁眉苦脸,目瞪口呆,垂头丧气,嬉皮笑脸,一身正气,临危不惧,光明磊落,力挽狂澜,急中生智,镇定自若,化险为夷,春雨如油,春意盎然,春暖花开,百花齐放,苦思冥想,深思熟虑,胡思乱想,浮想联翩,左思右想,痴心妄想,异想天开,朝思暮想,座无虚席,高朋满座,摩肩接踵,五彩缤纷,博览群书,走南闯北,五颜六色,五花八门,望而生畏,一视同仁,一览无余,坐井观天,举世瞩目,管中窥豹,左顾右盼,龙争虎斗,龙飞凤舞,龙潭虎穴,龙跃凤鸣,刻舟求剑,鹏程万里,掩耳盗铃,惊弓之鸟,暗渡陈仓,班门弄斧,兵不厌诈,三顾茅庐,欢呼雀跃,鸦雀无声,一箭双雕,风声鹤唳,不耻下问,马到成功,功败垂成,成人之美,收回成命,命中注定,弹尽粮绝,有机可乘,乘机而入,入木三分,分秒必争,争权夺利,利欲熏心,心安理得,草船借箭,得才兼备,鞠躬尽瘁,代人受过,孤陋寡闻,一毛不拔,一呼百应,一干二净,一举两得,一落千丈,一日千里,两面三刀,三长两短,三番五次,三头六臂,三心二意,三言两语,四分五裂,四面八方,四通八达,四平八稳,五光十色,五湖四海,六神无主,七零八落,七上八下,七手八脚,七嘴八舌,八面玲珑,九牛一毛,十马九稳,千变万化,千差万别,千丝万缕,千真万确,千锤百炼,千方百计,千奇百怪,千姿百态,千篇一律,万水千山,万无一失,万众一心,肝胆相照,情同手足,志同道合,风雨同舟,荣辱与共,同甘共苦,关怀备注,海誓山盟,拔刀相助,亲密无间,姹紫嫣红,锦上添花,火树银花,春花秋月,花团锦簇,花枝招展,崇山峻岭,山明水秀,山穷水尽,大好山河,刀山火海,地动山摇,高山深涧,悬崖峭壁,峰峦雄伟,江山如画,锦绣山河,万紫千红,花红柳绿,青红皂白,绿水青山,不可多得,凤毛麟角,绝无仅有,空前绝后,寥若晨星,宁缺毋滥,前所未有,屈指可数,铁树开花,百里挑一,沧海一粟,千古绝唱,挥汗如雨,络绎不绝,万人空巷,水泄不通,人声鼎沸,人欢马叫,震耳欲聋,包罗万象,琳琅满目,美不胜收,目不暇接,无奇不有,眼花缭乱,洋洋大观,一应俱全,应有尽有,应接不暇,不可计数,层出不穷,多如牛毛,俯拾皆市,漫山遍野,星罗棋布,丰富多彩,九霄云外,腾云驾雾,壮志凌云,风云变幻,风起云涌,行云流水,风卷残云,浮云蔽日,孤云野鹤,烟消云散,风雨交加,风调雨顺,枪林弹雨,风雨无阻,和风细雨,满城风雨,滂沱大雨,春风化雨,风雨飘摇,水流湍急,水平如镜,高山流水,千山万水,水滴石穿,水乳交融,滴水不漏,杯水车薪,洪水猛兽,流水无情,直言不讳,无所顾忌,拐弯抹角,真心诚意,故弄玄虚,虚情假意,推心置腹,旁敲侧击,慢条斯理,含糊其词,肆无忌惮,大言不惭,对答如流,自圆其说,闲言碎语,闭月羞花,沉鱼落雁,出水芙蓉,美如冠玉,国色天香,眉清目秀,和蔼可亲,张牙舞爪,冰清玉洁,雍容华贵,老态龙钟,如花似玉,容光焕发,骨瘦如柴,面黄肌瘦,其貌不扬,蓬头垢面,弱不禁风,口若悬河,谈笑风生,高谈阔论,豪言壮语,花言巧语,忐忑不安,心惊肉跳,心神不定,心慌意乱,心急如焚,孤芳自赏,居功自傲,目中无人,妄自尊大,忘乎所以,惟我独尊,自鸣得意,自我陶醉,自命不凡,目空一切,功成不居,洗耳恭听,虚怀若谷,慎言谨行,学无止境,学而不厌,真才实学,学而不倦,发奋图强,废寝忘食,争分夺秒,笨鸟先飞,闻鸡起舞,自强不息,只争朝夕,不甘示弱,全力以赴,力争上游,披荆斩棘,奋不顾身,舍己为人,坚强不屈,赤胆忠心,忠贞不渝,威武不屈,克己奉公,一丝不苟,两袖清风,见礼忘义,永垂不朽,顶天立地,眉飞色舞,昂首挺胸,惊慌失措,漫不经心,没精打采,大惊失色,怒发冲冠,一目十行,一字千金,一日三秋,不毛之地,不计其数,胆大包天,寸步难行,一步登天,观者如云,挥金如土,铁证如山,爱财如命,稳如泰山,门庭若市,冷若冰霜,如雷贯耳,守口如瓶,高手如林,阳春三月,春光明媚,春回大地,春意正浓,风和日丽,春花烂漫,百鸟鸣春,骄阳似火,大汗淋漓,鸟语蝉鸣,万木葱茏,枝繁叶茂,秋高气爽,秋菊怒放,秋菊傲骨,秋色迷人,秋色宜人,金桂飘香,北雁南飞,满山红叶,五谷丰登,芦花飘扬,天寒地冻,滴水成冰,寒冬腊月,冰天雪地,冰封大地,万物初醒,空气清醒,雄鸡报晓,晨雾弥漫,晨光绚丽,丽日临空,日落西山,夕阳西斜,炊烟四起,百鸟归林,华灯初上,夜幕低垂,日薄西山,夜深人静,月明星稀,深更半夜,漫漫长夜,风光秀丽,宁静和谐,小桥流水,粉饰一新,门可罗雀,错落有致,富丽堂皇,设施齐全,气势雄伟,金碧辉煌,风景如画,闻名遐迩,井然有序,杂乱无章,布局巧妙,宽阔平坦,崎岖不平,拥挤不堪,畅通无阻,花色迷人,花香醉人,百花盛开,百花争艳,绚丽多彩,绿草如茵,杂草丛生,苍翠挺拔,枯木逢春,秀丽多姿,青翠欲滴,耸入云天,瓜果蔬菜,清香鲜嫩,果园飘香,果实饱满,鲜嫩水灵,乳燕初飞,婉转悦耳,莺歌燕舞,翩然归来,鹦鹉学舌,笨嘴学舌,神气活现,引吭高歌,腾空而起,狂奔飞驰,膘肥体壮,昂首嘶鸣,瘦骨嶙峋,行动迟缓,俯首帖耳,川流不息,呼啸而过,穿梭往来,一叶扁舟,扬帆远航,乘风破浪,雾海夜航,追波逐浪,划破云层,直冲云霄,穿云而过,银鹰展翅,活泼可爱,惹人喜爱,爱不释手,雨后彩虹,彩桥横空,光芒万丈,大雪纷飞,大雪封山,鹅毛大雪,漫天飞雪,瑞雪纷飞,林海雪原,风雪交加,雪上加霜,寒霜袭人,霜林尽染,垂露欲滴,朝露晶莹,日出露干,电光石火,雷电大作,电劈石击,雷电交加,阴雨连绵,牛毛细雨,秋雨连绵,随风飘洒,倾盆大雨,狂风暴雨,大雨滂沱,瓢泼大雨,大雨淋漓,暴雨如注,秋风送爽,寒风刺骨,大雾迷途,雾似轻纱,风吹雾散,云消雾散,彩云满天,天高云淡,乌云翻滚,彤云密布,彩霞缤纷,晚霞如火,朝霞灿烂,丹霞似锦,满天星斗,众星捧月,群星灿烂,万点繁星,月出东墙,月光皎洁,月色迷人,月牙初升,旭日东升,日上三竿,一轮红日,日高三尺,艳阳高照,烈日当头,日影西斜,碧空万里,晴空万里,万里无云,悠然而下,惊涛拍岸,波涛汹涌,白浪滔天,奔腾翻卷,奔腾不息,汪洋大海,湖光水色,一泻千里,荒山野岭,寸草不生,山清水秀,青山绿水,高耸入云,心灵手巧,手忙脚乱,形影不离,团结友爱,朝夕相处,人声喧哗,人声嘈杂,人如潮涌,神情专注,专心致志,日积月累,普天同庆,彩旗飞舞,欢天喜地,张灯结彩,彻夜狂欢,兴高采烈";
	private String encoding = "UTF-8";

	private CaphchaBackGroundModule backGroundModule;
	private CaptchaCommonModule commonModule;
	private CaptchaVerifyModule verifyModule;
	private CaptchaEncryptModule encryptModule;

	private CaptchaCommonImpl captchaCommonImpl;
	private CaptchaVerifyImpl captchaVerifyImpl;
	private CaptchaBgroundImpl captchaBgroundImpl;

	public String getVersion() {
		return this.version;
	}

	public void setKeyPairParams(KeyPairGenerator keyPairGenerator) {
		//报错，修改
		if (keyPairGenerator != null) {
//			this.keyPairGenerator = keyPairGenerator;
			this.captchaCommonImpl.setKeyPairGenerator(keyPairGenerator);
		}else {
			SysLog.println("keyPairGenerator cannot be null");
		}
	}

	// 生成验证码
	public JSONObject fetchCaptchaData(CommonDomain commonDomain) throws BehaviorFailException {
		return this.commonModule.getCommonParams(commonDomain);
	}

	// 验证验证码
	public String verifyCaptchaData(VerifyDomain verifyDomain) {
		return this.verifyModule.verifyCaptchaData(verifyDomain);
	}

	// 初始化模块以及实现类
	public void initializeAllModules() {
		this.captchaCommonImpl = new CaptchaCommonImpl();
		this.captchaVerifyImpl = new CaptchaVerifyImpl();
		this.captchaBgroundImpl = new CaptchaBgroundImpl();

		this.encryptModule = new CaptchaEncryptModule(this.captchaCommonImpl);
		this.verifyModule = new CaptchaVerifyModule(this.encryptModule,this.captchaCommonImpl,this.captchaVerifyImpl);
		this.commonModule = new CaptchaCommonModule(this.captchaCommonImpl,this.encryptModule,this);
		this.backGroundModule = new CaphchaBackGroundModule(this.captchaCommonImpl,this.captchaBgroundImpl);
	}

	//在对象初始化时，从配置文件中读取各种参数，并初始化类的成员变量
	public CaptchaCommonBehaviorRNUtils(IMUniCerInterface behaviorCall, boolean isRedisAvail) {
		initializeAllModules();
		//报错，修改
//		this.behaviorCall = behaviorCall;
//		this.isRedisAvail = isRedisAvail;
		this.captchaCommonImpl.setBehaviorCall(behaviorCall);
		this.captchaCommonImpl.setIsRedisAvail(isRedisAvail);

		try {
			//报错，修改
//			c_manager = RandomManagerNoSave.getInstance();
			RandomManagerNoSave c_manager = RandomManagerNoSave.getInstance();
			this.captchaVerifyImpl.setC_manager(c_manager);
		} catch (Exception e) {
			SysLog.println(e.toString());
			SysLog.println("Captcha--getInstance--error==" + e.toString());
		}
		//初始化全局编码
		encoding = ConfigUtil.getParamAsStr("system.encoding") == null?"UTF-8":ConfigUtil.getParamAsStr("system.encoding");
		String str = "";
		try {
			str = ConfigUtil.getParamAsStr("behavior.codeSequence") == null?codeSequenceDefault:ConfigUtil.getParamAsStr("behavior.codeSequence");
			str = new String(str.getBytes(encoding),encoding);
		} catch (UnsupportedEncodingException e) {
			str = codeSequenceDefault;
			SysLog.println("Captcha--getParamAsStrcodeSequence--error==" + e.toString());
		}
		//报错，修改
//		codeSequence = str;
		this.captchaCommonImpl.setCodeSequence(str);
		try {
			str = ConfigUtil.getParamAsStr("behavior.idiomSequence") == null?strIdiomDefault:ConfigUtil.getParamAsStr("behavior.idiomSequence");
			str = new String(str.getBytes(encoding),encoding);
		} catch (UnsupportedEncodingException e) {
			str = strIdiomDefault;
			SysLog.println("Captcha--getParamAsStridiomSequence--error==" + e.toString());
		}
		//报错，修改
//		strIdiom = str;
		this.captchaCommonImpl.setStrIdiom(str);
		//获取背景图片基准
		try{
			int bgWidthStandard = ConfigUtil.getParamAsStr("behavior.bgWidthStandard")==null?180:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.bgWidthStandard"));
			//报错，修改
			this.captchaCommonImpl.setBgWidthStandard(bgWidthStandard);
			int bgHeightStandard = ConfigUtil.getParamAsStr("behavior.bgHeightStandard")==null?150:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.bgHeightStandard"));
			this.captchaCommonImpl.setBgHeightStandard(bgHeightStandard);
			int bgWidthMaxStandard = ConfigUtil.getParamAsStr("behavior.bgWidthMaxStandard")==null?1200:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.bgWidthMaxStandard"));
			this.captchaCommonImpl.setBgWidthMaxStandard(bgWidthMaxStandard);
			int bgHeightMaxStandard = ConfigUtil.getParamAsStr("behavior.bgHeightMaxStandard")==null?1000:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.bgHeightMaxStandard"));
			this.captchaCommonImpl.setBgHeightMaxStandard(bgHeightMaxStandard);
		}catch(Exception e){
			//报错，修改
//			bgWidthStandard = 180;
//			bgHeightStandard = 150;
//			bgWidthMaxStandard = 1000;
//			bgHeightMaxStandard = 800;
			this.captchaCommonImpl.setBgWidthStandard(180);
			this.captchaCommonImpl.setBgHeightStandard(150);
			this.captchaCommonImpl.setBgWidthMaxStandard(1000);
			this.captchaCommonImpl.setBgHeightMaxStandard(800);

			SysLog.println("Captcha--getParamAsStrbgWidth--error==" + e.toString());
		}
		//报错，修改
//		if (crypto_kind == 2) {
		if (this.captchaCommonImpl.getEncrypt() == 2) {
			try {
				String pubModule = ConfigUtil.getParamAsStr("behavior.pubModule");
				String pubExponen = ConfigUtil.getParamAsStr("behavior.pubExponen");
				String priModule = ConfigUtil.getParamAsStr("behavior.priModule");
				String priExponen = ConfigUtil.getParamAsStr("behavior.priExponen");
				if (StringUtils.isEmpty(pubModule) || StringUtils.isEmpty(pubExponen) || StringUtils.isEmpty(priModule) || StringUtils.isEmpty(priExponen)) {
					SysLog.println("配置文件获取RSA密钥参数为空");
					return;
				}
				KeyPairInfo keyPairInfo = new KeyPairInfo();
				keyPairInfo.setAlgorithm("RSA");
				keyPairInfo.setPublicModule(pubModule);
				keyPairInfo.setPublicExponen(pubExponen);
				keyPairInfo.setPrivateModule(priModule);
				keyPairInfo.setPrivateExponent(priExponen);
				KeyPairGenerator keyPairGenerator = KeyPairGenerator.createKeyPairGenerator(keyPairInfo);
				setKeyPairParams(keyPairGenerator);
				SysLog.println("配置文件获取的：" + keyPairGenerator);
			} catch (Exception e) {
				SysLog.println("配置文件获取RSA密钥参数异常:" + e.toString());
			}
		}
	}
	//报错，修改，
	// 外界调用的方法，统一封装一层，因为抽离到point去了
	public void setSliceY(int slice_y) {
		this.captchaCommonImpl.setSliceY(slice_y);
	}

	public void setSliceNum(int[] sliceNum) {
		this.captchaCommonImpl.setSliceNum(sliceNum);
	}

	public void setSliceX(int slice_x) {
		this.captchaCommonImpl.setSliceX(slice_x);
	}

	public void setSliceType(int slice_type) {
		this.captchaCommonImpl.setSliceType(slice_type);
	}

	public void setEncrypt(int crypto_kind) {
		this.captchaCommonImpl.setEncrypt(crypto_kind);
	}

	public void setBlockSize(int w, int h) {
		this.captchaCommonImpl.setBlockSize(w,h);
//		if (w > 0) {
//			this.blockW = w;
//		}
//		if (h > 0) {
//			this.blockH = h;
//		}
	}

	public void setConnectTimeOut(int connectTimeMax) {
		this.captchaVerifyImpl.setConnectTimeOut(connectTimeMax);
	}

	public void setConnectTimeMin(int connectTimeMin) {
		this.captchaVerifyImpl.setConnectTimeMin(connectTimeMin);
	}

	public void setStandParams(boolean isStand, int value) {
		this.captchaVerifyImpl.setStandParams(isStand,value);
	}

	public void setCodeSequence(String codeSequence) {
		this.captchaCommonImpl.setCodeSequence(codeSequence);
	}

	public void setCodeSequence(String str, String encoding) {
		if (!StringUtils.isEmpty(str)) {
			this.captchaCommonImpl.setCodeSequence(str,encoding);
		}
	}

	public void setRandomColor(boolean randomColor) {
		this.captchaBgroundImpl.setRandomColor(randomColor);
	}

	public void setColorR(int colorR) {
		this.captchaBgroundImpl.setColorR(colorR);
	}

	public void setColorB(int colorB) {
		this.captchaBgroundImpl.setColorB(colorB);
	}

	public void setColorG(int colorG) {
		this.captchaBgroundImpl.setColorG(colorG);
	}

	public void setFont(Font localFont) {
		this.captchaCommonImpl.setFont(localFont);
	}

	public void setColorRange(int c) {
		if (c > 0) {
			//报错，修改
//			this.colorRange = c;
			this.captchaBgroundImpl.setColorRange(c);
		}
	}

	public void setFontSizeChange(boolean b) {
		//报错，修改
//		this.fontSizeChange = b;
		this.captchaBgroundImpl.setFontSizeChange(b);
	}

	/**
	 * 设置图片文件目录路径
	 * 
	 * @param path
	 */
	private void setImageFilePath(String path) {
		if (!StringUtils.isEmpty(path)) {
			this.imageFilePath = path;
		}
	}

	/**
	 * 设置验证范围参数
	 * 
	 * @param v
	 */
	public void setRangeValue(int v) {
		if (v > 0) {
			//报错，修改
//			this.rangeValue = v;
			this.captchaVerifyImpl.setRangeValue(v);
		}
	}

	@Override
	public CaphchaBackGroundModule getBackGroundModule() {
		return this.backGroundModule;
	}
}
