/**
* @author Dabing
* @E-mail chenbinging@outlook.com
* @date 2018-12-19上午11:30:02
* 类说明
*/
package cn.com.icbc.ms.behavior.base.bean;

public class AccelerationIncludingGravityBean {

	private float x;
	private float y;
	private float z;
	public float getX() {
		return x;
	}
	public void setX(float x) {
		this.x = x;
	}
	public float getY() {
		return y;
	}
	public void setY(float y) {
		this.y = y;
	}
	public float getZ() {
		return z;
	}
	public void setZ(float z) {
		this.z = z;
	}
	
}
