/**
* @author Dabing
* @E-mail chenbinging@outlook.com
* @date 2018-12-19上午11:19:17
* 传感器验证类
*/
package cn.com.icbc.ms.behavior.utils;

import java.util.ArrayList;

import cn.com.icbc.ms.behavior.base.bean.AccelerationBean;
import cn.com.icbc.ms.behavior.base.bean.AccelerationIncludingGravityBean;
import cn.com.icbc.ms.behavior.base.bean.OrientationBean;
import cn.com.icbc.ms.behavior.base.bean.RotationRateBean;
import cn.com.icbc.ms.behavior.base.bean.SensorBean;

public class SensorUtils {
	private float range = 0.01f;

	public boolean checkUserSensor(SensorBean sensor) {
		if (sensor == null) {
			return true;
		}
		
		//检查方向传感器
		ArrayList<OrientationBean> listOriArrayList = sensor.getOrientation();
		if (checkOrientation(listOriArrayList)) {
			return true;
		}
		//检查加速度
		ArrayList<AccelerationBean> listAccArrayList = sensor.getAcceleration();
		if (checkAcceleration(listAccArrayList)) {
			return true;
		}
		//检查重力加速度
		ArrayList<AccelerationIncludingGravityBean> accIncArrayList = sensor.getAccelerationIncludingGravity();
		if (checkAccelerationIncludingGravity(accIncArrayList)) {
			return true;
		}
		//检查旋转方向传感器数据
		ArrayList<RotationRateBean> rotArrayList = sensor.getRotationRate();
		if (checkRotationRate(rotArrayList)) {
			return true;
		}
		
		return false;
	}
	
	private boolean checkOrientation(ArrayList<OrientationBean> listOriArrayList) {
		if (listOriArrayList == null || listOriArrayList.size() == 0) {
			return true;
		}
		
		if (listOriArrayList.size() == 1) {
			return false;
		}
		
		float a = 0.0f;
		float b = 0.0f;
		float g = 0.0f;
		for (int i = 0; i < listOriArrayList.size() - 1; i++) {
			float ai = Math.abs(listOriArrayList.get(i + 1).getAlpha() - listOriArrayList.get(i).getAlpha());
			float bi = Math.abs(listOriArrayList.get(i + 1).getBeta() - listOriArrayList.get(i).getBeta());
			float gi = Math.abs(listOriArrayList.get(i + 1).getGamma() - listOriArrayList.get(i).getGamma());
			a += ai;
			b += bi;
			g += gi;
		}
		
		SysLog.println("checkOrientation:" + a + "-" + b + "-" + g);
		if (a > range && b > range && g > range) {
			return false;
		} else {
			return true;
		}
	}
	
	private boolean checkAcceleration(ArrayList<AccelerationBean> listAccArrayList) {
		if (listAccArrayList == null || listAccArrayList.size() == 0) {
			return true;
		}
		
		if (listAccArrayList.size() == 1) {
			return false;
		}
		
		float x = 0.0f;
		float y = 0.0f;
		float z = 0.0f;
		for (int i = 0; i < listAccArrayList.size() - 1; i++) {
			float xi = Math.abs(listAccArrayList.get(i + 1).getX() - listAccArrayList.get(i).getX());
			float yi = Math.abs(listAccArrayList.get(i + 1).getY() - listAccArrayList.get(i).getY());
			float zi = Math.abs(listAccArrayList.get(i + 1).getZ() - listAccArrayList.get(i).getZ());
			x += xi;
			y += yi;
			z += zi;
		}
		
		SysLog.println("checkAcceleration:" + x + "-" + y + "-" + z);
		if (x > range && y > range && z > range) {
			return false;
		} else {
			return true;
		}
	}
	
	private boolean checkAccelerationIncludingGravity(ArrayList<AccelerationIncludingGravityBean> accelerationIncludingGravity) {
		if (accelerationIncludingGravity == null || accelerationIncludingGravity.size() == 0) {
			return true;
		}
		
		if (accelerationIncludingGravity.size() == 1) {
			return false;
		}
		
		float x = 0.0f;
		float y = 0.0f;
		float z = 0.0f;
		for (int i = 0; i < accelerationIncludingGravity.size() - 1; i++) {
			float xi = Math.abs(accelerationIncludingGravity.get(i + 1).getX() - accelerationIncludingGravity.get(i).getX());
			float yi = Math.abs(accelerationIncludingGravity.get(i + 1).getY() - accelerationIncludingGravity.get(i).getY());
			float zi = Math.abs(accelerationIncludingGravity.get(i + 1).getZ() - accelerationIncludingGravity.get(i).getZ());
			x += xi;
			y += yi;
			z += zi;
		}
		
		SysLog.println("checkAccelerationIncludingGravity:" + x + "-" + y + "-" + z);
		if (x > range && y > range && z > range) {
			return false;
		} else {
			return true;
		}
	}
	
	private boolean checkRotationRate(ArrayList<RotationRateBean> rotArrayList) {
		if (rotArrayList == null || rotArrayList.size() == 0) {
			return true;
		}
		
		if (rotArrayList.size() == 1) {
			return false;
		}
		
		float a = 0.0f;
		float b = 0.0f;
		float g = 0.0f;
		for (int i = 0; i < rotArrayList.size() - 1; i++) {
			float ai = Math.abs(rotArrayList.get(i + 1).getAlpha() - rotArrayList.get(i).getAlpha());
			float bi = Math.abs(rotArrayList.get(i + 1).getBeta() - rotArrayList.get(i).getBeta());
			float gi = Math.abs(rotArrayList.get(i + 1).getGamma() - rotArrayList.get(i).getGamma());
			a += ai;
			b += bi;
			g += gi;
		}
		
		SysLog.println("checkRotationRate:" + a + "-" + b + "-" + g);
		int s = 0;
		if (a > range) {
			s++;
		}
		if (b > range) {
			s++;
		}
		if (g > range) {
			s++;
		}
		if (s >= 2) {
			return false;
		} else {
			return true;
		}
	}
}
