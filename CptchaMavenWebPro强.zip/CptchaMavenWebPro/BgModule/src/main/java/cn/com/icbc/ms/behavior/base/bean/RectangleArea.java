package cn.com.icbc.ms.behavior.base.bean;

public class RectangleArea {
	public int xAreaPointLeft = 0;
	public int xAreaPointRight = 0;
	public int yAreaPointTop = 0;
	public int yAreaPointBottom =0;
}
