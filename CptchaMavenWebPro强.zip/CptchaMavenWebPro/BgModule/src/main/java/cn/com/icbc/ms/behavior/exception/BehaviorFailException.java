package cn.com.icbc.ms.behavior.exception;

public class BehaviorFailException extends Exception {
	private String classMethodName;
	private String errorCode = "0";
	private static final long serialVersionUID = 1L;
	public BehaviorFailException(){
		super();
	}
	public BehaviorFailException(String s) {
		super(s);
	}
	
	public BehaviorFailException(String errorCode, String classMethodName, String errorMessage) {
		super(errorMessage);
		if (errorCode.trim().length() == 4)
			errorCode = "0" + errorCode.trim();
		this.errorCode = errorCode;
		this.classMethodName = classMethodName;
	}
	public String getErrorLocation() {
		return classMethodName;
	}
	public String getErrorCode() {
		return errorCode;
	}
}
