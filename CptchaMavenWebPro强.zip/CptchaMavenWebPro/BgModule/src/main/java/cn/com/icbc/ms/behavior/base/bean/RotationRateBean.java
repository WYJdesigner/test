/**
* @author Dabing
* @E-mail chenbinging@outlook.com
* @date 2018-12-19上午11:30:36
* 类说明
*/
package cn.com.icbc.ms.behavior.base.bean;

public class RotationRateBean {

	private float alpha;
	private float beta;
	private float gamma;
	public float getAlpha() {
		return alpha;
	}
	public void setAlpha(float alpha) {
		this.alpha = alpha;
	}
	public float getBeta() {
		return beta;
	}
	public void setBeta(float beta) {
		this.beta = beta;
	}
	public float getGamma() {
		return gamma;
	}
	public void setGamma(float gamma) {
		this.gamma = gamma;
	}
	
}
