/**
* @author Dabing
* @E-mail chenbinging@outlook.com
* @date 2018-10-29下午11:23:36
* 类说明
*/
package cn.com.icbc.ms.behavior.base.bean;

public class ImageTextPoint {
	
	private String txt;
	private int pointX;
	private int pointY;
	private int isCheck;
	
	public ImageTextPoint(String txt, int isCheck) {
		this.txt = txt;
		this.isCheck = isCheck;
	}
	public ImageTextPoint(String txt, int x, int y) {
		this.txt = txt;
		this.pointX = x;
		this.pointY = y;
	}
	public ImageTextPoint(String txt, int x, int y, int isCheck) {
		this.txt = txt;
		this.pointX = x;
		this.pointY = y;
		this.isCheck = isCheck;
	}
	public String getTxt() {
		return txt;
	}
	public void setTxt(String txt) {
		this.txt = txt;
	}
	public int getPointX() {
		return pointX;
	}
	public void setPointX(int pointX) {
		this.pointX = pointX;
	}
	public int getPointY() {
		return pointY;
	}
	public void setPointY(int pointY) {
		this.pointY = pointY;
	}
	public int getIsCheck() {
		return isCheck;
	}
	public void setIsCheck(int isCheck) {
		this.isCheck = isCheck;
	}

	
}
