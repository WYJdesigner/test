/**
* @author Dabing
* @E-mail chenbinging@outlook.com
* @date 2018-10-30下午5:28:11
* 浏览器信息
*/
package cn.com.icbc.ms.behavior.base.bean;

public class BrowserBean {

	private String user_agent;
	private String language;
	private int timezone_offset;
	private int add_behavior;
	private String cpu_class;
	private String navigator_platform;
	private String do_not_track;
	private String regular_plugins;
	private int color_depth;
	private String resolution;
	private int session_storage;
	private int local_storage ;
	private int indexed_db;
	private int open_database;
	public String getUser_agent() {
		return user_agent;
	}
	public void setUser_agent(String user_agent) {
		this.user_agent = user_agent;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public int getTimezone_offset() {
		return timezone_offset;
	}
	public void setTimezone_offset(int timezone_offset) {
		this.timezone_offset = timezone_offset;
	}
	public int getAdd_behavior() {
		return add_behavior;
	}
	public void setAdd_behavior(int add_behavior) {
		this.add_behavior = add_behavior;
	}
	public String getCpu_class() {
		return cpu_class;
	}
	public void setCpu_class(String cpu_class) {
		this.cpu_class = cpu_class;
	}
	public String getNavigator_platform() {
		return navigator_platform;
	}
	public void setNavigator_platform(String navigator_platform) {
		this.navigator_platform = navigator_platform;
	}
	public String getDo_not_track() {
		return do_not_track;
	}
	public void setDo_not_track(String do_not_track) {
		this.do_not_track = do_not_track;
	}
	public String getRegular_plugins() {
		return regular_plugins;
	}
	public void setRegular_plugins(String regular_plugins) {
		this.regular_plugins = regular_plugins;
	}
	public int getColor_depth() {
		return color_depth;
	}
	public void setColor_depth(int color_depth) {
		this.color_depth = color_depth;
	}
	public String getResolution() {
		return resolution;
	}
	public void setResolution(String resolution) {
		this.resolution = resolution;
	}
	public int getSession_storage() {
		return session_storage;
	}
	public void setSession_storage(int session_storage) {
		this.session_storage = session_storage;
	}
	public int getLocal_storage() {
		return local_storage;
	}
	public void setLocal_storage(int local_storage) {
		this.local_storage = local_storage;
	}
	public int getIndexed_db() {
		return indexed_db;
	}
	public void setIndexed_db(int indexed_db) {
		this.indexed_db = indexed_db;
	}
	public int getOpen_database() {
		return open_database;
	}
	public void setOpen_database(int open_database) {
		this.open_database = open_database;
	}
	@Override
	public String toString() {
		return "BrowserBean [user_agent=" + user_agent + ", language="
				+ language + ", timezone_offset=" + timezone_offset
				+ ", add_behavior=" + add_behavior + ", cpu_class=" + cpu_class
				+ ", navigator_platform=" + navigator_platform
				+ ", do_not_track=" + do_not_track + ", regular_plugins="
				+ regular_plugins + ", color_depth=" + color_depth
				+ ", resolution=" + resolution + ", session_storage="
				+ session_storage + ", local_storage=" + local_storage
				+ ", indexed_db=" + indexed_db + ", open_database="
				+ open_database + "]";
	}
	
}
