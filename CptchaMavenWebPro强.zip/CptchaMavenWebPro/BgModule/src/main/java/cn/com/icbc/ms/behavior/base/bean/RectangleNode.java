package cn.com.icbc.ms.behavior.base.bean;

public class RectangleNode {
	public int xRangePoint = 0;
	public int yRangePoint = 0;
	public int maxRangeInteger = 0;
}
