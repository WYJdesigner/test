package cn.com.icbc.ms.behavior.component;

/**
 * Created with IntelliJ IDEA.
 * User: luke lee
 * Date: 2021/1/14
 * Time: 10:25
 * Chinese Description:构件回调
 * English description:
 */

/*
* 这段代码是一个 Java 接口（interface）的定义，名为 `IMUniCerInterface`。接口是一种抽象的类似于合同的结构，

1. **常量定义**：
   - `ERROR_1`：这是一个接口中定义的常量，其值为字符串 "-1"。常量是不可变的值，通常用于在代码中引用一些固定的值，以提高代码的可读性和维护性。在这里，`ERROR_1` 似乎表示某种错误状态。
   - `SUCCESS`：同样是一个接口中定义的常量，其值为字符串 "1"。这个常量可能表示某种成功状态或者操作成功完成。

2. **抽象方法定义**：
   - `IMSaveStorage(String key, String value)`：这是一个抽象方法（没有方法体），用于保存数据到某个存储介质中。它接受两个参数，一个是键（key），用于唯一标识保存的数据，另一个是值（value），是要保存的数据内容。
   - `IMGetStorage(String key)`：同样是抽象方法，用于从存储介质中获取数据。它接受一个键作为参数，返回与该键相关联的数据。
   - `IMCleanStorage(String key)`：这也是一个抽象方法，用于从存储介质中删除与指定键相关的数据。
*
* */
public interface IMUniCerInterface {
	public static final String ERROR_1 = "-1";
	public static final String SUCCESS = "1";
    public String IMSaveStorage(String key, String value);

    public String IMGetStorage(String key);

    public String IMCleanStorage(String key);
}
