package cn.com.icbc.ms.behavior.utils;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.PropertyResourceBundle;

import cn.com.icbc.ms.behavior.base.bean.LatticeSegmentationBean;

/*
* 这段代码定义了一个名为 ConfigUtil 的 Java 类，它似乎是用于读取和管理配置信息的工具类。
 * */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class ConfigUtil {
	/*
	* 这些是类的静态属性，用于存储配置信息和其他数据。
	* configBundle 和 traitAttackBundle 存储了配置文件的资源包。
	* ParamMap 存储一般配置参数的键值对。
	* PointMap 和 PointImgMap 存储特定配置参数的集合，使用键值对应。
	* TraitList 存储特征攻击的关键字列表。
	* */
	private static PropertyResourceBundle configBundle = null;
	private static PropertyResourceBundle traitAttackBundle = null;
	private static Hashtable<String, String> ParamMap;
	private static Hashtable<String, ArrayList> PointMap;
	private static Hashtable<String, ArrayList> PointImgMap;
	private static ArrayList<String> TraitList;
	/*
	* 这个静态初始化块在类加载时执行，用于初始化静态属性。
	 * */
	static {
		ParamMap = new Hashtable();
		PointMap = new Hashtable();
		PointImgMap = new Hashtable();
		TraitList = new ArrayList<String>();
		//初始化配置文件
		try{
			configBundle = (PropertyResourceBundle) PropertyResourceBundle
				.getBundle("behavior");
		}catch (Exception ex) {
			configBundle  = null;
		}
		try{
			traitAttackBundle = (PropertyResourceBundle) PropertyResourceBundle
				.getBundle("traitAttack");
		}catch (Exception ex) {
			traitAttackBundle  = null;
		}
		
		//验证码参数
		setParam("m_iHashMapSize", getStrConfig("m_iHashMapSize"));
		setParam("m_defaultTimeout", getStrConfig("m_defaultTimeout"));
		setParam("m_loadFactor", getStrConfig("m_loadFactor"));
		setParam("system.encoding", getStrConfig("system.encoding"));//文字验证码的编码格式
		setParam("behavior.codeSequence", getStrConfig("behavior.codeSequence"));//文字验证码的文字库
		setParam("behavior.idiomSequence", getStrConfig("behavior.idiomSequence"));//成语语义验证码的文字库
		setParam("behavior.fountPointRandomCount", getStrConfig("behavior.fountPointRandomCount"));//文字验证码的随机文字获取最大次数 程序里面默认50
		setParam("behavior.randomPMultiple", getStrConfig("behavior.randomPMultiple"));//文字验证码的随机文字分片倍数 程序里面默认2
		setParam("behavior.limitRandomPointCountNum", getStrConfig("behavior.limitRandomPointCountNum"));//文字验证码的随机文字保持在内存点集合的个数默认是1000
		setParam("behavior.defaultXoffset", getStrConfig("behavior.defaultXoffset"));//行为验证x轴偏移量
		setParam("behavior.defaultYoffset", getStrConfig("behavior.defaultYoffset"));//行为验证y轴偏移量
		setParam("behavior.defaultDuration", getStrConfig("behavior.defaultDuration"));//行为验证第一次点击和第二次点击间隔
		setParam("behavior.defaultInterval", getStrConfig("behavior.defaultInterval"));//行为验证点击的总时间
		setParam("behavior.randomImgNum", getStrConfig("behavior.randomImgNum"));//文字验证码的图片信息缓存数量
		setParam("behavior.fountPointRandomTimeOut", getStrConfig("behavior.fountPointRandomTimeOut"));//文字验证码的获取随机文字超时时间默认30s
		setParam("behavior.bgWidthStandard", getStrConfig("behavior.bgWidthStandard"));//文字验证码最小宽度
		setParam("behavior.bgHeightStandard", getStrConfig("behavior.bgHeightStandard"));//文字验证码最小高度
		setParam("behavior.bgWidthMaxStandard", getStrConfig("behavior.bgWidthMaxStandard"));//文字验证码最大宽度
		setParam("behavior.bgHeightMaxStandard", getStrConfig("behavior.bgHeightMaxStandard"));//文字验证码最大高度
		setParam("behavior.cacheIMGFlag", getStrConfig("behavior.cacheIMGFlag"));//是否缓存图片及其点数据
		setParam("behavior.cacheIMGUsedNum", getStrConfig("behavior.cacheIMGUsedNum"));//缓存图片可使用次数
		setParam("behavior.ratioPathArray", getStrConfig("behavior.ratioPathArray"));//缓存图片分辨率集合300#200@400#600
		setParam("behavior.fountPointRandomTimeOutSecond", getStrConfig("behavior.fountPointRandomTimeOutSecond"));//文字点选验证码获取点超时时间
		setParam("behavior.pubModule",getStrConfig("behavior.pubModule"));
		setParam("behavior.pubExponen",getStrConfig("behavior.pubExponen"));
		setParam("behavior.priModule",getStrConfig("behavior.priModule"));
		setParam("behavior.priExponen",getStrConfig("behavior.priExponen"));
		//nos 相关配置
		//特征攻击初始化
		initTraitList();
	}
	/*
	* 这个方法用于将配置参数添加到 ParamMap 中，将键值对存储起来。
	 * */
	public static void setParam(String key, String value) {
		if (value != null) {
			ParamMap.put(key, value);
		}
	}
	/*
	* 这个私有方法用于获取配置文件中指定参数名的字符串值，并返回。
	* 如果未找到或出现异常，则返回 null。
	 * */
	private static String getStrConfig(String param) {
		try {
			String result = configBundle.getString(param);
			if (result == null || result.isEmpty()) {
				return null;
			}
			return result.trim();
		} catch (Exception ex) {
			return null;
		}
	}
	/*
	* 这个方法用于从 ParamMap 中获取指定键的参数值，并返回。如果未找到或出现异常，则返回 null。
	 * */
	public static String getParamAsStr(String key) {
		try {
			String param = ParamMap.get(key);
			if (param == null || param.isEmpty()) {
				return null;
			}
			return param;
		} catch (Exception ex) {
			return null;
		}
	}
	/*
	* 这个方法用于从 PointImgMap 中获取指定键的参数值，返回一个 ArrayList。
	* 如果未找到或出现异常，则返回 null。
	* */
	public static ArrayList getPointImgAsList(String key) {
		try {
			ArrayList param = PointImgMap.get(key);
			if (param == null || param.isEmpty()) {
				return null;
			}
			return param;
		} catch (Exception ex) {
			return null;
		}
	}
	/*
	* 这两个方法用于移除和添加 PointImgMap 中的键值对。
	* */
	public static void removePointImgAsList(String key) {
		PointImgMap.remove(key);
	}
	public static void putPointImgAsList(String key,ArrayList list) {
		PointImgMap.put(key,list);
	}
	/*
	* 这两个方法用于获取和设置 PointMap 中的键值对。
	 * */
	public static ArrayList getPointAsStr(String key) {
		try {
			ArrayList param = PointMap.get(key);
			if (param == null || param.isEmpty()) {
				return null;
			}
			return param;
		} catch (Exception ex) {
			return null;
		}
	}
	public static void putPointAsStr(String key,ArrayList list) {
		PointMap.put(key,list);
	}
	/*
	* 这个方法用于将所有配置参数和对应的值以字符串形式返回。
	 * */
	public static String printAll() {
		StringBuilder sb = new StringBuilder();
		Iterator iter = ParamMap.keySet().iterator();
		String name = "", val = "";
		while (iter.hasNext()) {
			name = (String) iter.next();
			val = (String) ParamMap.get(name);
			sb.append(name + "=" + val + "<br/>");
		}
		return sb.toString();
	}
	/**
	 * 初始化特征攻击key值
	 * @param str
	 */
	private static void initTraitList(){
		try{
		Enumeration<String> tkey = traitAttackBundle.getKeys();
			while(tkey.hasMoreElements()){
				TraitList.add(traitAttackBundle.getString(tkey.nextElement()));
			}
		}catch(Exception e){
			TraitList.clear();
		}
	}
	/**
	 * 返回特征攻击关键字列表
	 * @return
	 */
	public static ArrayList<String> getTraitList(){
		return TraitList;
	}
}
