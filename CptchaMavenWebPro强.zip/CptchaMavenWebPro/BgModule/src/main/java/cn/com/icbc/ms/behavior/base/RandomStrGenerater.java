package cn.com.icbc.ms.behavior.base;

import cn.com.icbc.ms.behavior.utils.StringUtils;
import cn.com.icbc.ms.behavior.utils.SysLog;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;

public class RandomStrGenerater {

	// 生成长度为len最大值为5的随机串
	public static String generateString(int len) {

		String str = "";
		SecureRandom sRandom = null;
		try {
			sRandom = SecureRandom.getInstance("SHA1PRNG");
		} catch (NoSuchAlgorithmException e) {
			SysLog.println(e.toString());
		}
		
		for (int i = 0; i < len; i++) {
			// Random random = new Random();
			if(sRandom == null){
				str += 0;
			}else {
				str += sRandom.nextInt(6);
			}
		}
		return str;
	}
	
	//生成长度为20的随机字符串
	 public static String generateString() {
		  // Random random = new Random();
		  SecureRandom sRandom = null;
		  try {
				sRandom = SecureRandom.getInstance("SHA1PRNG");
			} catch (NoSuchAlgorithmException e) {
				SysLog.println(e.toString());
			}
		  byte[] nbyte = new byte[10];
		  if(sRandom == null){
			  return "00000000000000000000";
		  }
		  sRandom.nextBytes(nbyte);
      	  String str = bytesToHexString(nbyte);
      	  return str;
	 }
		 
	 public static String bytesToHexString(byte[] src){  
		    StringBuilder stringBuilder = new StringBuilder("");  
		    if (src == null || src.length <= 0) {  
		        return null;  
		    }  
		    for (int i = 0; i < src.length; i++) {  
		        int v = src[i] & 0xFF;  
		        String hv = Integer.toHexString(v);  
		        if (hv.length() < 2) {  
		            stringBuilder.append(0);  
		       }  
		        stringBuilder.append(hv);  
		    }  
		    return stringBuilder.toString();  
	 }

	// 返回小于指定参数的随机数
	public static int generateRandom(int i) {
		//Random random = new Random();
		SecureRandom sRandom = null;
		try {
			sRandom = SecureRandom.getInstance("SHA1PRNG");
		} catch (NoSuchAlgorithmException e) {
			SysLog.println(e.toString());
		}
		if(sRandom == null){
			return i;
		}
		return sRandom.nextInt(i);
	}
	/*
	 * 生成随机字符串32位
	 * */
	public static String generateRandomNumber() {
		// 创建一个安全的随机数生成器
		SecureRandom secureRandom = new SecureRandom();
		// 生成随机字符串
		StringBuilder sb = new StringBuilder(32);
		for (int i = 0; i < 32; i++) {
			int randomNumber = secureRandom.nextInt(10); // 生成 0-9 之间的随机整数
			sb.append(randomNumber);
		}
		return sb.toString();
	}
	/*
	* 根据uuid生成随机字符串
	* */
	public static String processString(String input) {
		if (StringUtils.isEmpty(input)) return "";
		input = input.replace("-","");
		StringBuilder result = new StringBuilder();
		for (char c : input.toCharArray()) {
			if (Character.isDigit(c)) {
				result.append(c);
			} else {
				int asciiValue = (int) c; // 获取字符的ASCII值
				result.append(asciiValue);
			}
		}
		String processedString = result.toString();
		if (processedString.length() > 32) {
			processedString = processedString.substring(0, 32);
		} else if (processedString.length() < 32) {
			int zeroPadding = 32 - processedString.length();
			StringBuilder zeroPaddedResult = new StringBuilder(processedString);
			for (int i = 0; i < zeroPadding; i++) {
				zeroPaddedResult.append('0');
			}
			processedString = zeroPaddedResult.toString();
		}
		return processedString;
	}
}
