/**
* @author Dabing
* @E-mail chenbinging@outlook.com
* @date 2018-10-24下午5:28:37
* 类说明
*/
package cn.com.icbc.ms.behavior.utils;

public class StringUtils {

	public static boolean isEmpty(String str) {
		if (str == null || str.equals("")) {
			return true;
		} else {
			return false;
		}
	}
}
