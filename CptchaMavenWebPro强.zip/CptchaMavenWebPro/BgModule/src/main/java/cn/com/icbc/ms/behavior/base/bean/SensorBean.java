/**
* @author Dabing
* @E-mail chenbinging@outlook.com
* @date 2018-12-19上午11:23:27
* 传感器
*/
package cn.com.icbc.ms.behavior.base.bean;

import java.util.ArrayList;

public class SensorBean {

	private ArrayList<OrientationBean> orientation;
	private ArrayList<AccelerationBean> acceleration;
	private ArrayList<AccelerationIncludingGravityBean> accelerationIncludingGravity;
	private ArrayList<RotationRateBean> rotationRate;
	public ArrayList<OrientationBean> getOrientation() {
		return orientation;
	}
	public void setOrientation(ArrayList<OrientationBean> orientation) {
		this.orientation = orientation;
	}
	public ArrayList<AccelerationBean> getAcceleration() {
		return acceleration;
	}
	public void setAcceleration(ArrayList<AccelerationBean> acceleration) {
		this.acceleration = acceleration;
	}
	public ArrayList<AccelerationIncludingGravityBean> getAccelerationIncludingGravity() {
		return accelerationIncludingGravity;
	}
	public void setAccelerationIncludingGravity(
			ArrayList<AccelerationIncludingGravityBean> accelerationIncludingGravity) {
		this.accelerationIncludingGravity = accelerationIncludingGravity;
	}
	public ArrayList<RotationRateBean> getRotationRate() {
		return rotationRate;
	}
	public void setRotationRate(ArrayList<RotationRateBean> rotationRate) {
		this.rotationRate = rotationRate;
	}
	
	
}
