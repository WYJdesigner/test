package cn.com.icbc.ms.behavior.utils;

import java.util.ArrayList;
/**
 * 特征攻击校验
 * @author kfzx-zhangzj
 *
 */
public class TraitAttackUtil {
	
	public TraitAttackUtil(){
		
	}
	/**
	 * userAgent特征攻击验证
	 * @param userAgent
	 * @return
	 */
	public boolean verifyUserAgernt(String userAgent){
		boolean retFlag = true;
		ArrayList<String> traitList = ConfigUtil.getTraitList();
		for(String tempStr :traitList){
			if(userAgent.indexOf(tempStr)>=0){
				retFlag = false;
				break;
			}
		}
		return  retFlag;
	}
}
