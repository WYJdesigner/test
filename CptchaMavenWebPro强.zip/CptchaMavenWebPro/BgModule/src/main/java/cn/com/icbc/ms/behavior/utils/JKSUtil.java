package cn.com.icbc.ms.behavior.utils;

import javax.swing.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;

public class JKSUtil {
    /*
    *
    * */
    public static PublicKey getPublicKey(String keyStoreFile,String storeFilePass,String keyAlias) {
        //读取密钥时所用到的工具类
        KeyStore ks;
        //公钥类所对应的类
        PublicKey pubkey = null;
        try {
            //得到实例对象
            ks = KeyStore.getInstance("JKS");
            FileInputStream fin;
            try {
                //读取JKS文件
                fin = new FileInputStream(keyStoreFile);
                try {
                    //读取公钥
                    ks.load(fin,storeFilePass.toCharArray());
                    java.security.cert.Certificate cert = ks.getCertificate(keyAlias);
                    pubkey = cert.getPublicKey();
                    fin.close();
                } catch (NoSuchAlgorithmException e) {
                    SysLog.println(e.toString());
                } catch (CertificateException e) {
                    SysLog.println(e.toString());
                } catch (IOException e) {
                    SysLog.println(e.toString());
                }
            }catch (FileNotFoundException e) {
                SysLog.println(e.toString());
                SysLog.println(e.toString());

            }
        } catch (KeyStoreException e) {
            SysLog.println(e.toString());
        }
        return pubkey;
    }
    /*
    * 得到私钥
    * @param keyStoreFile
    *       私钥文件
    *
    * @param storeFilePass
    *       私钥文件密码
    *
    * @param keyAlias
    *       别名
    *
    * @param keyAliasPass
    *       密码
    *
    * */
    public static PrivateKey getPrivateKey(String keyStoreFile,
                                           String storeFilePass,
                                           String keyAlias,
                                           String keyAliasPass) {
        KeyStore ks;
        PrivateKey prikey = null;
        try {
            ks = KeyStore.getInstance("JKS");
            FileInputStream fin;
            try {
                fin = new FileInputStream((keyStoreFile));
                try {
                    try {
                        ks.load(fin, storeFilePass.toCharArray());
                        //先打开文件
                        prikey = (PrivateKey) ks.getKey(keyAlias, keyAliasPass.toCharArray());
                        fin.close();
                        // 通过别名和密码得到私钥
                    } catch (UnrecoverableKeyException e) {
                        SysLog.println(e.toString());
                    } catch (CertificateException e) {
                        SysLog.println(e.toString());
                    } catch (IOException e) {
                        SysLog.println(e.toString());
                    }
                } catch (NoSuchAlgorithmException e) {
                    SysLog.println(e.toString());
                }
            } catch (FileNotFoundException e) {
                SysLog.println(e.toString());
            }
        } catch (KeyStoreException e) {
            SysLog.println(e.toString());
        }
        return prikey;
    }
}
