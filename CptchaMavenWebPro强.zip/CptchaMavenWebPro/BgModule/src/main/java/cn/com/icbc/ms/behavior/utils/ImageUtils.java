/**
* @author Dabing
* @E-mail chenbinging@outlook.com
* @date 2018-10-18下午4:21:15
* 图片处理类
*/
package cn.com.icbc.ms.behavior.utils;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.GeneralPath;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Random;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import cn.com.icbc.ms.behavior.base.bean.LatticeSegmentationBean;
import cn.com.icbc.ms.behavior.base.bean.RectangleArea;
import cn.com.icbc.ms.behavior.exception.BehaviorFailException;

public class ImageUtils {
	
	// 图片的宽度
//    private static final int CAPTCHA_WIDTH = 300;
    // 图片的高度
//    private static final int CAPTCHA_HEIGHT = 100;
    // 验证码的个数
//    private static final int CAPTCHA_CODECOUNT = 4;
//	private static final int CAPTCHA_FONT_HEIGHT = CAPTCHA_HEIGHT/5; //18;
//    private static final int CAPTCHA_CODE_Y = CAPTCHA_HEIGHT/2; //16;
	private static final int limitRandomPointCountNumDF = 1000;
    private static final char[] codeSequence = { 
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 
        'H', 'I', 'J', 'K', 'L', 'M', 'N', 
        'O', 'P', 'Q', 'R', 'S', 'T', 
        'U', 'V', 'W', 'X', 'Y', 'Z', 
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
    private final int timeOutSecond = 30;
    /**
     * 获取图片buffer
     * @param path
     * @return
     */
	public BufferedImage getImageBuffer(String path) {
		if (StringUtils.isEmpty(path)) {
			return null;
		}
		File file = new File(path);
        FileInputStream inputStream = null;
        BufferedImage imageQR = null;
		try {
			inputStream = new FileInputStream(file);
			imageQR = ImageIO.read(inputStream);
			inputStream.close();
			inputStream = null;
		} catch (Exception e) {
			SysLog.println(e.toString());
			SysLog.println("Captcha--ImageUtils--getImageBuffer--Stream==" + e.toString());
		} finally {
			if(inputStream != null){
				try {
					inputStream.close();
				} catch (IOException e) {
					SysLog.println(e.toString());
				}
			}
		}
		return imageQR;
	}
	
	/**
	 * 从图片中随机生成滑动验证码的坐标点
	 * @param imageQR
	 * @return
	 */
	public int[] randomPoint (BufferedImage imageQR) {
		int width = imageQR.getWidth();
        int height = imageQR.getHeight();
        
        int rWidth = 0;
        int rHeight = 0;
        if (width < 60 || height < 60) {
        	return new int[]{10, 10};
    	} else if (width < 150 || height < 100) {
    		return new int[]{80, 10};
    	} else {
    		// Random random = new Random();
    		SecureRandom sRandom = null;
			try {
				sRandom = SecureRandom.getInstance("SHA1PRNG");
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				SysLog.println(e.toString());
			}
			if(sRandom == null){
				return new int[]{60, 60};
			}
    		do {
    			rWidth = sRandom.nextInt(width);
    		} while (rWidth < 60 || rWidth > width -70);
    		do {
    			rHeight = sRandom.nextInt(height);
    		} while (rHeight < 10 || rHeight > height -70);
    		
    		return new int[]{rWidth, rHeight};
    	}
	}
	
	public int[] randomPoint (int w1, int h1, int w2, int h2) {
        int rWidth = 0;
        int rHeight = 0;
        if (w1 < 60 || h1 < 60) {
        	return new int[]{10, 10};
    	} else if (w1 < 150 || h1 < 100) {
    		return new int[]{80, 10};
    	} else {
    		// Random random = new Random();
    		SecureRandom sRandom = null;
			try {
				sRandom = SecureRandom.getInstance("SHA1PRNG");
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				SysLog.println(e.toString());
				SysLog.println("Captcha--ImageUtils--randomPoint--getInstance==" + e.toString());
			}
			if(sRandom == null){
				return new int[]{60, 60};
			}
    		do {
    			rWidth = sRandom.nextInt(w1);
    		} while (rWidth < w2 || rWidth > w1 - w2);
    		do {
    			rHeight = sRandom.nextInt(h1);
    		} while (rHeight < 30 || rHeight > h1 - h2);
    		
    		return new int[]{rWidth, rHeight};
    	}
	}
	
	/**
	 * 从图片中随机生成图文验证码的坐标点
	 * @param imageQR 图片资源
	 * @param count 数量
	 * @return
	 * 修改2021年3月18日，修改内容：
	 * 临时方案增加最后一个随机点的随机阀值 如果到阀值无法获取到结果回退第三个点重新获取
	 * @throws BehaviorFailException 
	 */
	public ArrayList<LatticeSegmentationBean> randomPoint (int width, int height, int count) throws BehaviorFailException {
		ArrayList<LatticeSegmentationBean> m_tempAry = new ArrayList<LatticeSegmentationBean>();
        String paramName = "randomPoint"+count+width+height;
        ArrayList<ArrayList<LatticeSegmentationBean>> PointList = new ArrayList<ArrayList<LatticeSegmentationBean>>();
        
        int fountPointRandomCount = ConfigUtil.getParamAsStr("behavior.fountPointRandomCount") == null? 50 : Integer.parseInt(ConfigUtil.getParamAsStr("behavior.fountPointRandomCount"));
        int index = 0;
        int piontCount = 0;
        if(count>3){
        	try {
        		m_tempAry = randomIntAndVerify1(width, height, count, 40);
				ArrayList<LatticeSegmentationBean> m_tempAryCopy = new ArrayList<LatticeSegmentationBean>();
				for (int i = 0; i < m_tempAry.size(); i++) {
					LatticeSegmentationBean tt = m_tempAry.get(i);
					m_tempAryCopy.add(new LatticeSegmentationBean(tt.getM_xRangePoint(),tt.getM_yRangePoint()));
				}
				PointList.add(m_tempAryCopy);
				ConfigUtil.putPointAsStr(paramName, PointList);
        	} catch (Exception e) {
        		SysLog.println(e.toString());
        		SysLog.println("Captcha--ImageUtils--randomPoint--randomIntAndVerify1==" + e.toString());
        	}     
        	return m_tempAry;
        }
        
        int timeOut = ConfigUtil.getParamAsStr("behavior.fountPointRandomTimeOut")== null?timeOutSecond:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.fountPointRandomTimeOut"));
		Calendar c  = new GregorianCalendar();
		c.setTime(new Date());
		c.add(Calendar.SECOND, timeOut);
		
        while (index < count) {
        	Calendar c1  = new GregorianCalendar();
			c1.setTime(new Date());
			if(c1.getTimeInMillis()>c.getTimeInMillis()){
				throw new BehaviorFailException(this.getClass().getName()+"获取随机点超时失败!");
			}
        	int tempX = 0;
        	int tempY = 0;
        	tempX = randomInt(width);
        	tempY = randomInt(height);

        	boolean flag = false;
        	//如果设置的阀值和当前循环一致去掉前一个节点
        	if(fountPointRandomCount == piontCount){
        		m_tempAry.remove(m_tempAry.size()-1);
        		index --;
        		piontCount = 0;
        	}
        	for (LatticeSegmentationBean bean : m_tempAry) {
        		if (bean.getM_xRangePoint() > (tempX - 40) && bean.getM_xRangePoint() < (tempX + 40) && bean.getM_yRangePoint() > (tempY - 40) && bean.getM_yRangePoint() < (tempY + 40)) {
        			flag = true;
        			 if (count - 1 != m_tempAry.size()) piontCount++;
        			break;
        		}
    		}
        	if (!flag) {
        		LatticeSegmentationBean lsObject = new LatticeSegmentationBean(tempX, tempY);
        		m_tempAry.add(lsObject);
        		index++;
        		piontCount = 0;
        		
        	}
        }
        //System.out.println("-------------初始化完成------------------");
		ArrayList<LatticeSegmentationBean> m_tempAryCopy = new ArrayList<LatticeSegmentationBean>();
		for (int i = 0; i < m_tempAry.size(); i++) {
			LatticeSegmentationBean tt = m_tempAry.get(i);
			m_tempAryCopy.add(new LatticeSegmentationBean(tt.getM_xRangePoint(),tt.getM_yRangePoint()));
		}
		PointList.add(m_tempAryCopy);
		ConfigUtil.putPointAsStr(paramName, PointList);
        return m_tempAry;
	}
	
	
	/**
	 * 将图片buffer输入到本地文件中
	 * @param bufferedImage
	 * @param path
	 * @param formatName
	 */
	public void BufferedImageToFile(BufferedImage bufferedImage, String path, String formatName) {
		if (bufferedImage == null) {
			return;
		}
		if (StringUtils.isEmpty(path) || StringUtils.isEmpty(formatName)) {
			return;
		}
        try {
			ImageIO.write(bufferedImage, formatName, new File(path + "." + formatName));
		} catch (IOException e) {
			SysLog.println(e.toString());
			SysLog.println("Captcha--ImageUtils--BufferedImageToFile--ImageIO.write==" + e.toString());
		}
	}

	private int randomInt (int i) {
		//Random r = new Random();
		SecureRandom sRandom = null;
		try {
			sRandom = SecureRandom.getInstance("SHA1PRNG");
		} catch (NoSuchAlgorithmException e) {
			SysLog.println(e.toString());
			SysLog.println("Captcha--ImageUtils--randomInt--getInstance==" + e.toString());
		}
		if(sRandom == null){
			return 41;
		}
		int temp = 0;
    	do {
    		temp = sRandom.nextInt(i);
		} while (temp < 40 || temp > i -40);
    	
    	return temp;
	}

	/**
	 * 随机方法测试
	 * @param width
	 * @param height
	 * @param count
	 * @param stepLength
	 * @return
	 * @throws BehaviorFailException 
	 * @throws NoSuchAlgorithmException 
	 */
	private ArrayList<LatticeSegmentationBean> randomIntAndVerify1(int width, int height, int count, int stepLength) throws BehaviorFailException, NoSuchAlgorithmException {
		ArrayList<LatticeSegmentationBean> ary = new ArrayList<LatticeSegmentationBean>();
		// 初始化数据 渲染区域设置各个点的初始值为0
		int timeOut = ConfigUtil.getParamAsStr("behavior.fountPointRandomTimeOutSecond")== null?timeOutSecond:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.fountPointRandomTimeOutSecond"));
		Calendar c  = new GregorianCalendar();
		c.setTime(new Date());
		c.add(Calendar.SECOND, timeOut);
		int[][] areaArray = new int[height][width];
		int tcount =2;
		int ttcount =2;
		int fountPointRandomCount = ConfigUtil.getParamAsStr("behavior.fountPointRandomCount") == null? 50 : Integer.parseInt(ConfigUtil.getParamAsStr("behavior.fountPointRandomCount"));
		int piontCount = 0;
		SecureRandom sRandom = SecureRandom.getInstance("SHA1PRNG");
		while (ary.size() < count) {
			Calendar c1  = new GregorianCalendar();
			c1.setTime(new Date());
			if(c1.getTimeInMillis()>c.getTimeInMillis()){
				SysLog.println("Captcha--ImageUtils--randomIntAndVerify1--TimeInMillis==");
			}
			int tempX = 0;
			int tempY = 0;
			if(fountPointRandomCount == piontCount){
				ary.remove(ary.size()-1);
				SysLog.println("取值次数到达上限回退一个点后继续");
        		piontCount = 0;
        		continue;
        	}
			if (ary.size() >= 4) {
				HashMap<String,RectangleArea> retNodeAreaMap = new HashMap<String,RectangleArea>();
				int maxSquare = maxSquare(areaArray,stepLength,retNodeAreaMap,ary);
					// Random rd = new Random();
					if(maxSquare <= 0){
						ary.remove(ary.size()-1);
						tcount--;
						areaArray = fmatrix(width, height, stepLength, ary);
						SysLog.println("回退一点");						
						if(tcount==0){
							SysLog.println("回退二点");	
							ary.remove(ary.size()-1);
							ary.remove(ary.size()-1);
							areaArray = fmatrix(width, height, stepLength, ary);
							tcount =2;
							ttcount--;
						}
						if(ttcount==0){
							ary.clear();
							areaArray = new int[height][width];
							ttcount = 2;
						}
						continue;
					}
					int getInt = sRandom.nextInt(retNodeAreaMap.size());
					int countInt  = 0;
					RectangleArea tempArea = null;
					for (String key :retNodeAreaMap.keySet() ) {
						if(countInt == getInt ){
							tempArea=retNodeAreaMap.get(key);
							break;
						}
						countInt++;
					}
					if(tempArea == null){
						tempX = randomInt(width);
						tempY = randomInt(height);
					} else {
						do {
							tempX = sRandom.nextInt(tempArea.xAreaPointRight-tempArea.xAreaPointLeft)%(tempArea.xAreaPointRight-tempArea.xAreaPointLeft)+tempArea.xAreaPointLeft;
						} while (tempX < stepLength || tempX > width -stepLength);
						do {
							tempY = sRandom.nextInt(tempArea.yAreaPointBottom-tempArea.yAreaPointTop)%(tempArea.yAreaPointBottom-tempArea.yAreaPointTop)+tempArea.yAreaPointTop;
						} while (tempY < stepLength || tempY > height -stepLength);
					}
				
			} else {
				tempX = randomInt(width);
				tempY = randomInt(height);
			}
			SysLog.println("随机到的点是"+tempX+","+tempY);	
			boolean flag = false;
			for (LatticeSegmentationBean bean : ary) {
				if (bean.getM_xRangePoint() > (tempX - 40) && bean.getM_xRangePoint() < (tempX + 40)
						&& bean.getM_yRangePoint() > (tempY - 40) && bean.getM_yRangePoint() < (tempY + 40)) {
					flag = true;
					piontCount++;
					break;
				}
			}
			if (!flag) {
				LatticeSegmentationBean lsObject = new LatticeSegmentationBean(tempX, tempY);
				SysLog.println("随机到的点是"+tempX+","+tempY);
				ary.add(lsObject);
				//标记数组
				if(ary.size() < count){
					for (int i = 0; i < areaArray.length; i++) {
						for (int j = 0; j < areaArray[i].length; j++) {
							if(tempY-stepLength<=i&& i<=tempY+stepLength && tempX-stepLength<=j&& j<=tempX+stepLength ){
								areaArray[i][j] = 1;
							}
						}
					}
				}
			}
		}
		areaArray = null;
		return ary;
	}
	
	int[][] fmatrix(int width,int height,int stepLength,ArrayList<LatticeSegmentationBean> ary){
		int[][] areaArray = new int[height][width];
		for (LatticeSegmentationBean lsObject: ary) {
			int tempX = lsObject.getM_xRangePoint();
			int tempY = lsObject.getM_yRangePoint();
			for (int i = 0; i < areaArray.length; i++) {
				for (int j = 0; j < areaArray[i].length; j++) {
					if(tempY-stepLength<=i&& i<=tempY+stepLength && tempX-stepLength<=j&& j<=tempX+stepLength ){
						areaArray[i][j] = 1;
					}
				}
			}
		}
		return areaArray;
	}
	/**
	 * 计算二维矩阵内最大正方形的面积 如果大于（步长*2+1）*（步长*2+1） 则返回正常面积否则返回报错值小于0
	 * histogram法
	 * @param matrix
	 * @param stepLength
	 * @param retNodeAreaMap
	 * @return
	 */
	 public int maxSquare(int[][] matrix,int stepLength,HashMap<String,RectangleArea> retNodeAreaMap,ArrayList<LatticeSegmentationBean> ary) {
		    if(retNodeAreaMap==null || matrix == null ){
		    	return -999;
		    }
	        int row = matrix.length;  //行大小
	        int line = matrix[0].length;  //列大小
	        //一个与matrix相同大小的辅助数组
	        int[][] tmp = new int[row][line];

	        //将matrix的第一行和第一列元素直接存放到
	        for(int i=0;i<row;i++){
	            tmp[i][0] = matrix[i][0]==1?0:1;
	        }
	        for(int i=0;i<line;i++){
	            tmp[0][i] = matrix[0][i]==1?0:1;
	        }
	        for(int i=1;i<row;i++){
	            for(int j=1;j<line;j++){
	                if(matrix[i][j] == 0){
	                    tmp[i][j] = 
	                    Math.min(Math.min(tmp[i-1][j],tmp[i][j-1]),tmp[i-1][j-1]) + 1;
	                }
	                if(matrix[i][j] == 1){
	                    tmp[i][j] = 0;
	                }
	            }
	        }
	        int max=0;  //记录tmp中最大元素的值（tmp中元素值表示正方形的边长)
//for (int i = 0; i < matrix.length; i++) {
//	for (int j = 0; j < matrix[i].length; j++) {
//		System.out.print(matrix[i][j]);
//	}
//	 System.out.println();
//}
//	        System.out.println("-----------------------------");
	        RectangleArea tempRectangleArea = null;
	        for(int i=0;i<row;i++){
	            for(int j=0;j<line;j++){
	            	SysLog.println(tmp[i][j]+",");
	            	boolean flagSave = false;
	                if(tmp[i][j] > max && j<line-stepLength&&j>stepLength&&i>stepLength&&i<row-stepLength){
	                	boolean flag = false;
	                	for (LatticeSegmentationBean bean : ary) {
	        				if (bean.getM_xRangePoint() > (j - 40) && bean.getM_xRangePoint() < (j + 40)
	        						&& bean.getM_yRangePoint() > (i - 40) && bean.getM_yRangePoint() < (i + 40)) {
	        					flag = true;
	        					break;
	        				}
	        			}
	                	if(!flag){
	                		flagSave = true;
	                		max = tmp[i][j];
	                		tempRectangleArea = new RectangleArea();
	                		tempRectangleArea.xAreaPointLeft = j-1-max;
	                		tempRectangleArea.xAreaPointRight = j;
	                		tempRectangleArea.yAreaPointTop = i-1-max;
	                		tempRectangleArea.yAreaPointBottom = i;
	                		retNodeAreaMap.clear();
	                		retNodeAreaMap.put(i+""+j, tempRectangleArea);
	                	}
	                }else if(tmp[i][j] == max && flagSave){
	                	tempRectangleArea = new RectangleArea();
	                	tempRectangleArea.xAreaPointLeft = j-1-max;
	                    tempRectangleArea.xAreaPointRight = j;
	                    tempRectangleArea.yAreaPointTop = i-1-max;
	                    tempRectangleArea.yAreaPointBottom = i;
	                	retNodeAreaMap.put(i+""+j, tempRectangleArea);
	                }
	            }
//	            System.out.println();
	        }
//	        System.out.println("max==>"+max);
//	        if(max<stepLength*2+1){
//	        	retNodeAreaMap.clear();
//	        	return -998;
//	        }
	        return max*max;
	    }
	 
	/**
	 * 划分分片区域按两行多列处理
	 * @param randomP
	 * @return
	 */
	private HashMap<String,RectangleArea> getRectangleArea(int randomP,int width,int height,int stepLength){
		HashMap<String,RectangleArea> retMap = new HashMap<String,RectangleArea>();
		int key = 0;
		int MaxRandomPcount = 2*randomP;
		int ji = randomP/2;
		int dankuai = width/ji;
		 while(randomP>retMap.size()){
			 RectangleArea rectangleArea = null;
			 switch (retMap.size()%2) {
				case 0:
					rectangleArea = new RectangleArea();
					rectangleArea.xAreaPointLeft = dankuai*(retMap.size()/2)+stepLength;
					rectangleArea.xAreaPointRight = dankuai*(retMap.size()/2+1)-stepLength;
					rectangleArea.yAreaPointTop = 0+stepLength;
					rectangleArea.yAreaPointBottom = height/2;
					key++;
					retMap.put(key+"", rectangleArea);
					break;
				case 1:
					rectangleArea = new RectangleArea();
					rectangleArea.xAreaPointLeft = dankuai*(retMap.size()/2)+stepLength;
					rectangleArea.xAreaPointRight = dankuai*(retMap.size()/2+1)-stepLength;
					rectangleArea.yAreaPointTop = height%2==1?height/2+1+stepLength:height/2+stepLength;
					rectangleArea.yAreaPointBottom = height-stepLength;
					key++;
					retMap.put(key+"", rectangleArea);
					break;
				default:
					break;
			}
			 //如果循环次数超出了需要循环随机片的个数2倍就退出
			 MaxRandomPcount--;
			 if(MaxRandomPcount == 0){
//				 break;
				 return null;
			 }
		 }
		return retMap;
	}
	
	//wangJin, t 为random.nextInt(3);
		public GeneralPath drawPath(int blockWidth, int blockHeight, int[] t) {
			
			float sw = blockWidth / 5;
			float sh = blockHeight / 5;
			//Random random = new Random();
			int[] circle = new int[4];
			for (int i = 0; i < 4; i++) {
				//int t = random.nextInt(3);
				if(t[i] == 0) {
					circle[i] = 0;
				} else if (t[i] == 1){
					circle[i] = 1;
				} else {
					circle[i] = 2;
				}
			}
			GeneralPath gp = new GeneralPath();
			gp.moveTo(sw, sh);
			gp.lineTo(sw * 2, sh);
			if (circle[0] == 0) {
				gp.quadTo(blockWidth / 2, sh * 1 / 3, sw * 3, sh);
			} else if (circle[0] == 1){
				gp.quadTo(blockWidth / 2, sh + sh * 2 / 3, sw * 3, sh);
			} else {
				gp.lineTo(sw * 3, sh);
			}
			gp.lineTo(sw * 4, sh);
			gp.lineTo(sw * 4, sh * 2);
			if (circle[1] == 0) {
				gp.quadTo(sw * 4 + sw * 2 / 3, blockHeight / 2, sw * 4, sh * 3);
			} else if (circle[1] == 1){
				gp.quadTo(sw * 3 + sw * 1 / 3, blockHeight / 2, sw * 4, sh * 3);
			} else {
				gp.lineTo(sw * 4, sh * 3);
			}
			gp.lineTo(sw * 4, sh * 4);
			gp.lineTo(sw * 3, sh * 4);
			if (circle[2] == 0) {
				gp.quadTo(blockWidth / 2, blockHeight - sh * 1 / 3, sw * 2, sh * 4);
			} else if (circle[2] == 1){
				gp.quadTo(blockWidth / 2, sh * 3 + sh * 1 / 3, sw * 2, sh * 4);
			} else {
				gp.lineTo(sw * 2, sh * 4);
			}
			gp.lineTo(sw, sh * 4);
			gp.lineTo(sw, sh * 3);
			if (circle[3] == 0) {
				gp.quadTo(sw * 1 / 3, blockHeight / 2, sw, sh * 2);
			} else if (circle[3] == 1){
				gp.quadTo(sw + sw * 2 / 3, blockHeight / 2, sw, sh * 2);
			} else {
				gp.lineTo(sw, sh * 2);
			}
			
			gp.closePath();
			
			return gp;
		}
	
	public BufferedImage DealOriPictureByTemplate(BufferedImage oriImage, BufferedImage templateImage, int x,
            int y){
		// 源文件备份图像矩阵 支持alpha通道的rgb图像
        BufferedImage ori_copy_image = new BufferedImage(oriImage.getWidth(), oriImage.getHeight(), BufferedImage.TYPE_INT_RGB);
        // 源文件图像矩阵
        int[][] oriImageData = null;
		try {
			oriImageData = getData(oriImage);
		} catch (Exception e) {
			SysLog.println(e.toString());
		}
        // 模板图像矩阵
        int[][] templateImageData = null;
		try {
			templateImageData = getData(templateImage);
		} catch (Exception e) {
			SysLog.println(e.toString());
		}
 
		if (oriImageData == null || templateImageData == null) {
			return null;
		}
        for (int i = 0; i < oriImageData.length; i++) {
            for (int j = 0; j < oriImageData[0].length; j++) {
                int rgb = oriImage.getRGB(i, j);
                int r = (0xff & rgb);
                int g = (0xff & (rgb >> 8));
                int b = (0xff & (rgb >> 16));
                ori_copy_image.setRGB(i, j, rgb);
            }
        }
 
        // Random random = new Random();
        SecureRandom sRandom = null;
		try {
			sRandom = SecureRandom.getInstance("SHA1PRNG");
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			SysLog.println(e.toString());
			SysLog.println("Captcha--ImageUtils--DealOriPictureByTemplate--getInstance==" + e.toString());
		}
		int tx = 0;
		int ty = 0;
		if(sRandom != null){
			tx = sRandom.nextInt(x - 10);
			ty = sRandom.nextInt(oriImage.getHeight() - templateImage.getHeight());
		}
        for (int i = 0; i < templateImageData.length; i++) {
            for (int j = 0; j < templateImageData[0].length - 5; j++) {
                int rgb = templateImage.getRGB(i, j);
                if (rgb != 16777215 && rgb < 0) {
                    int rgb_ori = ori_copy_image.getRGB(x + i, y + j);
                    int r = (int) ((0xff & rgb_ori) * 0.5);
                    int g = (int) ((0xff & (rgb_ori >> 8)) * 0.5);
                    int b = (int) ((0xff & (rgb_ori >> 16)) * 0.5);
                    rgb_ori = r + (g << 8) + (b << 16) + (255 << 24);
                    ori_copy_image.setRGB(x + i, y + j, rgb_ori);
                    
                    // 混淆模块
                    rgb_ori = ori_copy_image.getRGB(tx + i, ty + j);
                    r = (int) ((0xff & rgb_ori) * 0.7);
                    g = (int) ((0xff & (rgb_ori >> 8)) * 0.7);
                    b = (int) ((0xff & (rgb_ori >> 16)) * 0.7);
                    rgb_ori = r + (g << 8) + (b << 16) + (255 << 24);
                    ori_copy_image.setRGB(tx + i, ty + j, rgb_ori);
                } else {
                }
            }
        }
        
        return ori_copy_image;
	}
	
	public BufferedImage DealBlockPictureByTemplate(BufferedImage oriImage, BufferedImage templateImage, int x,
            int y){
		// 源文件备份图像矩阵 支持alpha通道的rgb图像
        BufferedImage ori_copy_image = new BufferedImage(templateImage.getWidth(), templateImage.getHeight(), BufferedImage.TYPE_INT_ARGB);
        // 模板图像矩阵
        int[][] templateImageData = null;
		try {
			templateImageData = getData(templateImage);
		} catch (Exception e) {
			SysLog.println(e.toString());
			SysLog.println("Captcha--ImageUtils--DealBlockPictureByTemplate--getData==" + e.toString());
		}
 
		if (templateImageData == null) {
			return null;
		}
		
        for (int i = 0; i < templateImageData.length; i++) {
            for (int j = 0; j < templateImageData[0].length - 5; j++) {
                int rgb = templateImage.getRGB(i, j);
                if (rgb != 16777215 && rgb < 0) {
                	int rgb1 = templateImage.getRGB(i - 1, j);
                	int rgb2 = templateImage.getRGB(i + 1, j);
                	int rgb3 = templateImage.getRGB(i, j - 1);
                	int rgb4 = templateImage.getRGB(i, j + 1);
                	if (rgb1 == 16777215 || rgb1 >= 0 || rgb3 == 16777215 || rgb3 >= 0) {
                		ori_copy_image.setRGB(i, j, Color.white.getRGB());
                	} else if (rgb2 == 16777215 || rgb2 >= 0 || rgb4 == 16777215 || rgb4 >= 0){
                		ori_copy_image.setRGB(i, j, Color.black.getRGB());
                	} else {
                		int rgb_ori = oriImage.getRGB(x + i, y + j);
                		ori_copy_image.setRGB(i, j, rgb_ori);
                	}
                } else {
//                	ori_copy_image.setRGB(i, j, rgb);
                }
            }
        }
        
        return ori_copy_image;
	}
	
	private int[][] getData(BufferedImage bimg) throws Exception {
        int[][] data = new int[bimg.getWidth()][bimg.getHeight()];
        for (int i = 0; i < bimg.getWidth(); i++) {
            for (int j = 0; j < bimg.getHeight(); j++) {
                data[i][j] = bimg.getRGB(i, j);
            }
        }
        return data;
    }
	public  boolean compressPic(File file, OutputStream out) throws IOException {
        
        BufferedImage src = null;
        
        
        ImageWriteParam imgWriteParams;

        // 指定写图片的方式为 jpg
        ImageWriter imgWrier = ImageIO.getImageWritersByFormatName("jpg").next();
        imgWriteParams = new javax.imageio.plugins.jpeg.JPEGImageWriteParam(
                null);
        // 要使用压缩，必须指定压缩方式为MODE_EXPLICIT
        imgWriteParams.setCompressionMode(imgWriteParams.MODE_EXPLICIT);
        // 这里指定压缩的程度，参数qality是取值0~1范围内，
        imgWriteParams.setCompressionQuality((float)1);
        imgWriteParams.setProgressiveMode(imgWriteParams.MODE_DISABLED);
        ColorModel colorModel = ImageIO.read(file).getColorModel();// ColorModel.getRGBdefault();
        // 指定压缩时使用的色彩模式
//        imgWriteParams.setDestinationType(new javax.imageio.ImageTypeSpecifier(
//                colorModel, colorModel.createCompatibleSampleModel(16, 16)));
        imgWriteParams.setDestinationType(new javax.imageio.ImageTypeSpecifier(
                colorModel, colorModel.createCompatibleSampleModel(16, 16)));

        try {
            
                
                // System.out.println(file.length());
                src = ImageIO.read(file);
                //out = new FileOutputStream(descFilePath);

                imgWrier.reset();
                // 必须先指定 out值，才能调用write方法, ImageOutputStream可以通过任何
                // OutputStream构造
                imgWrier.setOutput(ImageIO.createImageOutputStream(out));
                // 调用write方法，就可以向输入流写图片
                imgWrier.write(null, new IIOImage(src, null, null),
                        imgWriteParams);
                out.flush();
                out.close();
            
        } catch (Exception e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--ImageUtils--compressPic--write==" + e.toString());
            return false;
        }
        return true;
    }
}
