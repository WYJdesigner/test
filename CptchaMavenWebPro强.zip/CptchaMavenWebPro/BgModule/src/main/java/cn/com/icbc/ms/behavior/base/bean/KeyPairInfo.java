package cn.com.icbc.ms.behavior.base.bean;

public class KeyPairInfo {
    private String algorithm;
    private String publicModule;
    private String publicExponen;
    private String privateModule;
    private String privateExponent;

    public String getAlgorithm() {
        return algorithm;
    }

    public void setAlgorithm(String algorithm) {
        this.algorithm = algorithm;
    }

    public String getPrivateModule() {
        return privateModule;
    }

    public void setPrivateModule(String privateModule) {
        this.privateModule = privateModule;
    }

    public String getPrivateExponent() {
        return privateExponent;
    }

    public void setPrivateExponent(String privateExponent) {
        this.privateExponent = privateExponent;
    }

    public String getPublicModule() {
        return publicModule;
    }

    public void setPublicModule(String publicModule) {
        this.publicModule = publicModule;
    }

    public String getPublicExponen() {
        return publicExponen;
    }

    public void setPublicExponen(String publicExponen) {
        this.publicExponen = publicExponen;
    }
}
