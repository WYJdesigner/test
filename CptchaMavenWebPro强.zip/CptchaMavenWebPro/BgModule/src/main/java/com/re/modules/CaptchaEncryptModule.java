package com.re.modules;

import cn.com.icbc.ms.behavior.base.RandomItem;
import cn.com.icbc.ms.behavior.component.KeyPairGenerator;
import cn.com.icbc.ms.behavior.utils.*;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.re.inter.CaptchaCommonBehavior;
import com.re.inter.CaptchaEncryptBehavior;

import java.io.UnsupportedEncodingException;
import java.security.interfaces.RSAPrivateKey;
import java.util.Base64;

public class CaptchaEncryptModule implements CaptchaEncryptBehavior {

    // 服务端随机数不一致
    private final String ERROR_CODE5 = "ERROR_5";

    // 解密客户端随机数失败
    private final String ERROR_CODE6 = "ERROR_6";

    // 服务端随机数异常
    private final String ERROR_CODE7 = "ERROR_7";

    private CaptchaCommonBehavior commonBehavior;

    private CaptchaEncryptModule(){}

    public CaptchaEncryptModule(CaptchaCommonBehavior commonBehavior) {
        this.commonBehavior = commonBehavior;
    }

    @Override
    public String WYJetStr(String key, String str, int crypto_kind) {
        String s = "";
//		SysLog.println("etStr" + str);
        switch (crypto_kind) {
            case 0:// 3des
                byte[] keyByte = init3DesKey(key);
                if (keyByte == null) {
                    return s;
                }
                byte[] bts = null;
                try {
                    bts = EncodeUtils.encryptBy3DesCBC(keyByte, str.getBytes("UTF-8"));
                } catch (UnsupportedEncodingException e) {
                    SysLog.println(e.toString());
                    SysLog.println("Captcha--etStr--error==" + e.toString());
                }
                if (bts == null) {
                    return s;
                }
                s = EncodeUtils.encode2Base64(bts);
                keyByte = null;
                bts = null;
                break;
            case 1:// SM4
                String keyStr = getSm4Key(key);
                SysLog.println("etStr-sm4-key" + keyStr);
                s = etSM4Str(str, keyStr);
                break;
            case 2:
                s = str;
                break;
        }
        return s;
    }

    @Override
    public String dtStrItem(String key, String str, RandomItem item, int crypto_kind) {
        String s = "";
        if (StringUtils.isEmpty(str) || StringUtils.isEmpty(key)) {
            return s;
        }
        if (item == null) {
            return s;
        }
        String randomStr = item.getRandomStr();
        if (StringUtils.isEmpty(randomStr)) {
            randomStr = "";
        }
        switch (crypto_kind) {
            case 0:// 3des
                byte[] base64 = EncodeUtils.decode2Base64(str);
                byte[] keys = init3DesKey(key + randomStr);
                SysLog.println("keys = " + new String(keys));

                if (keys == null || base64 == null) {
                    return s;
                }
                byte[] dtbyte = EncodeUtils.decryptBy3DesCBC(keys, base64);
                if (dtbyte == null) {
                    return s;
                }
                try {
                    s = new String(dtbyte, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    SysLog.println(e.toString());
                    SysLog.println("Captcha--dtStrItem--String==" + e.toString());
                }
                base64 = null;
                dtbyte = null;
                break;
            case 1:// SM4
                String keyStr = getSm4Key(key + randomStr);
                s = dtSM4Str(str, keyStr);
                break;
            case 2://AES
                s = getResData(str,key,item);
                break;
        }
        return s;


    }

    private byte[] init3DesKey(String str) {
        byte[] key = null;
        if (StringUtils.isEmpty(str)) {
            return key;
        }
        byte[] iKey = EncodeUtils.encryptBySha(str);
        if (iKey == null) {
            return null;
        }
        String hexStr = HexStringUtil.byte2HexNew(iKey);
        String keyStr = "";
        if (hexStr.length() > 28) {
            keyStr = hexStr.substring(4, 28);
        } else {
            for (int i = 0; i < 24; i++) {
                if (hexStr.length() >= (i + 4)) {
                    char c = hexStr.charAt(i + 4);
                    keyStr.concat(String.valueOf(c));
                } else {
                    keyStr.concat("0");
                }
            }
        }
        try {
            key = keyStr.getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--init3DesKey--error==" + e.toString());
        }
        return key;
    }

    public String getSm4Key(String uuid) {
        if (null == uuid || "".equals(uuid)) {
            return "";
        }
        byte[] bytes = EncodeUtils.encryptBySha(uuid);
        String s = HexStringUtil.byte2HexNew(bytes);
        return s.substring(0, 16);
    }

    public String etSM4Str(String content, String key) {
        if (null == content || "".equals(content) || key.length() != 16) {
            return "";
        }
        String enStr = new SM4Encrypt(0).encryptSm4(content, key);
        if (null != enStr || "".equals(enStr))
            return enStr;
        else
            return "";
    }

    private String dtSM4Str(String content, String key) {
        if (null == content || "".equals(content) || key.length() != 16) {
            return "";

        }
        String deStr = new SM4Decoder(0).decryptSm4(content, key);
        if (null != deStr || "".equals(deStr))
            return deStr;
        else
            return "";
    }

    public String getResData(String str,String key,RandomItem item) {
        KeyPairGenerator keyPairGenerator = this.commonBehavior.getKeyPairGenerator();
        if (StringUtils.isEmpty(str) || StringUtils.isEmpty(key) || keyPairGenerator == null) return  null;
        RSAPrivateKey privateKey = keyPairGenerator.createPrivateKey(
                keyPairGenerator.getKeyPairInfo().getPrivateModule(),
                keyPairGenerator.getKeyPairInfo().getPrivateExponent());;
        JSONObject outerJsonObject = JSON.parseObject(str);
        String rsaParamsJsonString = outerJsonObject.getString("rsaParams");
        JSONObject innerJsonObject = JSON.parseObject(rsaParamsJsonString);
        String aesKey = null;
        if (str.contains("sr")) {
            String srValue = innerJsonObject.getString("sr");
            try {
                byte[] srBytes = KeyPairGenerator.decryptWithRSA(privateKey,HexStringUtil.hexStringToByteArray(srValue));
                String srString = new String(srBytes);
                String localSr = item.getSr();
//                SysLog.println("解密的key：" + key + "\n" + "item获取的sr" +localSr);
                if (srString.equals(localSr)) {
                    SysLog.println("sr is equal");
                }else {
                    SysLog.println("sr is not equal");
                    return ERROR_CODE5;
                }
            } catch (Exception e) {
                SysLog.println("get sr exception:" + ERROR_CODE7);
                return ERROR_CODE7;
            }
        }
        if (str.contains("cr")) {
            String crValue = innerJsonObject.getString("cr");
            try {
                byte[] crBytes = KeyPairGenerator.decryptWithRSA(privateKey,HexStringUtil.hexStringToByteArray(crValue));
                String crString = new String(crBytes);
                aesKey = KeyPairGenerator.xorStrings(item.getSr(),crString);
                //SysLog.println("AES密钥：" + aesKey);
            } catch (Exception e) {
                SysLog.println("解密cr失败:" + ERROR_CODE6);
                return ERROR_CODE6;
            }
        }
        if (str.contains("resData")) {
            String resDataValue = outerJsonObject.getString("resData");

            byte[] encryptedBytes = Base64.getDecoder().decode(resDataValue);
            SysLog.println("a:" + encryptedBytes);
            byte[] decryptedBytes = EncodeUtils.decryptByAesCBC(encryptedBytes,aesKey);
            SysLog.println("b:" + encryptedBytes);
            String decryptString = new String(decryptedBytes);
            //SysLog.println("利用密钥开始解密 解密结果：" + decryptString);
            return decryptString;
        }
        return null;
    }
}
