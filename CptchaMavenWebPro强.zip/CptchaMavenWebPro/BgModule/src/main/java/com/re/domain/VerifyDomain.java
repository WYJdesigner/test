package com.re.domain;

import com.re.CommonEnum;

public class VerifyDomain {
    private String uuid;
    private String data;
    private CommonEnum operation;

    private VerifyDomain(){}

    public VerifyDomain(CommonEnum operation) {
        this.operation = operation;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public CommonEnum getOperation() {
        return operation;
    }
}
