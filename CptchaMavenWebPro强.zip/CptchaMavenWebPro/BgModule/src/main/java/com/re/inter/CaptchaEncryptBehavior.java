package com.re.inter;

import cn.com.icbc.ms.behavior.base.RandomItem;

public interface CaptchaEncryptBehavior {
    // 主要为了解决参数模块引用加密模块的问题
    String WYJetStr(String key, String str, int crypto_kind);
    String dtStrItem(String key, String str, RandomItem item, int crypto_kind);
}
