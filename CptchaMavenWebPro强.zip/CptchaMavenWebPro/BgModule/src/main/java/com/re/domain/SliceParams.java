package com.re.domain;

import cn.com.icbc.ms.behavior.base.RandomItem;
import com.re.domain.CommonDomain;

import java.io.InputStream;

public class SliceParams {
    private RandomItem item;
    private String uniqueid;
    private String filePath;
    private InputStream iStream;
    private CommonDomain commonDomain;
    public SliceParams() {}
//    public SliceParams(RandomItem item, String uniqueid, String filePath, InputStream iStream, CommonDomain commonDomain) {
//        this.item = item;
//        this.uniqueid = uniqueid;
//        this.filePath = filePath;
//        this.iStream = iStream;
//        this.commonDomain = commonDomain;
//    }

    public RandomItem getItem() {
        return item;
    }

    public void setItem(RandomItem item) {
        this.item = item;
    }

    public String getUniqueid() {
        return uniqueid;
    }

    public void setUniqueid(String uniqueid) {
        this.uniqueid = uniqueid;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public InputStream getiStream() {
        return iStream;
    }

    public void setiStream(InputStream iStream) {
        this.iStream = iStream;
    }

    public CommonDomain getCommonDomain() {
        return commonDomain;
    }

    public void setCommonDomain(CommonDomain commonDomain) {
        this.commonDomain = commonDomain;
    }


}
