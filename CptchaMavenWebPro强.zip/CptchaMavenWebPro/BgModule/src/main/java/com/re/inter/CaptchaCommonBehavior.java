package com.re.inter;

import cn.com.icbc.ms.behavior.base.RandomItem;
import cn.com.icbc.ms.behavior.base.bean.LatticeSegmentationBean;
import cn.com.icbc.ms.behavior.component.IMUniCerInterface;
import cn.com.icbc.ms.behavior.component.KeyPairGenerator;

import java.awt.*;
import java.util.ArrayList;

public interface CaptchaCommonBehavior {

    //滑动-----
    int getSliceX();// 通用 背景

    int getSliceY();// 通用 背景

    int getSliceType(); // 参数 背景

    int[] getSliceNum();// 参数 背景

    int getBlockW();// 通用

    int getBlockH();// 通用

    //--滑动
    //---------点选
    int getBgWidthStandard();// 通用

    int getBgHeightStandard();// 通用

    int getBgWidthMaxStandard();// 通用

    int getBgHeightMaxStandard();// 通用

    boolean getIsIdiom(); // 通用

    String getStrIdiom();// 通用

    String getCodeSequence(); // 通用

    Font getFont();// 背景 参数

    void setIsIdiom(boolean isIdiom);// 通用

//    -------------------
    IMUniCerInterface getBehaviorCall();// 验证 ,虽然只在验证模块中使用，但是这个字段在通用实现类中使用。

    boolean getIsRedisAvail();// 参数 验证

    int getEncrypt();// 参数 验证

// 好像没用到，先去掉试试
//    void setParameter(int v1, int v2, int v3, int v4);// 验证

    KeyPairGenerator getKeyPairGenerator();// 加密 通用

    RandomItem getItem(String uniqueid, boolean isPoint, String filePath);// 背景 通用 滑块 验证
//实现类内部用，所以不设置接口
//    int setItem(String uniqueid, RandomItem item) throws IOException;// rnutils


    // 参数模块
    RandomItem setRandomCode(String uniqueid, int[] ri,
                             ArrayList<LatticeSegmentationBean> rPoint, int width, int height,
                             int blockW, int blockH, int countPoint, int checkPoint, int fontSize) throws Exception;

    RandomItem setRandomCode(String uniqueid, int[] ri,
                                     ArrayList<LatticeSegmentationBean> rPoint, int width, int height,
                                     int blockW, int blockH, int countPoint, int checkPoint, int fontSize,
                                     String filePath) throws Exception;
}
