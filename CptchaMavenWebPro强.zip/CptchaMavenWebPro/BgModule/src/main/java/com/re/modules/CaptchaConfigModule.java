package com.re.modules;

public class CaptchaConfigModule {

}
