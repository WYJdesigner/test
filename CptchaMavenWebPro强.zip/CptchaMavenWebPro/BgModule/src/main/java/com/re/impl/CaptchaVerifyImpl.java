package com.re.impl;

import cn.com.icbc.ms.behavior.base.RandomManagerNoSave;
import cn.com.icbc.ms.behavior.component.IMUniCerInterface;
import cn.com.icbc.ms.behavior.utils.SysLog;
import com.re.inter.CaptchaVerifyBehavior;

public class CaptchaVerifyImpl implements CaptchaVerifyBehavior {
    private int connectTimeMax = 5 * 60 * 1000;
    private int connectTimeMin = 1 * 1000;
    private boolean detectWebDriver = false;
    private int StandValue = -1;
    private int v1, v2, v3, v4;
    private static RandomManagerNoSave c_manager = null;
    private int rangeValue = 10;


    @Override
    public int getConnectTimeOut() {
        return this.connectTimeMax;
    }

    @Override
    public int getConnectTimeMin() {
        return this.connectTimeMin;
    }

    @Override
    public int getParameter(String v1, String v2, String v3, String v4) {
        if (v1.equals("v1")) {
            return this.v1;
        }else if(v2.equals("v2")) {
            return this.v2;
        }else if(v3.equals("v3")) {
            return this.v3;
        }else if(v4.equals("v4")) {
            return this.v4;
        }else {
            return 0;
        }
    }

    @Override
    public boolean getDetectWebDriver() {
        return this.detectWebDriver;
    }

    @Override
    public RandomManagerNoSave getC_manager() {
        return c_manager;
    }

    @Override
    public int getStandParams() {
        return this.StandValue;
    }

    /**
     * 是否在选择区域范围内
     *
     * @param value1
     * @param value2
     * @return
     */
    @Override
    public boolean inRange(int value1, int value2) {
        if (value1 > (value2 - rangeValue) && value1 < (value2 + rangeValue)) {
            SysLog.println("inRange:" + value1 + "--" + value2 + "--1");
            return true;
        } else {
            SysLog.println("inRange:" + value1 + "--" + value2 + "--0");
            return false;
        }
    }
    //报错，修改
    //utils中需要ranagevalue
    public void setRangeValue(int rangeValue) {
        this.rangeValue = rangeValue;
    }
    //utils需要 c_manager
    public void setC_manager(RandomManagerNoSave manager) {
        this.c_manager = manager;
    }

    //utils 需要connectTimeMax
    public void setConnectTimeOut(int connectTimeMax) {
        this.connectTimeMax = connectTimeMax;
    }

    //utils 需要connectTimeMin
    public void setConnectTimeMin(int connectTimeMin) {
        this.connectTimeMin = connectTimeMin;
    }

    //utils 需要StandValue
    public void setStandParams(boolean isStand, int value) {
        this.StandValue = value;
    }

}
