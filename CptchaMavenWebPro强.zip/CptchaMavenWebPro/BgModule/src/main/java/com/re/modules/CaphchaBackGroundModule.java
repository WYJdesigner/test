package com.re.modules;

import cn.com.icbc.ms.behavior.base.RandomItem;
import cn.com.icbc.ms.behavior.base.bean.LatticeSegmentationBean;
import cn.com.icbc.ms.behavior.utils.ImageUtils;
import cn.com.icbc.ms.behavior.utils.PhotoCutting;
import cn.com.icbc.ms.behavior.utils.SysLog;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.*;
import java.security.SecureRandom;
import java.util.ArrayList;

import com.re.CaptchaAbstractBehavior;
import com.re.CommonEnum;
import com.re.domain.SliceParams;
import com.re.domain.CommonDomain;
import com.re.impl.CaptchaBgroundImpl;
import com.re.inter.CaptchaBGroundBehavior;
import com.re.inter.CaptchaCommonBehavior;

/*
* 背景图片
* */
public class CaphchaBackGroundModule  extends CaptchaAbstractBehavior {

    private CaptchaCommonBehavior commonBehavior;
    private CaptchaBGroundBehavior bGroundBehavior;

    private CaphchaBackGroundModule(){}
    public CaphchaBackGroundModule(CaptchaCommonBehavior commonBehavior,
                                   CaptchaBGroundBehavior bGroundBehavior) {
        this.commonBehavior = commonBehavior;
        this.bGroundBehavior = bGroundBehavior;
    }

    public byte[] getCommonBackGround(CommonDomain commonDomain) {
        SliceParams sliceParams = new SliceParams();
        sliceParams.setUniqueid(commonDomain.getUuid());
        sliceParams.setCommonDomain(commonDomain);
        sliceParams.setFilePath(commonDomain.getFilePath());
        sliceParams.setiStream(commonDomain.getiStream());
        sliceParams.setItem(commonDomain.getItem());
        return getBackgroundParams(sliceParams);

//        CommonEnum operation = commonDomain.getOperation();
//        switch (operation) {
//            case Slice_Data_Type: {
//                RandomItem item = commonDomain.getItem();
//                String filePath = commonDomain.getFilePath();
//                return getSlideBackgroundStream(item,filePath);
//            }
//            case Slice_Canvas_Type: {
//                RandomItem item = commonDomain.getItem();
//                String filePath = commonDomain.getFilePath();
//                return getSlideBackgroundCanvas(item,filePath);
//            }
//            case Old_IEeight_Type: {
//                String uuid = commonDomain.getUuid();
//                String filePath = commonDomain.getFilePath();
//                return getSlideBackgroundStream(uuid,filePath);
//            }
//            case Other_Case_Type: {
//                RandomItem item = commonDomain.getItem();
//                InputStream iStream = commonDomain.getiStream();
//                return getClickSelectBackground(item,iStream);
//            }
//            default:
//                return new byte[0];
//        }
    }
    public  byte[] getBackgroundParams(SliceParams sliceParams) {
        CommonEnum operation = sliceParams.getCommonDomain().getOperation();
        switch (operation) {
            case Slice_Data_Type: {
                RandomItem item = sliceParams.getItem();
                String filePath = sliceParams.getFilePath();
                byte[] bt = null;
                if(null == item || "".equals(item.getPicPath())){
                    return bt;
                }
                File file = new File(item.getPicPath());
                FileInputStream inputStream = null;
                try {
                    if(file.isFile()){
                        inputStream = new FileInputStream(file);
                        bt = this.getSlideBackgroundStream(item, inputStream);
                    }
                } catch (FileNotFoundException e) {
                    SysLog.println(e.toString());
                }
                return bt;
//                return getSlideBackgroundStream(item,filePath);
            }
            case Slice_Canvas_Type: {
                RandomItem item = sliceParams.getItem();
                String filePath = sliceParams.getFilePath();
//                return getSlideBackgroundCanvas(item,filePath);
                byte[] bt = null;
                if(null == item || "".equals(item.getPicPath())){
                    return bt;
                }
                File file = new File(item.getPicPath());
                FileInputStream inputStream = null;
                try {
                    if(file.isFile()){
                        inputStream = new FileInputStream(file);
                        bt = this.getSlideBackgroundCanvas(item, inputStream);
                    }
                } catch (FileNotFoundException e) {
                    SysLog.println(e.toString());
                }
                return bt;
            }
            case Slice_Bgimage_O_Type: {
                String uniqueid = sliceParams.getUniqueid();
                String filePath = sliceParams.getFilePath();
//                return getSlideBackgroundStream(uuid,filePath);
                byte[] bt = null;
                RandomItem item = null;
                item = this.commonBehavior.getItem(uniqueid, false, filePath);
                if(null == item || "".equals(item.getPicPath())){
                    return bt;
                }
                File file = new File(item.getPicPath());
                FileInputStream inputStream = null;
                try {
                    if(file.isFile()){
                        inputStream = new FileInputStream(file);
                        bt = getSlideBackgroundStream(item, inputStream);
                    }
                } catch (FileNotFoundException e) {
                    SysLog.println(e.toString());
                }
                return bt;
            }
            case Other_Case_Type: {
                RandomItem item = sliceParams.getItem();
                InputStream iStream = sliceParams.getiStream();
                return getClickSelectBackground(item,iStream);
            }
            default:
                return new byte[0];
        }
    }

    // canvas：false stream：false slice_data 1
//    public byte[] getSlideBackgroundStream(RandomItem item, String filePath) {
//            byte[] bt = null;
//        if(null == item || "".equals(item.getPicPath())){
//            return bt;
//        }
//        File file = new File(item.getPicPath());
//        FileInputStream inputStream = null;
//        try {
//            if(file.isFile()){
//                inputStream = new FileInputStream(file);
//                bt = this.getSlideBackgroundStream(item, inputStream);
//            }
//        } catch (FileNotFoundException e) {
//            SysLog.println(e.toString());
//        }
//        return bt;
//    }

    // canvas：true  stream：false slice_canvas 1
//    public byte[] getSlideBackgroundCanvas(RandomItem item, String filePath) {
//        byte[] bt = null;
//        if(null == item || "".equals(item.getPicPath())){
//            return bt;
//        }
//        File file = new File(item.getPicPath());
//        FileInputStream inputStream = null;
//        try {
//            if(file.isFile()){
//                inputStream = new FileInputStream(file);
//                bt = this.getSlideBackgroundCanvas(item, inputStream);
//            }
//        } catch (FileNotFoundException e) {
//            SysLog.println(e.toString());
//        }
//        return bt;
//    }

    //滑动验证码背景图片旧方法,主要用于兼容IE8版本 1
//    public byte[] getSlideBackgroundStream(String uniqueid, String filePath) {
//        byte[] bt = null;
//        RandomItem item = null;
//        item = this.commonBehavior.getItem(uniqueid, false, filePath);
//        if(null == item || "".equals(item.getPicPath())){
//            return bt;
//        }
//        File file = new File(item.getPicPath());
//        FileInputStream inputStream = null;
//        try {
//            if(file.isFile()){
//                inputStream = new FileInputStream(file);
//                bt = getSlideBackgroundStream(item, inputStream);
//            }
//        } catch (FileNotFoundException e) {
//            SysLog.println(e.toString());
//        }
//        return bt;
//    }

    //other case 1
    // 参数模块有调用
    public byte[] getClickSelectBackground(RandomItem item, InputStream iStream) {
        byte[] bt = null;

        // ImageUtils imUtils = new ImageUtils();
        BufferedImage imageQr = null;

        int colorR = this.bGroundBehavior.getColorR();
        int colorG = this.bGroundBehavior.getColorG();
        int colorB = this.bGroundBehavior.getColorB();
        boolean isRandomColor = this.bGroundBehavior.getRandomColor();
        boolean fontSizeChange = this.bGroundBehavior.getFontSizeChange();
        int colorRange = this.bGroundBehavior.getColorRange();
        Font g_ft = this.commonBehavior.getFont();

        try {
            if (item == null) {
                return bt;
            }
            ArrayList<LatticeSegmentationBean> rPoint = item.getrPointAry();
            imageQr = ImageIO.read(iStream);
            int imageQrWidth = imageQr.getWidth();
            int imageQrHeight = imageQr.getHeight();
            int width = item.getWidth();
            int height = item.getHeight();
            int fontSize = item.getFontSize();
            int countPoint = item.getCountPoint();
            String randomStr = item.getRandomStr();
            long timeStamp = item.getTimeStamp();
            Image img = imageQr.getScaledInstance(width, height,
                    BufferedImage.SCALE_SMOOTH);
            double wr = width * 1.0 / imageQrWidth;
            double hr = height * 1.0 / imageQrHeight;
            AffineTransformOp ato = new AffineTransformOp(
                    AffineTransform.getScaleInstance(wr, hr), null);
            img = ato.filter(imageQr, null);
            imageQrWidth = ((BufferedImage) img).getWidth();
            imageQrHeight = ((BufferedImage) img).getHeight();

            BufferedImage oriBuf = new BufferedImage(imageQrWidth,
                    imageQrHeight, BufferedImage.TYPE_INT_RGB);
            // BufferedImage oriBuf = imUtils.copyBufferImage(imageQr);
            // Random random = new Random();
            SecureRandom sRandom = SecureRandom.getInstance("SHA1PRNG");
            Graphics2D g = oriBuf.createGraphics();
//			g.drawImage(img, 0, 0, imageQrWidth, imageQrHeight, null);
            g.drawImage(img.getScaledInstance(imageQrWidth, imageQrHeight, Image.SCALE_SMOOTH), 0, 0, imageQrWidth, imageQrHeight, null);
            // g.setFont(new Font("宋体", Font.BOLD | Font.ITALIC, fontSize +
            // fontChange));
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_GASP);

            // int red = 0, green = 0, blue = 0;
            // 随机产生验证码
            // int len = codeSequence.length();
            // String str = "";
            // 创建循环渐变的GraphientPaint对象
            //更改字体颜色 颜色统一设置
            Color color = null;
            if(colorR >=0 && colorG >= 0 && colorB >= 0 && !isRandomColor){
                color = new Color(colorR,colorG,colorB);
            }else{
                int rgbl = oriBuf.getRGB(imageQrWidth / 2, imageQrHeight / 2);
                color = new Color(rgbl);
            }
            // int rgbr = oriBuf.getRGB(150, 150);
            // int rgb_r = (0xff & rgb);
            // int rgb_g = (0xff & (rgb >> 8));
            // int rgb_b = (0xff & (rgb >> 16));
            GradientPaint paint = new GradientPaint(20, 20, color,
                    40, 40, Color.black, true);
            g.setPaint(paint);
            for (int i = 0; i < rPoint.size(); i++) {
                int fontChange = 0;
                AffineTransform transform = new AffineTransform();
                if (fontSizeChange) {
                    int n = sRandom.nextInt(10);
                    SysLog.println("fontSizeChange:" + n);
                    if (n % 3 == 0) {
                        fontChange = sRandom.nextInt(fontSize / 3);
                    } else {
                        fontChange = Integer.valueOf("-"
                                + sRandom.nextInt(fontSize / 3));
                    }
                    SysLog.println(randomStr+"-"+timeStamp+"fontSizeChange fontSize:" + (fontSize + fontChange));
                }
                // g.setFont(new Font("宋体", Font.BOLD | Font.ITALIC, fontSize +
                // fontChange));
                if (g_ft == null) {
                    SysLog.println(randomStr+"-"+timeStamp+"默认字体");
                    g.setFont(new Font("宋体", Font.BOLD | Font.ITALIC, fontSize
                            + fontChange));
                } else {
                    SysLog.println(randomStr+"-"+timeStamp+"调用方自定义字体");
                    g.setFont(g_ft.deriveFont(Font.BOLD | Font.ITALIC, fontSize
                            + fontChange));
                }
                /*
                 * char at = codeSequence.charAt(random.nextInt(len)); while
                 * (str.contains(String.valueOf(at))) { at =
                 * codeSequence.charAt(random.nextInt(len)); } str += at;
                 */
                int x = rPoint.get(i).getM_xRangePoint();
                int y = rPoint.get(i).getM_yRangePoint();
                char at = rPoint.get(i).getM_txt();
                // SysLog.println("x" + x);
                // SysLog.println("y" + y);
                SysLog.println(randomStr+"-"+timeStamp+"-"+x+"---字位置---"+y);
                // 产生随机的颜色分量来构造颜色值，这样输出的每位数字的颜色值都将不同
                if(isRandomColor){
                    int rgb = oriBuf.getRGB(x, y);
                    // SysLog.println("rgb:" + rgb);
                    int rgb_r = (0xff & rgb);
                    int rgb_g = (0xff & (rgb >> 8));
                    int rgb_b = (0xff & (rgb >> 16));
                    if (rgb_r - colorRange >= 0) {
                        rgb_r -= colorRange;
                    } else {
                        rgb_r += colorRange;
                        if(rgb_r > 255){
                            rgb_r = 255 - rgb_r%255;
                        }
                    }
                    // randomChange = random.nextInt(changeColor);
                    if (rgb_g - colorRange >= 0) {
                        rgb_g -= colorRange;
                    } else {
                        rgb_g += colorRange;
                        if(rgb_g > 255){
                            rgb_g = 255 - rgb_g%255;
                        }
                    }
                    // randomChange = random.nextInt(changeColor);
                    if (rgb_b - colorRange >= 0) {
                        rgb_b -= colorRange;
                    } else {
                        rgb_b += colorRange;
                        if(rgb_b > 255){
                            rgb_b = 255 - rgb_b%255;
                        }
                    }
                    // red = random.nextInt(255);
                    // green = random.nextInt(255);
                    // blue = random.nextInt(255);

                    // float rotate = random.nextFloat();
                    SysLog.println(randomStr+"-"+timeStamp+"字颜色随机,色值 r="+rgb_r+",g="+rgb_g+",b="+rgb_b);
                    g.setColor(new Color(rgb_r, rgb_g, rgb_b));
                }
                float r = sRandom.nextInt(9);
                float rotate = r / 10;
                SysLog.println(randomStr+"-"+timeStamp+"rotate:" + rotate);
                g.setBackground(Color.white);
                int xp = x - fontSize / 2;
                int yp = y + fontSize / 2;
                SysLog.println(randomStr+"-"+timeStamp+"xp:" + xp+",yp:" +yp);
                transform.rotate(rotate, xp, yp);
                g.setTransform(transform);
                g.drawString(String.valueOf(at), xp - rotate * fontSize, yp
                        - rotate * fontSize);
                transform.rotate(-rotate, xp, yp);
                g.setTransform(transform);
//				rPoint.get(i).setM_txt(at);
            }
            g.dispose();
            ByteArrayOutputStream os = new ByteArrayOutputStream();// 新建流。
            try {
                // 利用ImageIO类提供的write方法，将by以png图片的数据模式写入流。
                ImageIO.write(oriBuf, "jpeg", os);
                bt = os.toByteArray();// 从流中获取数据数组。
                os.close();
            } catch (IOException e) {
                SysLog.println(e.toString());
                SysLog.println("Captcha--getClickSelectBackground--ImageIO.write--error==" + e.toString());
                return bt;
            }
        } catch (Exception e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--getClickSelectBackground--error==" + e.toString());
            return null;
        }finally {
            try {
                iStream.close();
            } catch (IOException e) {
                SysLog.println(e.toString());
                SysLog.println("Captcha--getClickSelectBackground--iStream.close--error==" + e.toString());
            }
        }
        return bt;
    }

    // canvas：false stream：false slice_data 2
    // 旧方法,主要用于兼容IE8版本 2
    public byte[] getSlideBackgroundStream(RandomItem item, InputStream iStream) {
        byte[] bt = null;
        BufferedImage blockBuf = null;
        ImageUtils imUtils = new ImageUtils();
        GeneralPath gp = null;
        BufferedImage imageQr = null;
        try {
            if(iStream == null){
                return bt;
            }
            if (item == null) {
                iStream.close();
                return bt;
            }
            int width = item.getWidth();
            int height = item.getHeight();
            int blockW = item.getBlockW();
            int blockH = item.getBlockH();

            // 处理图片的拉伸效果
            imageQr = ImageIO.read(iStream);
            int imageQrWidth = imageQr.getWidth();
            int imageQrHeight = imageQr.getHeight();
            Image img = imageQr.getScaledInstance(width, height,
                    BufferedImage.SCALE_SMOOTH);
            double wr = width * 1.0 / imageQrWidth;
            double hr = height * 1.0 / imageQrHeight;
            AffineTransformOp ato = new AffineTransformOp(
                    AffineTransform.getScaleInstance(wr, hr), null);
            img = ato.filter(imageQr, null);

            // 绘制滑块区域图像
            blockBuf = new BufferedImage(blockW, blockH,
                    BufferedImage.TYPE_INT_ARGB);
//			gp = item.getPath();
            gp = imUtils.drawPath(item.getBlockH(), item.getBlockW(), item.getT());
            Graphics2D g = blockBuf.createGraphics();
            g.setColor(Color.black);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g.fill(gp);
            g.dispose();
            int[] ri = item.getrPoint();
            int bw = ri[0] - blockW / 2;
            int bh = ri[1] - blockH / 2;
            BufferedImage dealOriPicture = imUtils.DealOriPictureByTemplate(
                    (BufferedImage) img, blockBuf, bw, bh);
            ByteArrayOutputStream os = new ByteArrayOutputStream();// 新建流。
            try {
                // 利用ImageIO类提供的write方法，将by以png图片的数据模式写入流。
                ImageIO.write(dealOriPicture, "png", os);
            } catch (IOException e) {
                SysLog.println(e.toString());
                SysLog.println("Captcha--getSlideBackgroundStream--ImageIO.write--error==" + e.toString());
            }
            bt = os.toByteArray();// 从流中获取数据数组。
            os.close();
            item = null;
        } catch (Exception e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--getSlideBackgroundStream--error==" + e.toString());
        }
        try {
            iStream.close();
        } catch (IOException e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--getSlideBackgroundStream--iStream.close==" + e.toString());
        }
        return bt;
    }

    // canvas：true stream：false  slice_canvas 2
    public byte[] getSlideBackgroundCanvas(RandomItem item, InputStream iStream) {
        byte[] bt = null;
        BufferedImage blockBuf = null;
        ImageUtils imUtils = new ImageUtils();
        GeneralPath gp = null;

        BufferedImage imageQr = null;
        try {
            if(iStream == null){
                return bt;
            }
            if (item == null) {
                iStream.close();
                return bt;
            }

            int width = item.getWidth();
            int height = item.getHeight();
            int blockW = item.getBlockW();
            int blockH = item.getBlockH();

            // 处理图片的拉伸效果
            imageQr = ImageIO.read(iStream);
            int imageQrWidth = imageQr.getWidth();
            int imageQrHeight = imageQr.getHeight();
            Image img = imageQr.getScaledInstance(width, height,
                    BufferedImage.SCALE_SMOOTH);
            double wr = width * 1.0 / imageQrWidth;
            double hr = height * 1.0 / imageQrHeight;
            AffineTransformOp ato = new AffineTransformOp(
                    AffineTransform.getScaleInstance(wr, hr), null);
            img = ato.filter(imageQr, null);

            // 绘制滑块区域图像
            blockBuf = new BufferedImage(blockW, blockH,
                    BufferedImage.TYPE_INT_ARGB);
//			gp = item.getPath();
            gp = imUtils.drawPath(item.getBlockH(), item.getBlockW(), item.getT());
            Graphics2D g = blockBuf.createGraphics();
            g.setColor(Color.black);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g.fill(gp);
            g.dispose();

            int[] ri = item.getrPoint();
            int bw = ri[0] - blockW / 2;
            int bh = ri[1] - blockH / 2;
            BufferedImage dealOriPicture = imUtils.DealOriPictureByTemplate(
                    (BufferedImage) img, blockBuf, bw, bh);
            PhotoCutting pc = new PhotoCutting();
//            pc.setSliceX(slice_x);
//            pc.setSliceY(slice_y);
//            pc.setSliceType(slice_type);
//            BufferedImage finalImg = pc.splitImage(dealOriPicture, sliceNum);
            pc.setSliceX(this.commonBehavior.getSliceX());
            pc.setSliceY(this.commonBehavior.getSliceY());
            pc.setSliceType(this.commonBehavior.getSliceType());
            BufferedImage finalImg = pc.splitImage(dealOriPicture, this.commonBehavior.getSliceNum());
//            ImageIO.write(finalImg, "jpeg", new File("D:\\Temp\\bg-03"+".jpg"));
            ByteArrayOutputStream os = new ByteArrayOutputStream();// 新建流。
            try {
                // 利用ImageIO类提供的write方法，将by以png图片的数据模式写入流。
                ImageIO.write(finalImg, "png", os);
            } catch (IOException e) {
                SysLog.println(e.toString());
                SysLog.println("Captcha--getSlideBackgroundCanvas--ImageIO.write--error==" + e.toString());
            }
            bt = os.toByteArray();// 从流中获取数据数组。
            os.close();
            item = null;
        } catch (Exception e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--getSlideBackgroundCanvas--error==" + e.toString());
        }
        try {
            iStream.close();
        } catch (IOException e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--getSlideBackgroundCanvas--iStream.close==" + e.toString());
        }
        return bt;
    }

    // 参数模块有调用
    public byte[] getClickSelectBackgroundCanvas(RandomItem item, InputStream iStream) {
        byte[] bt = null;

        BufferedImage imageQr = null;

        int slice_x = this.commonBehavior.getSliceX();
        int slice_y = this.commonBehavior.getSliceY();
        int slice_type = this.commonBehavior.getSliceType();
        int[] sliceNum = this.commonBehavior.getSliceNum();

        int colorR = this.bGroundBehavior.getColorR();
        int colorG = this.bGroundBehavior.getColorG();
        int colorB = this.bGroundBehavior.getColorB();
        boolean isRandomColor = this.bGroundBehavior.getRandomColor();

        boolean fontSizeChange = this.bGroundBehavior.getFontSizeChange();
        int colorRange = this.bGroundBehavior.getColorRange();
        Font g_ft = this.commonBehavior.getFont();

        try {
            if (item == null) {
                SysLog.println("Captcha--getClickSelectBackgroundCanvas--item==null");
                return bt;
            }
            ArrayList<LatticeSegmentationBean> rPoint = item.getrPointAry();
            imageQr = ImageIO.read(iStream);
            int imageQrWidth = imageQr.getWidth();
            int imageQrHeight = imageQr.getHeight();
            int width = item.getWidth();
            int height = item.getHeight();
            int fontSize = item.getFontSize();
            int countPoint = item.getCountPoint();
            String randomStr = item.getRandomStr();
            long timeStamp = item.getTimeStamp();
            Image img = imageQr.getScaledInstance(width, height,
                    BufferedImage.SCALE_SMOOTH);
            double wr = width * 1.0 / imageQrWidth;
            double hr = height * 1.0 / imageQrHeight;
            AffineTransformOp ato = new AffineTransformOp(
                    AffineTransform.getScaleInstance(wr, hr), null);
            img = ato.filter(imageQr, null);
            imageQrWidth = ((BufferedImage) img).getWidth();
            imageQrHeight = ((BufferedImage) img).getHeight();

            BufferedImage oriBuf = new BufferedImage(imageQrWidth,
                    imageQrHeight, BufferedImage.TYPE_INT_RGB);
            // BufferedImage oriBuf = imUtils.copyBufferImage(imageQr);
            // Random random = new Random();
            SecureRandom sRandom = SecureRandom.getInstance("SHA1PRNG");
            Graphics2D g = oriBuf.createGraphics();
//			g.drawImage(img, 0, 0, imageQrWidth, imageQrHeight, null);
            g.drawImage(img.getScaledInstance(imageQrWidth, imageQrHeight, Image.SCALE_SMOOTH), 0, 0, imageQrWidth, imageQrHeight, null);
            // g.setFont(new Font("宋体", Font.BOLD | Font.ITALIC, fontSize +
            // fontChange));
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_GASP);

            //更改字体颜色 颜色统一设置
            Color color = null;
            if(colorR >=0 && colorG >= 0 && colorB >= 0 && !isRandomColor){
                color = new Color(colorR,colorG,colorB);
            }else{
                int rgbl = oriBuf.getRGB(imageQrWidth / 2, imageQrHeight / 2);
                color = new Color(rgbl);
            }
            GradientPaint paint = new GradientPaint(20, 20, color,
                    40, 40, Color.black, true);
            g.setPaint(paint);
            for (int i = 0; i < rPoint.size(); i++) {
                int fontChange = 0;
                AffineTransform transform = new AffineTransform();
                if (fontSizeChange) {
                    int n = sRandom.nextInt(10);
                    SysLog.println("fontSizeChange:" + n);
                    if (n % 3 == 0) {
                        fontChange = sRandom.nextInt(fontSize / 3);
                    } else {
                        fontChange = Integer.valueOf("-"
                                + sRandom.nextInt(fontSize / 3));
                    }
                    SysLog.println(randomStr+"-"+timeStamp+"fontSizeChange fontSize:" + (fontSize + fontChange));
                }
                // g.setFont(new Font("宋体", Font.BOLD | Font.ITALIC, fontSize +
                // fontChange));
                if (g_ft == null) {
                    SysLog.println(randomStr+"-"+timeStamp+"默认字体");
                    g.setFont(new Font("宋体", Font.BOLD | Font.ITALIC, fontSize
                            + fontChange));
                } else {
                    SysLog.println(randomStr+"-"+timeStamp+"调用方自定义字体");
                    g.setFont(g_ft.deriveFont(Font.BOLD | Font.ITALIC, fontSize
                            + fontChange));
                }
                int x = rPoint.get(i).getM_xRangePoint();
                int y = rPoint.get(i).getM_yRangePoint();
                char at = rPoint.get(i).getM_txt();
                // SysLog.println("x" + x);
                // SysLog.println("y" + y);
                SysLog.println(randomStr+"-"+timeStamp+"-"+x+"---字位置---"+y);
                // 产生随机的颜色分量来构造颜色值，这样输出的每位数字的颜色值都将不同
                if(isRandomColor){
                    int rgb = oriBuf.getRGB(x, y);
                    // SysLog.println("rgb:" + rgb);
                    int rgb_r = (0xff & rgb);
                    int rgb_g = (0xff & (rgb >> 8));
                    int rgb_b = (0xff & (rgb >> 16));
                    if (rgb_r - colorRange >= 0) {
                        rgb_r -= colorRange;
                    } else {
                        rgb_r += colorRange;
                        if(rgb_r > 255){
                            rgb_r = 255 - rgb_r%255;
                        }
                    }
                    // randomChange = random.nextInt(changeColor);
                    if (rgb_g - colorRange >= 0) {
                        rgb_g -= colorRange;
                    } else {
                        rgb_g += colorRange;
                        if(rgb_g > 255){
                            rgb_g = 255 - rgb_g%255;
                        }
                    }
                    // randomChange = random.nextInt(changeColor);
                    if (rgb_b - colorRange >= 0) {
                        rgb_b -= colorRange;
                    } else {
                        rgb_b += colorRange;
                        if(rgb_b > 255){
                            rgb_b = 255 - rgb_b%255;
                        }
                    }
                    // red = random.nextInt(255);
                    // green = random.nextInt(255);
                    // blue = random.nextInt(255);

                    // float rotate = random.nextFloat();
                    SysLog.println(randomStr+"-"+timeStamp+"字颜色随机,色值 r="+rgb_r+",g="+rgb_g+",b="+rgb_b);
                    g.setColor(new Color(rgb_r, rgb_g, rgb_b));
                }
                float r = sRandom.nextInt(9);
                float rotate = r / 10;
                SysLog.println(randomStr+"-"+timeStamp+"rotate:" + rotate);
                g.setBackground(Color.white);
                int xp = x - fontSize / 2;
                int yp = y + fontSize / 2;
                SysLog.println(randomStr+"-"+timeStamp+"xp:" + xp+",yp:" +yp);
                transform.rotate(rotate, xp, yp);
                g.setTransform(transform);
                g.drawString(String.valueOf(at), xp - rotate * fontSize, yp
                        - rotate * fontSize);
                transform.rotate(-rotate, xp, yp);
                g.setTransform(transform);
//				rPoint.get(i).setM_txt(at);
            }
            g.dispose();
            ByteArrayOutputStream os = new ByteArrayOutputStream();// 新建流。
            try {
                PhotoCutting pc = new PhotoCutting();
                pc.setSliceX(slice_x);
                pc.setSliceY(slice_y);
                pc.setSliceType(slice_type);
                BufferedImage finalImg = pc.splitImage(oriBuf, sliceNum);
//				ImageIO.write(finalImg, "jpeg", new File("D:\\Temp\\bg-05"+".jpg"));
                // 利用ImageIO类提供的write方法，将by以png图片的数据模式写入流。
                ImageIO.write(finalImg, "jpeg", os);
                bt = os.toByteArray();// 从流中获取数据数组。
                os.close();
            } catch (IOException e) {
                SysLog.println(e.toString());
                SysLog.println("Captcha--getClickSelectBackgroundCanvas--ImageIO.write--error==" + e.toString());
                return bt;
            }
        } catch (Exception e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--getClickSelectBackgroundCanvas--error==" + e.toString());
            return null;
        }finally {
            try {
                iStream.close();
            } catch (IOException e) {
                SysLog.println(e.toString());
                SysLog.println("Captcha--getClickSelectBackgroundCanvas--iStream.close--error==" + e.toString());
            }
        }
        return bt;
    }



    //------------------------------滑块0-----
    public byte[] getCommonBlockParams(CommonDomain commonDomain) {
        CommonEnum operation = commonDomain.getOperation();
        switch (operation) {
            case Slice_Data_Type:
            case Slice_Canvas_Type: {
                RandomItem item = commonDomain.getItem();
                String filePath = commonDomain.getFilePath();
                return getSlideBlockImageStream(item,filePath);
            }
            case Slice_Sliceimage_O_Type:
            {
                String uuid = commonDomain.getUuid();
                String filePath = commonDomain.getFilePath();
                return getSlideBlockImageStream(uuid,filePath);
            }
            default:
                return new byte[0];
        }
    }

    //canvas：false stream：false slice_data  1调用 获取抠图
    //canvas：true stream：false slice_canvas  1调用 获取抠图
    public byte[] getSlideBlockImageStream(RandomItem item, String filePath) {

        byte[] bt = null;
        if(null == item || "".equals(item.getPicPath())){
            return bt;
        }
        File file = new File(item.getPicPath());
        FileInputStream inputStream = null;
        try {
            if(file.isFile()){
                inputStream = new FileInputStream(file);
                bt = this.getSlideBlockImageStream(item, inputStream);

            }
        } catch (FileNotFoundException e) {
            SysLog.println(e.toString());
        }
        return bt;
    }

    //旧方法,主要用于兼容IE8版本Slice_Sliceimage_O_Type 1 调用
    public byte[] getSlideBlockImageStream(String uniqueid, String filePath) {

        byte[] bt = null;
        RandomItem item = null;
        item = this.commonBehavior.getItem(uniqueid, false, filePath);
        if(null == item || "".equals(item.getPicPath())){
            return bt;
        }
        File file = new File(item.getPicPath());
        FileInputStream inputStream = null;
        try {
            if(file.isFile()){
                inputStream = new FileInputStream(file);
                bt = getSlideBlockImageStream(item, inputStream);
            }
        } catch (FileNotFoundException e) {
            SysLog.println(e.toString());
        }
        return bt;
    }

    //public byte[] getSlideBlockImageStream(RandomItem item, String filePath)方法调用
    public byte[] getSlideBlockImageStream(RandomItem item, InputStream iStream) {
        byte[] bt = null;
        BufferedImage blockBuf = null;
        ImageUtils imUtils = new ImageUtils();
        GeneralPath gp = null;
        BufferedImage imageQr = null;
        try {
            if(iStream == null){
                return bt;
            }
            if (item == null) {
                SysLog.println("Captcha--getSlideBlockImageStream--item==null");
                iStream.close();
                return bt;
            }
            int width = item.getWidth();
            int height = item.getHeight();
            int blockW = item.getBlockW();
            int blockH = item.getBlockH();

            imageQr = ImageIO.read(iStream);
            int imageQrWidth = imageQr.getWidth();
            int imageQrHeight = imageQr.getHeight();
            Image img = imageQr.getScaledInstance(width, height,
                    BufferedImage.SCALE_SMOOTH);
            double wr = width * 1.0 / imageQrWidth;
            double hr = height * 1.0 / imageQrHeight;
            AffineTransformOp ato = new AffineTransformOp(
                    AffineTransform.getScaleInstance(wr, hr), null);
            img = ato.filter(imageQr, null);

            blockBuf = new BufferedImage(blockW, blockH,
                    BufferedImage.TYPE_INT_ARGB);
//			gp = item.getPath();
            gp = imUtils.drawPath(item.getBlockH(), item.getBlockW(), item.getT());
            Graphics2D g = blockBuf.createGraphics();
            g.setColor(Color.black);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g.fill(gp);
            g.dispose();

            int[] ri = item.getrPoint();
            int bw = ri[0] - blockW / 2;
            int bh = ri[1] - blockH / 2;
            BufferedImage dealBlockPicture = imUtils
                    .DealBlockPictureByTemplate((BufferedImage) img, blockBuf,
                            bw, bh);

            ByteArrayOutputStream os = new ByteArrayOutputStream();// 新建流。
            try {
                // 利用ImageIO类提供的write方法，将by以png图片的数据模式写入流。
                ImageIO.write(dealBlockPicture, "png", os);
            } catch (IOException e) {
                SysLog.println(e.toString());
                SysLog.println("Captcha--getSlideBlockImageStream--ImageIO.write--error==" + e.toString());
            }
            bt = os.toByteArray();// 从流中获取数据数组。
            os.close();
            item = null;
        } catch (Exception e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--getSlideBlockImageStream--error==" + e.toString());
        }
        try {
            iStream.close();
        } catch (IOException e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--getSlideBlockImageStream--iStream.close==" + e.toString());
        }
        return bt;
    }

}

