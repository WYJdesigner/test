package com.re;

import cn.com.icbc.ms.behavior.base.RandomItem;
import cn.com.icbc.ms.behavior.base.bean.LatticeSegmentationBean;
import cn.com.icbc.ms.behavior.utils.SysLog;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.re.domain.CommonDomain;
import com.re.inter.CaptchaBGroundBehavior;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class CaptchaAbstractBehavior {

    public int getInt(String uuid, int index) {
        String regEx = "[^0-9]";

        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(uuid);
        // System.out.println(m.replaceAll("").trim());
        String trim = m.replaceAll("").trim();
        if(trim.length() == 0 || trim.length() < 4){
            trim = "1111111111111111";
        }
        int[] arr = new int[trim.length()];
        for (int i = 0; i < trim.length(); i++) {
            arr[i] = Integer.parseInt(trim.charAt(i) + "");
        }

        return arr[index - 1];

    }
    public int[] getInt(String uuid) {

        String regEx = "[^0-9]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(uuid);

        String trim = m.replaceAll("").trim();
        if(trim.length() == 0 || trim.length() < 4){
            trim = "1111111111111111";
        }
        int[] arr = new int[trim.length()];
        for (int i = 0; i < trim.length(); i++) {
            arr[i] = Integer.parseInt(trim.charAt(i) + "");
        }

        return arr;

    }
    public int getX(int x) {
        int x1 = (int) (x * 17);

        if ((x1 + 20) > 150) {
            x1 -= 20;

        }
        if (x1 < 20) {
            x1 += 20;
        }
        // System.out.println("i2 = " + x1);
        return x1;

    }
    public int getY(int y) {
        int y1 = (int) (y * 17);

        if ((y1 + 20) > 100) {
            y1 -= 20;

        }
        if (y1 < 20) {
            y1 += 20;
        }
        // System.out.println("i2 = " + y1);
        return y1;

    }
    public String getFileInDir(String fileL) {
        String filePath = "";
        File dest = new File(fileL);
        List<File> listFile = new ArrayList<File>();
        // 目录，遍历当前目录，列出目录下的文件,记录所有文件
        if (dest.exists() || dest.isDirectory()) {
            String[] files = dest.list();
            for (int i = 0; i < files.length; i++) {
                File file = new File(dest, files[i]);
                if (file.getName().endsWith(".DS_Store")) {
                    continue;
                }
                if (file.isFile() || file.getName().endsWith("jpeg") ) {
                    // System.out.println("file = " + file.getName());
                    listFile.add(file);
                }
            }
        }
        // 返回随机当前目录下随机文件的流
        Random r = new Random();
        int index = r.nextInt(listFile.size());
        filePath = listFile.get(index).getAbsolutePath();

        return filePath;
    }
    public String getFileInDirByUUID(String uuid, String filePath) {
        // TODO Auto-generated method stub
        File dest = new File(filePath);
        if (dest.isFile()) {
            throw new IllegalArgumentException("filePath is not directory");
        }

        int lastChar = uuid.charAt(uuid.length() - 1);
        SysLog.println("lastChar = " + lastChar);

        String[] files = dest.list();
        String[] listFile = new String[files.length];
        int sum = 0;
        // 目录，遍历当前目录，列出目录下的文件,记录所有文件
        if (dest.exists() || dest.isDirectory()) {

            for (int i = 0; i < files.length; i++) {
                File file = new File(dest, files[i]);
                if (file.isFile() || file.getName().endsWith("jpeg")) {

                    listFile[i] = file.getAbsolutePath();
                    sum++;
                }
            }
        }
        if(sum == 0){
            return "";
        }
        // 根据uuid获取图片路径
        if(lastChar < listFile.length){
            return listFile[lastChar];
        } else {
            lastChar = lastChar % 10;
            if(lastChar < listFile.length){
                return listFile[lastChar];
            }else {
                return listFile[0];
            }
        }
    }
    //暂时无用 拆出来
    public RandomItem getRandomItem(String itemJsonStr){
        RandomItem item = null;
        JSONObject rItemJson = JSONObject.parseObject(itemJsonStr);
        int blockW = rItemJson.getInteger("blockW");
        int blockH = rItemJson.getInteger("blockH");
        com.alibaba.fastjson.JSONArray jarPoint = (com.alibaba.fastjson.JSONArray) rItemJson.get("rPoint");
        int[] rPoint = null;
        if(jarPoint != null && jarPoint.size()>0){
            rPoint = new int[jarPoint.size()];
            for (int i = 0; i < jarPoint.size(); i++) {
                rPoint[i]=jarPoint.getIntValue(i);
            }
        }

        ArrayList<LatticeSegmentationBean> rPointAryList = null;
        if(rItemJson.get("rPointAry") != null){
            rPointAryList = JSONObject.parseObject(rItemJson.get("rPointAry").toString(),
                    new TypeReference<ArrayList<LatticeSegmentationBean>>() {
                    });
        }
        if(rItemJson.get("rPoint") != null){
            item = new RandomItem( rItemJson.getLongValue("timeStamp"), rPoint, rItemJson.getInteger("width"),  rItemJson.getInteger("height"), blockW, blockH);
        }else if(rItemJson.get("rPointAry") != null){
            item = new RandomItem(rItemJson.getLongValue("timeStamp"), rPointAryList, rItemJson.getInteger("width"), rItemJson.getInteger("height"), rItemJson.getInteger("countPoint"),rItemJson.getInteger("checkPoint"), rItemJson.getInteger("fontSize")) ;
        }else{
            return null;
        }
        item.setRandomStr(rItemJson.getString("randomStr"));
        item.setrPointAry(rPointAryList);
        item.setCacheIMGUsedNum(rItemJson.getIntValue("cacheIMGUsedNum"));
        return item;
    }
}
