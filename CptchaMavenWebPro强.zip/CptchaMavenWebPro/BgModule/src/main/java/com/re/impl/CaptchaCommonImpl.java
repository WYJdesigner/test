package com.re.impl;

import cn.com.icbc.ms.behavior.base.RandomItem;
import cn.com.icbc.ms.behavior.base.RandomManagerNoSave;
import cn.com.icbc.ms.behavior.base.RandomStrGenerater;
import cn.com.icbc.ms.behavior.base.bean.LatticeSegmentationBean;
import cn.com.icbc.ms.behavior.component.IMUniCerInterface;
import cn.com.icbc.ms.behavior.component.KeyPairGenerator;
import cn.com.icbc.ms.behavior.utils.StringUtils;
import cn.com.icbc.ms.behavior.utils.SysLog;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.re.CaptchaAbstractBehavior;
import com.re.inter.CaptchaCommonBehavior;
import com.re.modules.CaphchaBackGroundModule;

import java.awt.*;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Date;

public class CaptchaCommonImpl extends CaptchaAbstractBehavior implements CaptchaCommonBehavior {

    private IMUniCerInterface behaviorCall;
    private boolean isRedisAvail = true;
    private int crypto_kind = 0;
    private KeyPairGenerator keyPairGenerator;
    private int range = 60;
    private static Font g_ft = null;
    private String strIdiom = "";
    private boolean isIdiom = false;
    private int bgWidthStandard = 180;
    private int bgHeightStandard = 150;
    private int bgWidthMaxStandard = 1200;
    private int bgHeightMaxStandard = 1000;
    private String codeSequence = "";

    private int slice_x = 1;
    private int slice_y = 1;
    private int slice_type = 0;
    private int[] sliceNum = null;
    private int blockW = 60;
    private int blockH = 60;

    @Override
    public int getSliceX() {
        return slice_x;
    }

    @Override
    public int getSliceY() {
        return slice_y;
    }

    @Override
    public int getSliceType() {
        return slice_type;
    }

    @Override
    public int[] getSliceNum() {
        return sliceNum;
    }

    @Override
    public int getBlockW() {
        return blockW;
    }

    @Override
    public int getBlockH() {
        return blockH;
    }
//    滑动---------


    //---------d点选
    @Override
    public boolean getIsIdiom() {
        return this.isIdiom;
    }

    @Override
    public void setIsIdiom(boolean isIdiom) {
        this.isIdiom = isIdiom;
    }

    @Override
    public String getStrIdiom() {
        return this.strIdiom;
    }

    @Override
    public String getCodeSequence() {
        return this.codeSequence;
    }

    @Override
    public Font getFont() {
        return g_ft;
    }

    @Override
    public int getBgHeightStandard() {
        return bgHeightStandard;
    }

    @Override
    public int getBgWidthStandard() {
        return bgWidthStandard;
    }

    @Override
    public int getBgHeightMaxStandard() {
        return bgHeightMaxStandard;
    }

    @Override
    public int getBgWidthMaxStandard() {
        return bgWidthMaxStandard;
    }
//    -------------------------

    @Override
    public IMUniCerInterface getBehaviorCall() {
        return this.behaviorCall;
    }

    @Override
    public boolean getIsRedisAvail() {
        return this.isRedisAvail;
    }

    @Override
    public int getEncrypt() {
        return this.crypto_kind;
    }

    @Override
    public KeyPairGenerator getKeyPairGenerator() {
        return this.keyPairGenerator;
    }

    @Override
    public RandomItem setRandomCode(String uniqueid, int[] ri,
                                    ArrayList<LatticeSegmentationBean> rPoint, int width, int height,
                                    int blockW, int blockH, int countPoint, int checkPoint, int fontSize)
            throws Exception {
        RandomItem item = null;
        if (uniqueid == null || uniqueid.length() == 0) {
            return item;
        }
        try {
            if (null == rPoint && width == 0 && height == 0 && blockW == 0
                    && blockH == 0 && countPoint == 0 && checkPoint == 0
                    && fontSize == 0) {
                item = new RandomItem(System.currentTimeMillis(), ri);
            } else if (null == rPoint && countPoint == 0 && checkPoint == 0
                    && fontSize == 0) {
                item = new RandomItem(System.currentTimeMillis(), ri, width,
                        height, blockW, blockH);
            } else if (null == ri && width == 0 && height == 0 && blockW == 0
                    && blockH == 0 && countPoint == 0 && checkPoint == 0
                    && fontSize == 0) {
                item = new RandomItem(System.currentTimeMillis(), rPoint);
            } else if (null == ri && blockW == 0 && blockH == 0) {
                item = new RandomItem(System.currentTimeMillis(), rPoint,
                        width, height, countPoint, checkPoint, fontSize);
            }

            // 耳朵没存过，随机生成存下来
            SecureRandom sRandom = SecureRandom.getInstance("SHA1PRNG");
            sRandom.nextInt(3);
            // Random random = new Random();
            int[] t = new int[4];
            for (int i = 0; i < 4; i++) {
                t[i] = sRandom.nextInt(3);
            }
            if(item == null){
                return item;
            }
            item.setT(t);
            String randomStr = "";
            randomStr = RandomStrGenerater.generateString();
            item.setRandomStr(randomStr);
            if (StringUtils.isEmpty(item.getSr()) && crypto_kind == 2) {
                String sr = RandomStrGenerater.generateRandomNumber();
                item.setSr(sr);
                SysLog.println("随机生成sr：" + item.getSr());
            }
            int status = setItem(uniqueid, item);
            if(status == -1){
                item = null;
            }

        } catch (Exception e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--setRandomCode--error==" + e.toString());
        }
        return item;
    }
    @Override
    public RandomItem setRandomCode(String uniqueid, int[] ri,
                                    ArrayList<LatticeSegmentationBean> rPoint, int width, int height,
                                    int blockW, int blockH, int countPoint, int checkPoint, int fontSize,
                                    String filePath)
            throws Exception {
        RandomItem item = null;
        if (uniqueid == null || uniqueid.length() == 0) {
            return item;
        }
        try {
            if (null == rPoint && width == 0 && height == 0 && blockW == 0
                    && blockH == 0 && countPoint == 0 && checkPoint == 0
                    && fontSize == 0) {
                item = new RandomItem(System.currentTimeMillis(), ri);
            } else if (null == rPoint && countPoint == 0 && checkPoint == 0
                    && fontSize == 0) {
                item = new RandomItem(System.currentTimeMillis(), ri, width,
                        height, blockW, blockH);
            } else if (null == ri && width == 0 && height == 0 && blockW == 0
                    && blockH == 0 && countPoint == 0 && checkPoint == 0
                    && fontSize == 0) {
                item = new RandomItem(System.currentTimeMillis(), rPoint);
            } else if (null == ri && blockW == 0 && blockH == 0) {
                item = new RandomItem(System.currentTimeMillis(), rPoint,
                        width, height, countPoint, checkPoint, fontSize);
            }

            // 耳朵没存过，随机生成存下来
            SecureRandom sRandom = SecureRandom.getInstance("SHA1PRNG");
            sRandom.nextInt(3);
            // Random random = new Random();
            int[] t = new int[4];
            for (int i = 0; i < 4; i++) {
                t[i] = sRandom.nextInt(3);
            }
            if(item == null){
                return item;
            }
            item.setT(t);
            String randomStr = "";
            randomStr = RandomStrGenerater.generateString();
            item.setRandomStr(randomStr);

            String picPath = "";
            if(isRedisAvail){
                picPath = getFileInDir(filePath);
            } else {
                picPath = getFileInDirByUUID(uniqueid, filePath);
            }
            item.setPicPath(picPath);
            if (StringUtils.isEmpty(item.getSr()) && crypto_kind == 2) {
                String sr = RandomStrGenerater.generateRandomNumber();
                item.setSr(sr);
                SysLog.println("随机生成sr：" + item.getSr());
            }
            int status = setItem(uniqueid, item);
            if(status == -1){
                item = null;
            }

        } catch (Exception e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--setRandomCode--error==" + e.toString());
        }
        return item;
    }
    @Override
    public RandomItem getItem(String uniqueid, boolean isPoint, String filePath) {
        RandomItem item = null;
        if (isRedisAvail) {

            String callGetParam = behaviorCall.IMGetStorage(uniqueid);
            SysLog.println("缓存可用获取item字符串:" + callGetParam);
            // 先判断，这里返回失败
            if ("-1".equals(callGetParam) || "".equals(callGetParam)) {

                // 返回失败
                item = generateRandomItem(uniqueid, isPoint);
                if (!"".equals(filePath)) {
                    item.setPicPath(getFileInDirByUUID(uniqueid, filePath));
                }
            } else {
                item = JSONObject.parseObject(callGetParam, RandomItem.class);
//				SysLog.println("缓存可以用获取item字符串:" + JSON.toJSONString(item));
            }

        } else {

            item = generateRandomItem(uniqueid, isPoint);
            SysLog.println("缓存不可用item字符串:" + JSON.toJSONString(item));
            if (!"".equals(filePath)) {
                item.setPicPath(getFileInDirByUUID(uniqueid, filePath));
            }
        }

        return item;
    }

//    @Override
    public int setItem(String uniqueid, RandomItem item) throws IOException {
        String content = JSONObject.toJSONString(item);
        SysLog.println("设置sr之后字符串:" + content);
        String result = behaviorCall.IMSaveStorage(uniqueid, content);
        // 存的时候失败,返回-1，给前端根据uuid生成的滑块高度信息，图文点选的......一些信息
        if ("-1".equals(result)) {
            return -1;
        } else {
            return 1;
        }
    }

    private RandomItem generateRandomItem(String uniqueid, boolean isPoint) {
        //System.out.println("--------redis是坏的，按照uuid生成信息");
        SysLog.println("Captcha--generateRandomItem--redis--error");
        RandomItem item = null;
        if (!isPoint) {
            // 自己根据uuid自己处理生成参数信息
            item = new RandomItem();
            item.setBlockH(60);
            item.setBlockW(60);
            item.setCheckPoint(0);
            item.setCountPoint(0);
            item.setFontSize(0);
            item.setHeight(200);
            item.setWidth(300);
            item.setTimeStamp(new Date().getTime());

            int u1 = getInt(uniqueid, 1);
            int u2 = getInt(uniqueid, 2);
            int u3 = getInt(uniqueid, 3);
            int u4 = getInt(uniqueid, 4);


            // X:uuid中的 的第一个数字 + 第二个数字
            int x = u1 * 10 + u2;
            // y: uuid中的第三个数字 + 第4个数字
            int y = u3 * 10 + u4;
            if(y < this.range){
                y = this.range;
            }
            if(x < this.range){
                x = this.range;
            }
            int[] rPoint = new int[2];
            rPoint[0] = x;
            rPoint[1] = y;
            item.setrPoint(rPoint);
        } else {
            // 自己根据uuid自己处理生成参数信息
            item = new RandomItem();
            item.setCheckPoint(2);
            item.setCountPoint(4);
            item.setFontSize(30);
            item.setHeight(200);
            item.setWidth(300);
            item.setTimeStamp(new Date().getTime());
            int[] u = getInt(uniqueid);
            int u1 = /* getInt(uniqueid, 1); */10 + u[1];
            int u2 = /* getInt(uniqueid, 2); */20 + u[2];
            int u3 = /* getInt(uniqueid, 3); */30 + u[3];
            int u4 = /* getInt(uniqueid, 4); */40 + u[4];
            // X:uuid中的 的第一个数字 + 第二个数字
            // System.out.println("u1 = " + u1 + "    u2 = " + u2 + "   u3 = "
            // + u3 + "  u4 = " + u4);
            // y: uuid中的第三个数字 + 第4个数字
            // item.rPoint[0] = x;
            // item.rPoint[1] = y;
            // 图文
            // 汉字：从uuid 1 x10 ，2 x 10， 3 x 10 汉字补1
            // 汉字位置：3个写死，一个变，变得字根据uuid的第一位来随机在第一等分偏移，控制外
            // 要验证的汉字的1 3
//			SysLog.println("wyj: +" + codeSequence);
            //报错，修改
            String codeSequence = this.getCodeSequence();
            //报错，修改
            ArrayList<LatticeSegmentationBean> rPointAry = new ArrayList<LatticeSegmentationBean>();
            rPointAry.add(new LatticeSegmentationBean(40, 40, 1,
                    codeSequence.charAt(u1)));
            rPointAry.add(new LatticeSegmentationBean(200, 40, 0,
                    codeSequence.charAt(u2)));
            rPointAry.add(new LatticeSegmentationBean(20, 120, 0,
                    codeSequence.charAt(u3)));

            int x4 = 150 + getX(u[4]);
            int y4 = 100 + getY(u[4]);

            rPointAry.add(new LatticeSegmentationBean(
                    x4, y4, 1, codeSequence.charAt(u4)));
            item.setrPointAry(rPointAry);
        }
        if (StringUtils.isEmpty(item.getSr()) && crypto_kind == 2) {
            if (StringUtils.isEmpty(RandomStrGenerater.processString(uniqueid))) return null;
            item.setSr(RandomStrGenerater.processString(uniqueid));
//			SysLog.println("获取验证码参数缓存不可用item字符串:" + JSON.toJSONString(item));
        }
        return item;
    }

    //报错，解决
    //utils需要设置keyPairGenerator 的值
    public void setKeyPairGenerator(KeyPairGenerator keyPairGenerator) {
        if (keyPairGenerator != null) {
            this.keyPairGenerator = keyPairGenerator;
        }
    }

    //utils需要 behaviorCall
    public void setBehaviorCall(IMUniCerInterface behaviorCall) {
        this.behaviorCall = behaviorCall;
    }

    //utils需要 isRedisAvail
    public void setIsRedisAvail(Boolean isRedisAvail) {
        this.isRedisAvail = isRedisAvail;
    }

    //utils需要 crypto_kind
    public void setEncrypt(int crypto_kind) {
        this.crypto_kind = crypto_kind;
    }

    //----------------
    //报错，修改
    //utils需要 以下方法均是utils使用
    public void setStrIdiom(String str) {
        this.strIdiom = str;
    }

    public void setBgHeightStandard(int value) {
        this.bgWidthStandard = value;
    }

    public void setBgWidthStandard(int value) {
        this.bgHeightStandard = value;
    }

    public void setBgHeightMaxStandard(int value) {
        this.bgHeightMaxStandard = value;
    }

    public void setBgWidthMaxStandard(int value) {
        this.bgWidthMaxStandard = value;
    }

    public void setCodeSequence(String codeSequence) {
        this.codeSequence = codeSequence;
    }

    public void setCodeSequence(String str, String encoding) {
        if (!StringUtils.isEmpty(str)) {
            this.codeSequence = str;
        }
    }

    public void setFont(Font ft) {
        if (ft != null) {
            g_ft = ft;
        }
    }

//    ---------------滑动


    //报错，修改
    //以下方法均是utils用到的
    public void setBlockSize(int w, int h) {
        if (w > 0) {
            this.blockW = w;
        }
        if (h > 0) {
            this.blockH = h;
        }
    }

    public void setSliceY(int slice_y) {
        this.slice_y = slice_y;
    }

    public void setSliceNum(int[] sliceNum) {
        this.sliceNum = sliceNum;
    }

    public void setSliceX(int slice_x) {
        this.slice_x = slice_x;
    }

    public void setSliceType(int slice_type) {
        this.slice_type = slice_type;
    }
}
