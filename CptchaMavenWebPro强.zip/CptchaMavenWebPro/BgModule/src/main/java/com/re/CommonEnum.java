package com.re;

public enum CommonEnum {
    Slice_Data_Type,  //slice_data
    Slice_Data_O_Type,//slice_data_o
    Slice_Canvas_Type,//sclice_canvas
    Slice_Bgimage_O_Type,//slice_bgimage_o 滑动验证码背景图片旧方法,主要用于兼容IE8版本
    Slice_Sliceimage_O_Type,//slice_sliceimage_o 滑动验证码抠块图片旧方法,主要用于兼容IE8版本
    Point_Data_Type,  //
    Point_Canvas_Type,
    Point_Idiom_Type,
    Other_Case_Type,
    Slice_Check_Type,
    Point_Check_Type
}
