package com.re.modules;

import java.util.ArrayList;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;

import cn.com.icbc.ms.behavior.base.PointBean;
import cn.com.icbc.ms.behavior.base.RandomItem;
import cn.com.icbc.ms.behavior.base.RandomManagerNoSave;
import cn.com.icbc.ms.behavior.base.bean.LatticeSegmentationBean;
import cn.com.icbc.ms.behavior.component.IMUniCerInterface;
import cn.com.icbc.ms.behavior.utils.*;
import com.re.CommonEnum;
import com.re.domain.VerifyDomain;
import com.re.inter.CaptchaCommonBehavior;
import com.re.inter.CaptchaEncryptBehavior;
import com.re.inter.CaptchaVerifyBehavior;


public class CaptchaVerifyModule {
    // 参数值有误
    private final String ERROR_CODE0 = "ERROR_0";

    // 验证码距离无效
    private final String ERROR_CODE1 = "ERROR_1";

    // 手势轨迹无效
    private final String ERROR_CODE2 = "ERROR_2";

    // 验证时间超时
    private final String ERROR_CODE3 = "ERROR_3";

    private CaptchaCommonBehavior commonBehavior;
    private CaptchaEncryptBehavior encryptBehavior;
    private CaptchaVerifyBehavior verifyBehavior;
    private CaptchaVerifyModule(){}

    public CaptchaVerifyModule(CaptchaEncryptBehavior encryptBehavior, CaptchaCommonBehavior commonBehavior, CaptchaVerifyBehavior verifyBehavior) {
        this.encryptBehavior = encryptBehavior;
        this.commonBehavior = commonBehavior;
        this.verifyBehavior = verifyBehavior;
    }

    public String verifyCaptchaData(VerifyDomain verifyDomain) {
        CommonEnum operation = verifyDomain.getOperation();
        RandomItem item = null;
        String uuid = verifyDomain.getUuid();
        String data = verifyDomain.getData();
        if (operation == CommonEnum.Slice_Check_Type) {
            try {
                item = verifyRandomCode(uuid, false);
                SysLog.println("获取item完毕:" + JSON.toJSONString(item));
            } catch (Exception e) {
                SysLog.println(e.toString());
                SysLog.println("Captcha--verifySlideData--verifyRandomCode--error==" + e.toString());
            }
            return  verifySlideData(uuid, data, item);
        }
        else if ((operation == CommonEnum.Point_Check_Type)) {
            try {
                item = verifyRandomCode(uuid, true);
            } catch (Exception e) {
                SysLog.println(e.toString());
                SysLog.println("Captcha--verifyClickSelect--verifyRandomCode--error==" + e.toString());
            }
            return verifyClickSelect(uuid, data, item);
        }
        else {}
        return "";
    }
    //slice_check 1
//    public String verifySlideData(String uuid, String data) {
//        RandomItem item = null;
//        try {
//            item = verifyRandomCode(uuid, false);
//            SysLog.println("获取item完毕:" + JSON.toJSONString(item));
//        } catch (Exception e) {
//            SysLog.println(e.toString());
//            SysLog.println("Captcha--verifySlideData--verifyRandomCode--error==" + e.toString());
//        }
////		item = new RandomItem( rItemJson.getLongValue("timeStamp"), rPoint, rItemJson.getInteger("width"),  rItemJson.getInteger("height"), blockW, blockH);
//        return  verifySlideData(uuid, data, item);
//    }

    //point_check 1
//    public String verifyClickSelect(String uuid, String data) {
//        RandomItem item = null;
//        try {
//            item = verifyRandomCode(uuid, true);
//        } catch (Exception e) {
//            SysLog.println(e.toString());
//            SysLog.println("Captcha--verifyClickSelect--verifyRandomCode--error==" + e.toString());
//        }
////		String itemJsonStr = behaviorCall.IMGetStorage(uuid);
////		RandomItem item = getRandomItem(itemJsonStr);
//        return verifyClickSelect(uuid, data, item);
//    }

    // point 和 slice 1 - 2.1
    public RandomItem verifyRandomCode(String uniqueid, boolean isPoint) throws Exception {
        RandomItem item = null;

        IMUniCerInterface behaviorCall = this.commonBehavior.getBehaviorCall();
        boolean isRedisAvail = this.commonBehavior.getIsRedisAvail();

        item = this.commonBehavior.getItem(uniqueid, isPoint, "");// 验证的时候不需要图片路径
        //TODO:处理 缓存可用或者不可用情况
        SysLog.println("验证之前获取完毕item：" + JSON.toJSONString(item));
        if (null == item) {
            return null;
        }
        if (isRedisAvail) {
            // 验证完成删除
            behaviorCall.IMCleanStorage(uniqueid);
            SysLog.println("缓存存在，删除uniqueid：" + uniqueid);
        }
        return item;

    }

    // slice 1 - 2.2
    public String verifySlideData(String uuid, String data, RandomItem item) {

        int crypto_kind = this.commonBehavior.getEncrypt();
        boolean isRedisAvail = this.commonBehavior.getIsRedisAvail();
        int connectTimeMax = this.verifyBehavior.getConnectTimeOut();
        int connectTimeMin = this.verifyBehavior.getConnectTimeMin();
        boolean detectWebDriver = this.verifyBehavior.getDetectWebDriver();
        RandomManagerNoSave c_manager = this.verifyBehavior.getC_manager();
        int v1 = this.verifyBehavior.getParameter("v1","","","");
        int v2 = this.verifyBehavior.getParameter("","v2","","");
        int v3 = this.verifyBehavior.getParameter("","","v3","");
        int v4 = this.verifyBehavior.getParameter("","","","v4");

        String repStr = "";
        String txt = this.encryptBehavior.dtStrItem(uuid, data, item,crypto_kind);
        if (StringUtils.isEmpty(txt)) {
            SysLog.println("Captcha--verifySlideData--txt==null");
            return ERROR_CODE0;
        }
        JSONObject obj = JSONObject.parseObject(txt);
        boolean isMobile = obj.getBooleanValue("isMobile");
        String left = obj.getString("left");
        // SysLog.println("param_left:" + left);
        if (left == null) {
            SysLog.println("Captcha--verifySlideData--left==null");
            return ERROR_CODE0;
        }
        if(obj.containsKey("lifeCycleStart") && obj.containsKey("lifeCycleEnd")){
            long lifeCycleA = obj.getLongValue("lifeCycleStart");
            long lifeCycleB = obj.getLongValue("lifeCycleEnd");
            //System.out.println("lifeCycleA:" + lifeCycleA);
            //System.out.println("lifeCycleB:" + lifeCycleB);
            if(lifeCycleA == 0 || lifeCycleB == 0 || (lifeCycleB - lifeCycleA) > connectTimeMax || (lifeCycleB - lifeCycleA) < connectTimeMin){
                SysLog.println("Captcha--verifySlideData--lifeCycle==error");
                return ERROR_CODE3;
            }
        }

        boolean isWebDriver = obj.getBooleanValue("isWebDriver");
        if (detectWebDriver == true && isWebDriver == true) {
            SysLog.println("Captcha--verifySlideData--WebDriver==true");
            return ERROR_CODE0;
        }
        String mouseInfo = obj.getString("mouseInfo");
        // SysLog.println("param_mouseInfo:" + mouseInfo);
        if (mouseInfo == null) {
            SysLog.println("Captcha--verifySlideData--mouseInfo==null");
            return ERROR_CODE0;
        }
        int iLeft = Double.valueOf(left).intValue();
        // RandomItem item = new RandomItem(111111, new int[]{68, 20});
        if(isRedisAvail){
            try {
                item = c_manager.verifyRandomCodeItem(item);
            } catch (Exception e) {
                SysLog.println("Captcha--verifySlideData--verifyRandomCodeItem--error==" + e.toString());
                SysLog.println(e.toString());
            }
        }
        if (item == null) {
            SysLog.println("Captcha--verifySlideData--item==null");
            return ERROR_CODE3;
        } else {
            int[] pointStr = item.getrPoint();
            boolean isPass = false;
            if (iLeft > 0 && this.verifyBehavior.inRange(iLeft, pointStr[0])) {
                isPass = true;
            }
            if (isPass) {
                ArrayList<PointBean> list = JSONObject.parseObject(mouseInfo,
                        new TypeReference<ArrayList<PointBean>>() {
                        });
                if (list.size() < 3) {
                    SysLog.println("Captcha--verifySlideData--list==min");
                    return ERROR_CODE2;
                }
                BehaviorUtils bhUtils = new BehaviorUtils();
                if (v1 == 0 && v2 == 0 && v3 == 0 && v4 == 0) {
                    bhUtils.setParameter(50, 10, 600, 300);
                } else {
                    bhUtils.setParameter(v1, v2, v3, v4);
                }
                if (isMobile) {
                    bhUtils.setMobile(true);
                }
                // bhUtils.CreateCaptcha();
                BehaviorUtils.UserBehavior ub = null;
                try {
                    ub = bhUtils.checkUserBehavior(list, 0);
                } catch (Exception e) {
                    SysLog.println(e.toString());
                    SysLog.println("Captcha--verifySlideData--checkUserBehavior--error==" + e.toString());
                }
                if (ub == null) {
                    SysLog.println("非法操作");
                    repStr = "ERROR_CODE2";
                    return repStr;
                }
                isPass = ub.isBcheck();
                SysLog.println("行为是否正常：" + ub.isBcheck());
                // SysLog.println("水平方向速度：" + ub.getSpeedX());
                // SysLog.println("垂直方向速度：" + ub.getSpeedY());
                // SysLog.println("水平方向加速度：" + ub.getAccelerateX());
                // SysLog.println("垂直方向加速度：" + ub.getAccelerateY());
//                SysLog.println("水平方向偏移量：" + ub.getOffsetX());
//                SysLog.println("垂直方向偏移量：" + ub.getOffsetY());
//                SysLog.println("滑动时间间隔：" + ub.getDuration());
//                SysLog.println("点击时间间隔：" + ub.getInterval());
                if (isPass) {
                    String deviceInfo = obj.getString("deviceInfo");
                    BrowserUtils browserUtils = new BrowserUtils();
                    try {
                        isPass = browserUtils.verifyInfo(deviceInfo);
                    } catch (Exception e) {
                        SysLog.println(e.toString());
                        SysLog.println("Captcha--verifySlideData--verifyInfo--error==" + e.toString());
                    }
                    if (isPass) {
                        SysLog.println("通过");
                        repStr = "SUCCESS";
                        return repStr;
                    } else {
                        SysLog.println("非法操作");
                        repStr = "ERROR_CODE2";
                        return repStr;
                    }
                } else {
                    SysLog.println("非法操作");
                    return ERROR_CODE2;
                }
            } else {
                SysLog.println("拒绝");
                return ERROR_CODE1;
            }
        }
    }

    // point 1 - 2.2
    public String verifyClickSelect(String uuid, String data,RandomItem item) {

        int crypto_kind = this.commonBehavior.getEncrypt();
        boolean isRedisAvail = this.commonBehavior.getIsRedisAvail();
        int connectTimeMax = this.verifyBehavior.getConnectTimeOut();
        int connectTimeMin = this.verifyBehavior.getConnectTimeMin();
        boolean detectWebDriver = this.verifyBehavior.getDetectWebDriver();
        RandomManagerNoSave c_manager = this.verifyBehavior.getC_manager();
        int v1 = this.verifyBehavior.getParameter("v1","","","");
        int v2 = this.verifyBehavior.getParameter("","v2","","");
        int v3 = this.verifyBehavior.getParameter("","","v3","");
        int v4 = this.verifyBehavior.getParameter("","","","v4");
        int StandValue = this.verifyBehavior.getStandParams();

        String repStr = "";
        String str = this.encryptBehavior.dtStrItem(uuid, data,item,crypto_kind);

        //SysLog.println("verifyClickSelect str = " + str);
        if (StringUtils.isEmpty(str)) {
//			return ERROR_CODE0;
            // 解析数据失败
            return "ERROR_990";
        }
        JSONObject obj = JSONObject.parseObject(str);
        boolean isMobile = obj.getBooleanValue("isMobile");
        JSONArray ary = obj.getJSONArray("captchaInfo");
        if (ary == null) {
            // 验证码数据为空
//			return ERROR_CODE0;
            return "ERROR_991";
        }

        if(obj.containsKey("lifeCycleStart") && obj.containsKey("lifeCycleEnd")){
            long lifeCycleA = obj.getLongValue("lifeCycleStart");
            long lifeCycleB = obj.getLongValue("lifeCycleEnd");
            //System.out.println("lifeCycleA:" + lifeCycleA);
            //System.out.println("lifeCycleB:" + lifeCycleB);
            if(lifeCycleA == 0 || lifeCycleB == 0 || (lifeCycleB - lifeCycleA) > connectTimeMax || (lifeCycleB - lifeCycleA) < connectTimeMin){
                // 时间短于最小范围或超过最大范围
                return ERROR_CODE3;
            }
        }

        boolean isWebDriver = obj.getBooleanValue("isWebDriver");
        if (detectWebDriver == true && isWebDriver == true) {
//			return ERROR_CODE0;
            // 前端运行环境是否为webdriver
            return "ERROR_992";
        }
        for (int i = 0; i < ary.size(); i++) {
            SysLog.println("param_ary:" + i + ary.getString(i));
        }

        String mouseInfo = obj.getString("mouseInfo");
        // SysLog.println("param_mouseInfo:" + mouseInfo);
        if (mouseInfo == null) {
//			return ERROR_CODE0;
            // 鼠标滑动信息为空
            return "ERROR_993";
        }

        if(isRedisAvail){
            try {
                item = c_manager.verifyRandomCodeItem(item);
                // item = new RandomItem(111111, new
                // ArrayList<LatticeSegmentationBean>());
            } catch (Exception e) {
                SysLog.println(e.toString());
                SysLog.println("Captcha--verifyClickSelect--verifyRandomCodeItem--error==" + e.toString());
            }
        }
        if (item == null) {
            // 本地缓存数据为空
            return "ERROR_994";
        } else {
            boolean isPass = false;
            ArrayList<LatticeSegmentationBean> aryBeanList = item
                    .getrPointAry();
            if (aryBeanList == null || aryBeanList.size() == 0) {
//				return ERROR_CODE0;
                return "ERROR_995";
            }

            ArrayList<LatticeSegmentationBean> isMarkList = new ArrayList<LatticeSegmentationBean>();
            for (int i = 0; i < aryBeanList.size(); i++) {
                LatticeSegmentationBean lsBean = aryBeanList.get(i);
                if (lsBean.getM_isMark() == 1) {
                    isMarkList.add(lsBean);
                }
            }
            if (ary.size() != isMarkList.size()) {
//				return ERROR_CODE0;
                return "ERROR_996";
            }

            int verifySuccess = 0;
            for (int i = 0; i < isMarkList.size(); i++) {
                LatticeSegmentationBean latticeBean = isMarkList.get(i);
                String t = ary.getString(i);
                JSONObject pointObj = JSONObject.parseObject(t);
                // String[] p = t.split("||");
                if (this.verifyBehavior.inRange(Integer.valueOf(pointObj.getInteger("x")),
                        latticeBean.getM_xRangePoint())
                        && this.verifyBehavior.inRange(Integer.valueOf(pointObj.getInteger("y")),
                        latticeBean.getM_yRangePoint())) {
                    verifySuccess++;
                }
            }
            if (verifySuccess == isMarkList.size()) {
                isPass = true;
            }

            /*
             * if (iLeft > 0 && iLeft > pointStr[0]-10 && iLeft <
             * pointStr[0]+10) { isPass = true; }
             */
            if (isPass) {
                if (isMobile) {
                    SysLog.println("移动端图文验证码");
//					String motion = obj.getString("motion");
//					if (motion == null) {
//						SysLog.println("传感器为空");
//						return ERROR_CODE0;
//					}
//					SensorBean sensor = JSONObject.parseObject(motion,
//							SensorBean.class);
//					SensorUtils sensorUtils = new SensorUtils();
//					if (sensorUtils.checkUserSensor(sensor)) {
//						SysLog.println("传感器验证失败");
//						return ERROR_CODE2;
//					} else {
//						String deviceInfo = obj.getString("deviceInfo");
//						BrowserUtils browserUtils = new BrowserUtils();
//						try {
//							isPass = browserUtils.verifyInfo(deviceInfo);
//						} catch (Exception e) {
//							SysLog.println(e.toString());
//						}
//					}
                    if (isPass) {
                        SysLog.println("通过");
                        repStr = "SUCCESS";
                        return repStr;
                    } else {
                        SysLog.println("非法操作");
                        repStr = "ERROR_CODE2";
                        return repStr;
                    }
                }
                ArrayList<PointBean> list = JSONObject.parseObject(mouseInfo,
                        new TypeReference<ArrayList<PointBean>>() {
                        });
                // 验证标准差
                String verifyStand = verifyStand(list);
                if(StandValue != -1 ){
                    if(ERROR_CODE0.equals(verifyStand)){
                        return ERROR_CODE2;
                    }

                }
                if (list.size() < 3) {
                    return ERROR_CODE2;
                }
                BehaviorUtils bhUtils = new BehaviorUtils();
                if (v1 == 0 && v2 == 0 && v3 == 0 && v4 == 0) {
//					bhUtils.setParameter(60, 60, 800, 400);
                    int defaultXoffset = ConfigUtil.getParamAsStr("behavior.defaultYoffset") == null?50:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.defaultYoffset"));
                    int defaultYoffset = ConfigUtil.getParamAsStr("behavior.defaultYoffset") == null?10:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.defaultYoffset"));
                    int defaultDuration =  ConfigUtil.getParamAsStr("behavior.defaultDuration") == null?600:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.defaultDuration"));
                    int defaultInterval =  ConfigUtil.getParamAsStr("behavior.defaultInterval") == null?300:Integer.parseInt(ConfigUtil.getParamAsStr("behavior.defaultInterval"));
                    bhUtils.setParameter(defaultXoffset, defaultYoffset, defaultDuration, defaultInterval);
                } else {
                    bhUtils.setParameter(v1, v2, v3, v4);
                }
                bhUtils.setCount(aryBeanList.size());
                BehaviorUtils.UserBehavior ub = null;
                try {
                    ub = bhUtils.checkUserBehavior(list, 1);
                } catch (Exception e) {
                    SysLog.println(e.toString());
                    SysLog.println("Captcha--verifyClickSelect--checkUserBehavior--error==" + e.toString());
                }
                if (ub == null) {
                    SysLog.println("非法操作");
                    return ERROR_CODE2;
                }
                isPass = ub.isBcheck();
                SysLog.println("行为是否正常：" + ub.isBcheck());
                // SysLog.println("水平方向速度：" + ub.getSpeedX());
                // SysLog.println("垂直方向速度：" + ub.getSpeedY());
                // SysLog.println("水平方向加速度：" + ub.getAccelerateX());
                // SysLog.println("垂直方向加速度：" + ub.getAccelerateY());
                SysLog.println("水平方向偏移量：" + ub.getOffsetX());
                SysLog.println("垂直方向偏移量：" + ub.getOffsetY());
                SysLog.println("滑动时间间隔：" + ub.getDuration());
                SysLog.println("点击时间间隔：" + ub.getInterval());
                if (isPass) {
                    String deviceInfo = obj.getString("deviceInfo");
                    BrowserUtils browserUtils = new BrowserUtils();
                    try {
                        isPass = browserUtils.verifyInfo(deviceInfo);
                    } catch (Exception e) {
                        SysLog.println(e.toString());
                        SysLog.println("Captcha--verifyClickSelect--verifyInfo--error==" + e.toString());
                    }
                    if (isPass) {
                        SysLog.println("通过");
                        repStr = "SUCCESS";
                        return repStr;
                    } else {
                        SysLog.println("非法操作");
                        repStr = "ERROR_CODE2";
                        return repStr;
                    }
                } else {
                    SysLog.println("非法操作");
                    return ERROR_CODE2;
                }
            } else {
                SysLog.println("拒绝");
                return ERROR_CODE1;
            }
        }
    }

    private String verifyStand(ArrayList<PointBean> list) {

        int StandValue = this.verifyBehavior.getStandParams();

        // TODO Auto-generated method stub
        int[] x = new int[list.size()];
        int[] y = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            x[i] = list.get(i).getX();
        }
        for (int j = 0; j < list.size(); j++) {
            y[j] = list.get(j).getY();
        }
        double xLoc = StandardDiviation(x);
        double yLoc = StandardDiviation(y);
        if (xLoc > StandValue) {
            return ERROR_CODE0;
        }
        if (yLoc > StandValue) {
            return ERROR_CODE0;
        }
        return "";
    }

    public double StandardDiviation(int[] x) {
        int m = x.length;
        int sum = 0;
        for (int i = 0; i < m; i++) {// 求和
            sum += x[i];
        }
        int dAve = sum / m;// 求平均值
        int dVar = 0;
        for (int i = 0; i < m; i++) {// 求方差
            dVar += (x[i] - dAve) * (x[i] - dAve);
        }
        return Math.sqrt(dVar / m);
    }

}
