package com.re.inter;

import cn.com.icbc.ms.behavior.base.RandomManagerNoSave;

public interface CaptchaVerifyBehavior {


    int getConnectTimeOut(); // 验证

    int getConnectTimeMin(); // 验证

    int getParameter(String v1, String v2, String v3, String v4); // 验证

    boolean getDetectWebDriver();// 验证

    RandomManagerNoSave getC_manager(); // 验证

    int  getStandParams(); // 验证

    boolean inRange(int value1, int value2);//验证

}
