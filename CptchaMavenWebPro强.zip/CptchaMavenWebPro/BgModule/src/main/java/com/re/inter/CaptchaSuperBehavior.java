package com.re.inter;

import com.re.modules.CaphchaBackGroundModule;

public interface CaptchaSuperBehavior {
    //获取模块
    CaphchaBackGroundModule getBackGroundModule();//参数
}
