package com.re.modules;

import cn.com.icbc.ms.behavior.base.RandomItem;
import cn.com.icbc.ms.behavior.base.bean.LatticeSegmentationBean;
import cn.com.icbc.ms.behavior.component.KeyPairGenerator;
import cn.com.icbc.ms.behavior.exception.BehaviorFailException;
import cn.com.icbc.ms.behavior.utils.*;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.re.CommonEnum;
import com.re.domain.CommonDomain;
import com.re.inter.*;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Base64;

public class CaptchaCommonModule {

    private CaptchaCommonBehavior commonBehavior;
    private CaptchaEncryptBehavior encryptBehavior;
    private CaptchaSuperBehavior superBehavior;
    private CaptchaCommonModule(){}

    public CaptchaCommonModule(CaptchaCommonBehavior commonBehavior,
                               CaptchaEncryptBehavior encryptBehavior,
                               CaptchaSuperBehavior superBehavior) {
        this.commonBehavior = commonBehavior;
        this.encryptBehavior = encryptBehavior;
        this.superBehavior = superBehavior;
    }

    public JSONObject getCommonParams(CommonDomain commonDomain) throws BehaviorFailException {
        CommonEnum operation = commonDomain.getOperation();
        switch (operation) {
            case Slice_Data_Type:
            case Slice_Canvas_Type: {
                String uuid = commonDomain.getUuid();
                int width = commonDomain.getWidth();
                int height = commonDomain.getHeight();
                String filePath = commonDomain.getFilePath();
                // 参数
                HashMap<String,Object> retMap = getSlideParams(uuid,width,height,filePath);
                String str = retMap.get("getSlideParamsStr") == null?"":String.valueOf(retMap.get("getSlideParamsStr"));
                // 背景图
                RandomItem item =  (RandomItem) (retMap.get("getSlideParamsItem") == null?null:retMap.get("getSlideParamsItem"));
                commonDomain.setItem(item);
                byte[] bgbts = this.superBehavior.getBackGroundModule().getCommonBackGround(commonDomain);
                if (bgbts == null) {

                }
                String bgbase64bts=EncodeUtils.encode2Base64(bgbts);
                // 抠图
                byte[] slicebts = this.superBehavior.getBackGroundModule().getCommonBlockParams(commonDomain);
                if (slicebts == null) {

                }
                String slicebase64bts=EncodeUtils.encode2Base64(slicebts);
                JSONObject obj2 = new JSONObject();
                obj2.put("data", str);
                obj2.put("bgimg", bgbase64bts);
                obj2.put("sliceimg", slicebase64bts);
                return obj2;
            }
            case Slice_Data_O_Type: {
                String uuid = commonDomain.getUuid();
                int width = commonDomain.getWidth();
                int height = commonDomain.getHeight();
                String filePath = commonDomain.getFilePath();
                // 参数
                HashMap<String,Object> retMap = getSlideParams(uuid,width,height,filePath);
                String str = retMap.get("getSlideParamsStr") == null?"":String.valueOf(retMap.get("getSlideParamsStr"));
                JSONObject obj2 = new JSONObject();
                obj2.put("data", str);
                return obj2;
            }
            case Slice_Bgimage_O_Type: {
                String uuid = commonDomain.getUuid();
                String filePath = commonDomain.getFilePath();
                byte[] byteArray = this.superBehavior.getBackGroundModule().getCommonBackGround(commonDomain);
//                byte[] byteArray = this.commonBehavior.getBackGroundModule().getSlideBackgroundStream(uuid,filePath);
                JSONObject jsonObject = new JSONObject();
                if (byteArray != null) {
                    String base64Encoded = Base64.getEncoder().encodeToString(byteArray);
                    jsonObject.put("data", base64Encoded);
                }
                return jsonObject;
            }
            case Slice_Sliceimage_O_Type: {
                String uuid = commonDomain.getUuid();
                String filePath = commonDomain.getFilePath();
                byte[] byteArray = this.superBehavior.getBackGroundModule().getSlideBlockImageStream(uuid,filePath);
                JSONObject jsonObject = new JSONObject();
                if (byteArray != null) {
                    String base64Encoded = Base64.getEncoder().encodeToString(byteArray);
                    jsonObject.put("data",base64Encoded);
                }
                return jsonObject;
            }
            case Point_Idiom_Type: {
                int type = commonDomain.getType();
                String uuid = commonDomain.getUuid();
                int bgwidth = commonDomain.getBgwidth();
                int bgheight = commonDomain.getBgheight();
                int bgfontSize = commonDomain.getBgfontSize();
                InputStream iStream = commonDomain.getiStream();
                int fontSize = commonDomain.getFontSize();
                return getClickSelectIdiom(type, uuid, bgwidth, bgheight, bgfontSize, iStream, fontSize);
            }
            case Point_Data_Type: {
                String uuid = commonDomain.getUuid();
                int bgwidth = commonDomain.getBgwidth();
                int bgheight = commonDomain.getBgheight();
                int bgfontSize = commonDomain.getBgfontSize();
                InputStream iStream = commonDomain.getiStream();
                int width = commonDomain.getWidth();
                int height = commonDomain.getHeight();
                int fontSize = commonDomain.getFontSize();
                int countPoint = commonDomain.getCountPoint();
                int checkPoint = commonDomain.getCheckPoint();
                return getClickSelectImg(uuid, bgwidth, bgheight, countPoint, checkPoint, bgfontSize, iStream, width, height, fontSize);
            }
            case Point_Canvas_Type: {
                String uuid = commonDomain.getUuid();
                int bgwidth = commonDomain.getBgwidth();
                int bgheight = commonDomain.getBgheight();
                int countPoint = commonDomain.getCountPoint();
                int checkPoint = commonDomain.getCheckPoint();
                int bgfontSize = commonDomain.getBgfontSize();
                InputStream iStream = commonDomain.getiStream();
                int width = commonDomain.getWidth();
                int height = commonDomain.getHeight();
                int fontSize = commonDomain.getFontSize();
                return getClickSelectImgCanvas(uuid, bgwidth, bgheight, countPoint, checkPoint, bgfontSize, iStream, width, height, fontSize);
            }
            default:
            JSONObject obj = new JSONObject();
            return obj;
        }
    }
    /*
     * 根据传入的参数生成滑动验证码的相关参数，并将这些参数存储在一个 HashMap 中返回。
     * */
    //canvas:false stream:true. slice_data_o 1
    //canvas:false stream:false slice_data  1
    //canvas:true  stream: fasle slice_canvas 1
    public HashMap<String,Object> getSlideParams(String uuid, int width, int height, String filePath) {
        String params = "";
        ImageUtils imUtils = new ImageUtils();

        int blockW = this.commonBehavior.getBlockW();
        int blockH = this.commonBehavior.getBlockH();
        int slice_x = this.commonBehavior.getSliceX();
        int slice_y = this.commonBehavior.getSliceY();
        int slice_type = this.commonBehavior.getSliceType();
        int[] sliceNum = this.commonBehavior.getSliceNum();
        boolean isRedisAvail = this.commonBehavior.getIsRedisAvail();
        int crypto_kind = this.commonBehavior.getEncrypt();
        KeyPairGenerator keyPairGenerator = this.commonBehavior.getKeyPairGenerator();

        if (blockW == 0 || blockH == 0) {
            blockW = 60;
            blockH = 60;
        }
        int[] ri = imUtils.randomPoint(width, height, blockW, blockH);
        ri[0] += blockW / 2;
        ri[1] += blockH / 2;
//        SysLog.println("ri[0]" + ri[0]);
//        SysLog.println("ri[1]" + ri[1]);

        PhotoCutting pct = new PhotoCutting();
        if(slice_x == 1 && slice_y == 1){
            if(slice_type == 1){
                slice_x = 1;
                slice_y = 3;
            } else if(slice_type == 2){
                slice_x = 1;
                slice_y = 5;
            } else if(slice_type == 3){
                slice_x = 1;
                slice_y = 10;
            } else if(slice_type == 4){
                slice_x = 1;
                slice_y = 20;
            } else if(slice_type == 5){
                slice_x = 1;
                slice_y = 50;
            } else{
                slice_x = 1;
                slice_y = 1;
            }
        }
        sliceNum = pct.shuffleArray(slice_x * slice_y);

        RandomItem item = null;
        JSONObject obj = new JSONObject();
        String randomStr = "";

        if(isRedisAvail) {
            try {
                SysLog.println("获取验证码参数-缓存可以用");
                item = this.commonBehavior.setRandomCode(uuid, ri, null, width, height, blockW, blockH, 0, 0, 0, filePath);
                randomStr = item == null ? "":item.getRandomStr();
                if(item == null){
                    // redis降级
                    item = this.commonBehavior.getItem(uuid, false, filePath);
                    obj.put("pointY", item.getrPoint()[1]);
                }else {
                    obj.put("pointY", ri[1]);
                }
            } catch (Exception e) {
                SysLog.println(e.toString());
                SysLog.println("Captcha--getSlideParams--setRandomCode--error==" + e.toString());
            }
        } else {
            SysLog.println("初始化的时候redis是异常的");
            // redis降级
            item = this.commonBehavior.getItem(uuid, false, filePath);
            obj.put("pointY", item.getrPoint()[1]);
            randomStr = "";
        }

		/*String randomStr = "";
		RandomItem item = null;
		try {
			item =c_manager.setRandomCode4Item(uuid, ri, width, height,
					blockW, blockH, gp);
			randomStr = item == null ? "":item.getRandomStr();
		} catch (Exception e) {
			SysLog.println(e.toString());
		}*/

        obj.put("keys", randomStr);
        obj.put("picSort", sliceNum);
        SysLog.println("打印完整的item:" + JSON.toJSONString(item));
        if (crypto_kind == 2 && keyPairGenerator != null) {
            SysLog.println("下发给前端的sr：" + item.getSr());
            obj.put("sr",item.getSr());
            obj.put("publicKeyModulus", keyPairGenerator.getKeyPairInfo().getPublicModule());
            obj.put("publicKeyExponent", keyPairGenerator.getKeyPairInfo().getPublicExponen());
        }
        params = JSONObject.toJSONString(obj);
        SysLog.println("getSlideParams:" + params);
        params = this.encryptBehavior.WYJetStr(uuid, params,crypto_kind);
        HashMap<String,Object> retMap = new HashMap<String,Object>();
        retMap.put("getSlideParamsStr", params);
        retMap.put("getSlideParamsItem", item);
//		retMap.put("getSlideParamsItemJsonStr", getSlideParamsItemJsonStr(uuid, item));
        return retMap;
    }

    // canvase:true stream: false point_idiom 1
    public JSONObject getClickSelectIdiom(int type, String uuid, int bgwidth, int bgheight,
                                          int bgfontSize, InputStream iStream, int fontSize) throws BehaviorFailException{
        /*
         * 这个属性用于标识生成的验证码是否为汉字成语验证码。
         * */
//        this.isIdiom = true;
        this.commonBehavior.setIsIdiom(true);
        int bgWidthStandard = this.commonBehavior.getBgWidthStandard();
        int bgHeightStandard = this.commonBehavior.getBgHeightStandard();
        int bgWidthMaxStandard = this.commonBehavior.getBgWidthMaxStandard();
        int bgHeightMaxStandard = this.commonBehavior.getBgHeightMaxStandard();

        JSONObject jsonObject = null;
        //校验图片大小基准
        if(bgwidth < bgWidthStandard || bgheight < bgHeightStandard || bgwidth > bgWidthMaxStandard || bgheight > bgHeightMaxStandard){
            jsonObject = new JSONObject();
            jsonObject.put("retFlag", "-3");
            jsonObject.put("errorMsg", "params_error");
            return jsonObject;
        }

        if(bgfontSize <= 0){
            jsonObject = new JSONObject();
            jsonObject.put("retFlag", "-7");
            jsonObject.put("errorMsg", "params_error");
            return jsonObject;
        }

        if(iStream == null){
            jsonObject = new JSONObject();
            jsonObject.put("retFlag", "-8");
            jsonObject.put("errorMsg", "params_error");
            return jsonObject;
        }

        if(StringUtils.isEmpty(uuid)){
            jsonObject = new JSONObject();
            jsonObject.put("retFlag", "-9");
            jsonObject.put("errorMsg", "params_error");
            return jsonObject;
        }
        if (type == 1){
            jsonObject = createClickSelectImgAndPoint(uuid, bgwidth, bgheight, 4, 4, bgfontSize, iStream, 0, 0, fontSize);
        } else {
            jsonObject = createClickSelectImgAndPointCanvas(uuid, bgwidth, bgheight, 4, 4, bgfontSize, iStream, 100, 30, fontSize);
        }
//		jsonObject = createClickSelectImgAndPointCanvas(uuid, bgwidth, bgheight, 4, 4, bgfontSize, iStream, width, height, fontSize);
        try {
            iStream.close();
        } catch (IOException e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--getClickSelectIdiom--iStream.close--error==" + e.toString());
        }
        if(!"0".equals(jsonObject.get("retFlag")) || null == jsonObject ){
            return null;
        }
//		jsonObject.put("getClickSelectParamsItemJsonStr", jsonObject.getString("itemJsonStr"));
        jsonObject.remove("itemJsonStr");
        return jsonObject == null? null:(JSONObject) jsonObject.clone();

    }

    // useCavas:false useStream: fasle  ponit_data 1
    public JSONObject getClickSelectImg(String uuid, int bgwidth, int bgheight,
                                        int countPoint, int checkPoint, int bgfontSize, InputStream iStream,int width, int height,
                                        int fontSize) throws BehaviorFailException{
        JSONObject obj2 = null;

        int bgWidthStandard = this.commonBehavior.getBgWidthStandard();
        int bgHeightStandard = this.commonBehavior.getBgHeightStandard();
        int bgWidthMaxStandard = this.commonBehavior.getBgWidthMaxStandard();
        int bgHeightMaxStandard = this.commonBehavior.getBgHeightMaxStandard();

        //校验图片大小基准
        if(bgwidth < bgWidthStandard || bgheight < bgHeightStandard || bgwidth > bgWidthMaxStandard || bgheight > bgHeightMaxStandard){
            obj2 = new JSONObject();
            obj2.put("retFlag", "-3");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }

        if(width < 100  || width > bgWidthMaxStandard || height > bgHeightMaxStandard || height <= 0){
            obj2 = new JSONObject();
            obj2.put("retFlag", "-6");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }

        if(bgfontSize <= 0  || fontSize<=0){
            obj2 = new JSONObject();
            obj2.put("retFlag", "-7");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }

        if(iStream == null){
            obj2 = new JSONObject();
            obj2.put("retFlag", "-8");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }

        if(StringUtils.isEmpty(uuid)){
            obj2 = new JSONObject();
            obj2.put("retFlag", "-9");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }
        if(countPoint == 0 || countPoint>7){
            obj2 = new JSONObject();
            obj2.put("retFlag", "-4");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }

        if(checkPoint == 0 || checkPoint > countPoint ){
            obj2 = new JSONObject();
            obj2.put("retFlag", "-5");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }
        obj2 = createClickSelectImgAndPoint(uuid, bgwidth, bgheight, countPoint, checkPoint, bgfontSize, iStream, width, height, fontSize);
        try {
            iStream.close();
        } catch (IOException e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--getClickSelectImg--iStream.close--error==" + e.toString());
        }
        if(!"0".equals(obj2.get("retFlag")) || null == obj2 ){
            return null;
        }
//		obj2.put("getClickSelectParamsItemJsonStr", obj2.getString("itemJsonStr"));
        obj2.remove("itemJsonStr");
        return obj2 == null? null:(JSONObject) obj2.clone();
    }
    //useCanvas:true useStream:false point_canvas 1
    public JSONObject getClickSelectImgCanvas(String uuid, int bgwidth, int bgheight,
                                              int countPoint, int checkPoint, int bgfontSize, InputStream iStream,int width, int height,
                                              int fontSize) throws BehaviorFailException{
        JSONObject obj2 = null;

        int bgWidthStandard = this.commonBehavior.getBgWidthStandard();
        int bgHeightStandard = this.commonBehavior.getBgHeightStandard();
        int bgWidthMaxStandard = this.commonBehavior.getBgWidthMaxStandard();
        int bgHeightMaxStandard = this.commonBehavior.getBgHeightMaxStandard();

        //校验图片大小基准
        if(bgwidth < bgWidthStandard || bgheight < bgHeightStandard || bgwidth > bgWidthMaxStandard || bgheight > bgHeightMaxStandard){
            obj2 = new JSONObject();
            obj2.put("retFlag", "-3");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }

        if(width < 100  || width > bgWidthMaxStandard || height > bgHeightMaxStandard || height <= 0){
            obj2 = new JSONObject();
            obj2.put("retFlag", "-6");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }

        if(bgfontSize <= 0  || fontSize<=0){
            obj2 = new JSONObject();
            obj2.put("retFlag", "-7");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }

        if(iStream == null){
            obj2 = new JSONObject();
            obj2.put("retFlag", "-8");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }

        if(StringUtils.isEmpty(uuid)){
            obj2 = new JSONObject();
            obj2.put("retFlag", "-9");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }
        if(countPoint == 0 || countPoint>7){
            obj2 = new JSONObject();
            obj2.put("retFlag", "-4");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }

        if(checkPoint == 0 || checkPoint > countPoint ){
            obj2 = new JSONObject();
            obj2.put("retFlag", "-5");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }
        obj2 = createClickSelectImgAndPointCanvas(uuid, bgwidth, bgheight, countPoint, checkPoint, bgfontSize, iStream, width, height, fontSize);
        try {
            iStream.close();
        } catch (IOException e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--getClickSelectImgCanvas--iStream.close--error==" + e.toString());
        }
        if(!"0".equals(obj2.get("retFlag")) || null == obj2 ){
            return null;
        }
//		obj2.put("getClickSelectParamsItemJsonStr", obj2.getString("itemJsonStr"));
        obj2.remove("itemJsonStr");
        return obj2 == null? null:(JSONObject) obj2.clone();
    }

    // getClickSelectImgCanvas()方法调用 2
    // getClickSelectIdiom() 2
    public JSONObject
    createClickSelectImgAndPointCanvas(String uuid, int bgwidth, int bgheight,
                                                         int countPoint, int checkPoint, int bgfontSize, InputStream iStream,int width, int height,
                                                         int fontSize) throws BehaviorFailException{
        int slice_x = this.commonBehavior.getSliceX();
        int slice_y = this.commonBehavior.getSliceY();
        int slice_type = this.commonBehavior.getSliceType();
        int[] sliceNum = this.commonBehavior.getSliceNum();


        JSONObject obj2 = new JSONObject();
        obj2.put("uuid", uuid);
        //获取参数
        PhotoCutting pct = new PhotoCutting();
        if(slice_x == 1 && slice_y == 1){
            if(slice_type == 1){
                slice_x = 1;
                slice_y = 3;
            } else if(slice_type == 2){
                slice_x = 1;
                slice_y = 5;
            } else if(slice_type == 3){
                slice_x = 1;
                slice_y = 10;
            } else if(slice_type == 4){
                slice_x = 1;
                slice_y = 20;
            } else if(slice_type == 5){
                slice_x = 1;
                slice_y = 50;
            } else{
                slice_x = 1;
                slice_y = 1;
            }
        }
        sliceNum = pct.shuffleArray(slice_x * slice_y);

        HashMap<String,Object> retMap = getClickSelectParams(uuid, bgwidth, bgheight, countPoint, checkPoint,
                bgfontSize);
        String str = retMap.get("getClickSelectParamsStr") == null?"":String.valueOf(retMap.get("getClickSelectParamsStr"));
        RandomItem item =  (RandomItem) (retMap.get("getClickSelectParamsItem") == null?null:retMap.get("getClickSelectParamsItem"));
//		String itemStr = retMap.get("getClickSelectParamsItemJsonStr") == null?"":String.valueOf(retMap.get("getClickSelectParamsItemJsonStr"));
//		obj2.put("getClickSelectParamsStr", str);
//		obj2.put("getClickSelectParamsItemJsonStr", itemStr);
        //缓存样本数不够的场景需要生成图片

        //获取背景图片
        byte[] bgbts = this.superBehavior.getBackGroundModule(). getClickSelectBackgroundCanvas( item,  iStream);
        if (bgbts == null) {
            obj2.put("retFlag", "-1");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }
        String bgbase64bts=EncodeUtils.encode2Base64(bgbts);
        obj2.put("bgimg", bgbase64bts);

        //生成提示文字
        String selectbase64bts = "";
        if(width != 0 && height != 0){
            byte[] selectbts = getClickSelectFontImage(item, width, height, fontSize);
            if (selectbts == null) {
                obj2.put("retFlag", "-2");
                obj2.put("errorMsg", "params_error");
                return obj2;
            }
            selectbase64bts = EncodeUtils.encode2Base64(selectbts);
        }

        obj2.put("selectimg", selectbase64bts);
        obj2.put("retFlag", "0");
        obj2.put("data", str);
//		obj2.put("itemJsonStr",getSlideParamsItemJsonStr(uuid, item));
        return obj2;
    }

    // getClickSelectImg 2
    // getClickSelectIdiom 2
    public JSONObject createClickSelectImgAndPoint(String uuid, int bgwidth, int bgheight,
                                                   int countPoint, int checkPoint, int bgfontSize, InputStream iStream,int width, int height,
                                                   int fontSize) throws BehaviorFailException{

        JSONObject obj2 = new JSONObject();
        obj2.put("uuid", uuid);
        //获取参数
        HashMap<String,Object> retMap = getClickSelectParams(uuid, bgwidth, bgheight, countPoint, checkPoint,
                bgfontSize);
        String str = retMap.get("getClickSelectParamsStr") == null?"":String.valueOf(retMap.get("getClickSelectParamsStr"));
        RandomItem item =  (RandomItem) (retMap.get("getClickSelectParamsItem") == null?null:retMap.get("getClickSelectParamsItem"));
//		String itemStr = retMap.get("getClickSelectParamsItemJsonStr") == null?"":String.valueOf(retMap.get("getClickSelectParamsItemJsonStr"));
//		obj2.put("getClickSelectParamsStr", str);
//		obj2.put("getClickSelectParamsItemJsonStr", itemStr);
        //缓存样本数不够的场景需要生成图片
        //获取背景图片
        byte[] bgbts = this.superBehavior.getBackGroundModule().getClickSelectBackground( item,  iStream);

        if (bgbts == null) {
            obj2.put("retFlag", "-1");
            obj2.put("errorMsg", "params_error");
            return obj2;
        }
        String bgbase64bts= EncodeUtils.encode2Base64(bgbts);
        obj2.put("bgimg", bgbase64bts);

        //生成提示文字
        if(width == 0 || height == 0){
            obj2.put("selectimg", "");
        } else {
            byte[] selectbts = getClickSelectFontImage(item, width, height, fontSize);
            if (selectbts == null) {
                obj2.put("retFlag", "-2");
                obj2.put("errorMsg", "params_error");
                return obj2;
            }
            String selectbase64bts = EncodeUtils.encode2Base64(selectbts);
            obj2.put("selectimg", selectbase64bts);
        }
        /*byte[] selectbts = getClickSelectFontImage(item, width, height, fontSize);
		if (selectbts == null) {
			obj2.put("retFlag", "-2");
			obj2.put("errorMsg", "params_error");
	        return obj2;
	    }
		String selectbase64bts = EncodeUtils.encode2Base64(selectbts);
		obj2.put("selectimg", selectbase64bts);*/
        obj2.put("retFlag", "0");
        obj2.put("data", str);
//		obj2.put("itemJsonStr",getSlideParamsItemJsonStr(uuid, item));
        return obj2;
    }

    // createClickSelectImgAndPointCanvas 123
    // createClickSelectImgAndPoint 123
    public HashMap<String,Object> getClickSelectParams(String uuid, int width, int height,
                                                       int countPoint, int checkPoint, int fontSize) throws BehaviorFailException {
        String params = "";
        HashMap<String,Object> retMap = null;
        ArrayList<LatticeSegmentationBean> rPoint = null;

        int blockW = this.commonBehavior.getBlockW();
        int blockH = this.commonBehavior.getBlockH();
        int slice_x = this.commonBehavior.getSliceX();
        int slice_y = this.commonBehavior.getSliceY();
        int slice_type = this.commonBehavior.getSliceType();
        int[] sliceNum = this.commonBehavior.getSliceNum();
        boolean isRedisAvail = this.commonBehavior.getIsRedisAvail();
        int crypto_kind = this.commonBehavior.getEncrypt();
        KeyPairGenerator keyPairGenerator = this.commonBehavior.getKeyPairGenerator();
        boolean isIdiom = this.commonBehavior.getIsIdiom();
        String strIdiom = this.commonBehavior.getStrIdiom();
        String codeSequence = this.commonBehavior.getCodeSequence();

        try {
            ImageUtils imUtils = new ImageUtils();
//			imUtils.randomPoint(width, height, countPoint);
            rPoint = imUtils.randomPoint(
                    width, height, countPoint);
            for (int i = 0; i < rPoint.size(); i++) {
                LatticeSegmentationBean bean = rPoint.get(i);
                int x = randomChangeValue(bean.getM_xRangePoint());
                int y = randomChangeValue(bean.getM_yRangePoint());
                bean.setM_xRangePoint(x);
                bean.setM_yRangePoint(y);
                rPoint.set(i, bean);
            }
            int t = 0;
            // Random random = new Random();
            SecureRandom sRandom = SecureRandom.getInstance("SHA1PRNG");
            do {
                int n = sRandom.nextInt(rPoint.size());
                LatticeSegmentationBean bean = rPoint.get(n);
                if (bean.getM_isMark() != 1) {
                    bean.setM_isMark(1);
                    ++t;
                }
            } while (t < checkPoint);

            // 随机产生验证码
            if(isIdiom){
                // 成语点选验证码
                String[] aryStrIdiom = strIdiom.split(",");
                String idiom = aryStrIdiom[sRandom.nextInt(aryStrIdiom.length)];
                for (int i = 0; i < countPoint; i++) {
                    char at = idiom.charAt(i);
                    rPoint.get(i).setM_txt(at);
                }
            } else {
                // 点选验证码
                int len = codeSequence.length();
                String str = "";
                for (int i = 0; i < countPoint; i++) {
                    char at = codeSequence.charAt(sRandom.nextInt(len));
                    while (str.contains(String.valueOf(at))) {
                        at = codeSequence.charAt(sRandom.nextInt(len));
                    }
                    str += at;
                    rPoint.get(i).setM_txt(at);
                }
            }
//			GeneralPath gp = imUtils.drawPath(blockW, blockH);
            RandomItem item = null;
            String randomStr = "";
            if(isRedisAvail) {
                try {
                    item = this.commonBehavior.setRandomCode(uuid, null, rPoint, width,
                            height, 0, 0, countPoint, checkPoint, fontSize);
                    randomStr = item == null ? "":item.getRandomStr();
                    if(item == null){
                        // redis降级
                        item = this.commonBehavior.getItem(uuid, true, "");
                    }
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            } else {
                //System.out.println("初始化的时候redis是异常的");
                // redis降级
                item = this.commonBehavior.getItem(uuid, true, "");
                if (isIdiom) {
                    item.setrPointAry(rPoint);
                }
                randomStr = "";
            }
            SysLog.println("666:" + item);
            JSONArray jsonAry = new JSONArray();
            JSONObject jsonObject = new JSONObject();
            for (int i = 0; i < rPoint.size(); i++) {
                JSONObject job = new JSONObject();
                LatticeSegmentationBean rPointObj = rPoint.get(i);
                job.put("isCheck", rPointObj.getM_isMark());
                jsonAry.add(job);
            }
            jsonObject.put("keys", randomStr);
            jsonObject.put("pointArray", jsonAry);
            jsonObject.put("picSort", sliceNum);
            if (crypto_kind == 2 && keyPairGenerator != null) {
                jsonObject.put("sr",item.getSr());
                jsonObject.put("publicKeyModulus", keyPairGenerator.getKeyPairInfo().getPublicModule());
                jsonObject.put("publicKeyExponent", keyPairGenerator.getKeyPairInfo().getPublicExponen());
            }
            params = JSONObject.toJSONString(jsonObject);
            SysLog.println("getClickSelectParams:" + params);
            params = this.encryptBehavior.WYJetStr(uuid, params,crypto_kind);
            retMap = new HashMap<String,Object>();
            retMap.put("getClickSelectParamsStr", params);
            retMap.put("getClickSelectParamsItem", item);
//			retMap.put("getClickSelectParamsItemJsonStr",getSlideParamsItemJsonStr(uuid, item));

        }catch (Exception e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--getClickSelectParams--error==" + e.toString());
            return null;
        }

        return retMap;
    }

    // 以上方法调用
    public byte[] getClickSelectFontImage(RandomItem item, int width, int height, int fontSize) {

        Font g_ft = this.commonBehavior.getFont();

        byte[] bt = null;
        try {
            if (item == null) {
                SysLog.println("Captcha--getClickSelectFontImage--item==null");
                return bt;
            }
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.append("【");
            ArrayList<LatticeSegmentationBean> rPoint = item.getrPointAry();
            int j = 0;
            for (int i = 0; i < rPoint.size(); i++) {
                LatticeSegmentationBean lsBean = rPoint.get(i);
                if (lsBean.getM_isMark() == 1) {
                    if (j > 0) {
                        strBuilder.append(",");
                    }
                    strBuilder.append(lsBean.getM_txt());
                    j++;
                }
            }
            strBuilder.append("】");

            BufferedImage oriBuf = new BufferedImage(width, height,
                    BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = oriBuf.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setColor(Color.black);
            // g.setFont(new Font("宋体", Font.BOLD | Font.ITALIC, fontSize));
            if (g_ft == null) {
                g.setFont(new Font("宋体", Font.ITALIC, fontSize));
            } else {
                g.setFont(g_ft.deriveFont(Font.ITALIC, fontSize));
            }
            g.drawString(strBuilder.toString(), 0, height - 5);
            g.dispose();

            ByteArrayOutputStream os = new ByteArrayOutputStream();// 新建流。
            try {
                // 利用ImageIO类提供的write方法，将by以png图片的数据模式写入流。
                ImageIO.write(oriBuf, "png", os);
                bt = os.toByteArray();// 从流中获取数据数组。
                os.close();
            } catch (IOException e) {
                SysLog.println(e.toString());
                SysLog.println("Captcha--getClickSelectFontImage--ImageIO.write--error==" + e.toString());
                return bt;
            }
        } catch (Exception e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--getClickSelectFontImage--error==" + e.toString());
        }
        return bt;
    }
    // 以上方法调用
    private int randomChangeValue(int a) {
        int x = a;
        SecureRandom sRandom = null;
        try {
            sRandom = SecureRandom.getInstance("SHA1PRNG");
        } catch (NoSuchAlgorithmException e) {
            SysLog.println(e.toString());
            SysLog.println("Captcha--randomChangeValue--error==" + e.toString());
        }
        if(sRandom == null){
            return x;
        }
        do {
            // Random random = new Random();
            int r = sRandom.nextInt(10);
            if (r % 2 == 0) {
                x = a + r;
            } else {
                x = a - r;
            }

        } while (x < 0);
        return x;
    }

    /*
     * 获取滑块验证所需的参数，并返回一个包含参数信息的 HashMap。
     * */
    //暂时未用到
    public HashMap<String,Object> getSlideParams(String uuid, int width, int height) {
        String params = "";
        ImageUtils imUtils = new ImageUtils();
        int blockW = this.commonBehavior.getBlockW();
        int blockH = this.commonBehavior.getBlockH();
        int slice_x = this.commonBehavior.getSliceX();
        int slice_y = this.commonBehavior.getSliceY();
        int slice_type = this.commonBehavior.getSliceType();
        int[] sliceNum = this.commonBehavior.getSliceNum();
        boolean isRedisAvail = this.commonBehavior.getIsRedisAvail();
        int crypto_kind = this.commonBehavior.getEncrypt();

        if (blockW == 0 || blockH == 0) {
            blockW = 60;
            blockH = 60;
        }
        int[] ri = imUtils.randomPoint(width, height, blockW, blockH);
        ri[0] += blockW / 2;
        ri[1] += blockH / 2;
//        SysLog.println("ri[0]" + ri[0]);
//        SysLog.println("ri[1]" + ri[1]);

        PhotoCutting pct = new PhotoCutting();
        if(slice_x == 1 && slice_y == 1){
            if(slice_type == 1){
                slice_x = 1;
                slice_y = 3;
            } else if(slice_type == 2){
                slice_x = 1;
                slice_y = 5;
            } else if(slice_type == 3){
                slice_x = 1;
                slice_y = 10;
            } else if(slice_type == 4){
                slice_x = 1;
                slice_y = 20;
            } else if(slice_type == 5){
                slice_x = 1;
                slice_y = 50;
            } else{
                slice_x = 1;
                slice_y = 1;
            }
        }
        sliceNum = pct.shuffleArray(slice_x * slice_y);

        RandomItem item = null;
        JSONObject obj = new JSONObject();
        String randomStr = "";

        if(isRedisAvail) {
            try {
                item = this.commonBehavior.setRandomCode(uuid, ri, null, width, height, blockW, blockH, 0, 0, 0);
                randomStr = item == null ? "":item.getRandomStr();
                if(item == null){
                    // redis降级
                    item = this.commonBehavior.getItem(uuid, false, "");
                    obj.put("pointY", item.getrPoint()[1]);
                }else {
                    obj.put("pointY", ri[1]);
                }
            } catch (Exception e) {
                SysLog.println(e.toString());
                SysLog.println("Captcha--getSlideParams--setRandomCode--error==" + e.toString());
            }
        } else {
            //System.out.println("初始化的时候redis是异常的");
            // redis降级
            item = this.commonBehavior.getItem(uuid, false, "");
            obj.put("pointY", item.getrPoint()[1]);
            randomStr = "";
        }

		/*String randomStr = "";
		RandomItem item = null;
		try {
			item =c_manager.setRandomCode4Item(uuid, ri, width, height,
					blockW, blockH, gp);
			randomStr = item == null ? "":item.getRandomStr();
		} catch (Exception e) {
			SysLog.println(e.toString());
		}*/

        obj.put("keys", randomStr);
        obj.put("picSort", sliceNum);
        params = JSONObject.toJSONString(obj);
        SysLog.println("getSlideParams:" + params);
        params = this.encryptBehavior.WYJetStr(uuid, params,crypto_kind);
        HashMap<String,Object> retMap = new HashMap<String,Object>();
        retMap.put("getSlideParamsStr", params);
        retMap.put("getSlideParamsItem", item);
//		retMap.put("getSlideParamsItemJsonStr", getSlideParamsItemJsonStr(uuid, item));
        return retMap;
    }
    //暂时未用到
    public JSONObject getClickSelectImg(int type, String uuid, int bgwidth, int bgheight,
                                        int countPoint, int checkPoint, int bgfontSize, InputStream iStream,int width, int height,
                                        int fontSize){
        JSONObject jsonObject = null;
        if(type == 1){
            // 普通效果
            try {
                jsonObject = getClickSelectImg(uuid, bgwidth, bgheight, countPoint, checkPoint, bgfontSize, iStream, width, height, fontSize);
            } catch (BehaviorFailException e) {
                SysLog.println(e.toString());
                return null;
            }
        }
        if(type == 2){
            // 切片效果
            try {
                jsonObject = getClickSelectImgCanvas(uuid, bgwidth, bgheight, countPoint, checkPoint, bgfontSize, iStream, width, height, fontSize);
            } catch (BehaviorFailException e) {
                SysLog.println(e.toString());
                return null;
            }
        }
        if(type == 3){
            // 成语验证码
            try {
                jsonObject = getClickSelectIdiom(1, uuid, bgwidth, bgheight, bgfontSize, iStream, fontSize);
            } catch (BehaviorFailException e) {
                SysLog.println(e.toString());
            }
        }
        if(type == 4){
            // 成语验证码，切片效果
            try {
                jsonObject = getClickSelectIdiom(2, uuid, bgwidth, bgheight, bgfontSize, iStream, fontSize);
            } catch (BehaviorFailException e) {
                SysLog.println(e.toString());
            }
        }
        return jsonObject;
    }
}
