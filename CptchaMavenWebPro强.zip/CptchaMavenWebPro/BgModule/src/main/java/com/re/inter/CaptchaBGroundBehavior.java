package com.re.inter;


import com.re.domain.CommonDomain;

public interface CaptchaBGroundBehavior {

    int getColorR(); // 背景

    int getColorG(); // 背景

    int getColorB(); // 背景

    boolean getRandomColor(); // 背景

    boolean getFontSizeChange(); // 背景

    int getColorRange();// 背景

}
