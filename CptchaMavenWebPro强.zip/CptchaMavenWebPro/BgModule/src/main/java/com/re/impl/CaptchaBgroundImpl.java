package com.re.impl;

import com.re.domain.CommonDomain;
import com.re.inter.CaptchaBGroundBehavior;

public class CaptchaBgroundImpl implements CaptchaBGroundBehavior {

    private int colorRange = 80;
    private boolean fontSizeChange = false;
    private int colorR = -1;
    private int colorG = -1;
    private int colorB = -1;
    private boolean isRandomColor = false;

    @Override
    public int getColorR() {
        return this.colorR;
    }

    @Override
    public int getColorG() {
        return this.colorG;
    }

    @Override
    public int getColorB() {
        return this.colorB;
    }

    @Override
    public boolean getRandomColor() {
        return isRandomColor;
    }

    @Override
    public boolean getFontSizeChange() {
        return fontSizeChange;
    }

    @Override
    public int getColorRange() {
        return colorRange;
    }


    //报错，修改
    public void setFontSizeChange(boolean b) {
        this.fontSizeChange = b;
    }

    public void setColorRange(int c) {
        this.colorRange = c;
    }

    public void setRandomColor(boolean randomColor) {
        this.isRandomColor = randomColor;
    }

    public void setColorR(int colorR) {
        this.colorR = colorR;
    }

    public void setColorG(int colorG) {
        this.colorG = colorG;
    }

    public void setColorB(int colorB) {
        this.colorB = colorB;
    }
}
