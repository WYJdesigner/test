package com.re.domain;

import cn.com.icbc.ms.behavior.base.RandomItem;
import java.io.InputStream;
import com.re.CommonEnum;

public class CommonDomain {
    private CommonEnum operation;
    private RandomItem item;
    private InputStream iStream;
    private String filePath;
    private int width;
    private int height;

    private int type;
    private int bgwidth;
    private int bgheight;
    private int countPoint;
    private int checkPoint;
    private int bgfontSize;
    private int fontSize;
    private String uuid;

    private CommonDomain(){}
    public CommonDomain(CommonEnum operation){
        this.operation = operation;
    }
    public CommonEnum getOperation() {
        return operation;
    }

    public void setItem(RandomItem item) {
        this.item = item;
    }
    public RandomItem getItem() {
        return item;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
    public String getFilePath() {
        return filePath;
    }

    public int getType() {
        return type;
    }
    public void setType(int type) {
        this.type = type;
    }

    public int getBgwidth() {
        return bgwidth;
    }
    public void setBgwidth(int bgwidth) {
        this.bgwidth = bgwidth;
    }

    public int getBgheight() {
        return bgheight;
    }
    public void setBgheight(int bgheight) {
        this.bgheight = bgheight;
    }

    public int getCountPoint() {
        return countPoint;
    }
    public void setCountPoint(int countPoint) {
        this.countPoint = countPoint;
    }

    public int getCheckPoint() {
        return checkPoint;
    }
    public void setCheckPoint(int checkPoint) {
        this.checkPoint = checkPoint;
    }

    public int getBgfontSize() {
        return bgfontSize;
    }
    public void setBgfontSize(int bgfontSize) {
        this.bgfontSize = bgfontSize;
    }

    public int getWidth() {
        return width;
    }
    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }
    public void setHeight(int height) {
        this.height = height;
    }

    public int getFontSize() {
        return fontSize;
    }
    public void setFontSize(int fontSize) {
        this.fontSize = fontSize;
    }

    public InputStream getiStream() {
        return iStream;
    }
    public void setiStream(InputStream iStream) {
        this.iStream = iStream;
    }

    public String getUuid() {
        return uuid;
    }
    public void setUuid(String uuid) {
        this.uuid = uuid;
    }
}
