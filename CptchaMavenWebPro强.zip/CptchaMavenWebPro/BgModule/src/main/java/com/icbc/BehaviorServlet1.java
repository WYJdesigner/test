package com.icbc;

import java.awt.Font;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.HashMap;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.com.icbc.ms.behavior.base.RandomItem;
import cn.com.icbc.ms.behavior.component.CaptchaCommonBehaviorRNUtils;
import cn.com.icbc.ms.behavior.exception.BehaviorFailException;
import cn.com.icbc.ms.behavior.utils.*;

import com.alibaba.fastjson.JSONObject;
import cn.com.icbc.ms.behavior.base.bean.KeyPairInfo;
import cn.com.icbc.ms.behavior.component.KeyPairGenerator;
import com.alibaba.fastjson.JSON;
import com.re.domain.CommonDomain;
import com.re.CommonEnum;
import com.re.domain.VerifyDomain;

import java.util.Base64;
/**
 * Servlet implementation class BehaviorServlet
 */
// @WebServlet("/BehaviorServlet")
public class BehaviorServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String uuid1 = "aaaaaa";
	private String uuid2 = "bbbbbb";
	private Font localFont;
	private KeyPairGenerator keyPairGenerator;
	public BehaviorServlet1(){
		localFont = initOneFont("/Users/yjwei/Downloads/simsun.ttc");
	}
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		super.destroy();
	}

	public void initJKSKeyPair()  {
		String keyStoreFile = "/Users/yjwei/test.jks";
		String storeFilePass = "123456";
		String keyAlias = "test";
		String keyAliasPass = "123456";
		RSAPublicKey publicKey = (RSAPublicKey) JKSUtil.getPublicKey(keyStoreFile, storeFilePass, keyAlias);
		if (publicKey != null) {
			//SysLog.println("Public Key success");
		} else {
			SysLog.println("Failed to read public key.");
		}
		RSAPrivateKey privateKey = (RSAPrivateKey)JKSUtil.getPrivateKey(keyStoreFile, storeFilePass, keyAlias, keyAliasPass);
		if (privateKey != null) {
			//SysLog.println("Private Key success");
		} else {
			SysLog.println("Failed to read private key.");
		}
		String pubM = publicKey.getModulus().toString(10);
		String pubE = publicKey.getPublicExponent().toString(10);
		String priM = privateKey.getModulus().toString(10);
		String priE = privateKey.getPrivateExponent().toString(10);
		pubM = HexStringUtil.convertToHexadecimal(pubM);
		pubE = HexStringUtil.convertToHexadecimal(pubE);
		priM = HexStringUtil.convertToHexadecimal(priM);
		priE = HexStringUtil.convertToHexadecimal(priE);
		KeyPairInfo keyPairInfo = new KeyPairInfo();
		keyPairInfo.setAlgorithm("RSA");
		keyPairInfo.setPublicModule(pubM);
		keyPairInfo.setPublicExponen(pubE);
		keyPairInfo.setPrivateModule(priM);
		keyPairInfo.setPrivateExponent(priE);
		keyPairGenerator = KeyPairGenerator.createKeyPairGenerator(keyPairInfo);
		SysLog.println("Servlet设置的：" + keyPairGenerator);
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings("deprecation")
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		uuid1 = "6af4365b-8944-4805-a889-541da00e432e";
		uuid2 = "897e267a-ca8f-46cc-96ad-a2b9230c2291";
		SysLog.logCon(0);
		// 相对路径地址ַ
		String contextPath = request.getSession().getServletContext()
				.getRealPath("/")
				+ "/";
		// 图片服务器地址
		String urlPath = request.getScheme() + "://" + request.getServerName()
				+ ":" + request.getServerPort() + request.getContextPath()
				+ "/";

		String params = request.getParameter("param");
		SysLog.println("get请求param:" + params);
		JSONObject jsonObject = JSONObject.parseObject(params);
		if (jsonObject == null) {
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write("params_error");
			return;
		}
		CaptchaCommonBehaviorRNUtils utils = new CaptchaCommonBehaviorRNUtils(DataBase.getInstans(),false);
		initJKSKeyPair();
		utils.setKeyPairParams(keyPairGenerator);
		utils.setEncrypt(0);
//		utils.setSliceType(4);
		// 验证码类型
		params = jsonObject.getString("captchaType");
//		String filePath = "D://Temp//image";
		String filePath = "/Users/yjwei/Downloads/image";
		FileInputStream fis = new FileInputStream(contextPath + "demo.jpeg");
		// FileInputStream fis2 = new FileInputStream(contextPath + "demo.jpeg");

		if(params != null &&params.equals("get_uuid")){
			String uuid= UUID.randomUUID().toString().replace("-", "");
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(uuid);
		}
		else if(params != null && params.equals("slice_data_o")){
			SysLog.println("false true slice_data_o-下发滑动验证码参数");
			// 滑动验证码参数
			int blockW = jsonObject.getIntValue("sliceW");
			int blockH = jsonObject.getIntValue("sliceH");
			// utils.setEncrypt(1); //设置加密类型
			utils.setBlockSize(blockW, blockH);
			int width = jsonObject.getIntValue("width");
			int height = jsonObject.getIntValue("height");

			// 改造
			CommonDomain commonDomain = new CommonDomain(CommonEnum.Slice_Data_O_Type);
			commonDomain.setUuid(uuid1);
			commonDomain.setWidth(width);
			commonDomain.setHeight(height);
			commonDomain.setFilePath(filePath);
			JSONObject obj = new JSONObject();
			try {
				obj = utils.fetchCaptchaData(commonDomain);
			} catch (BehaviorFailException e) {
				e.printStackTrace();
			}
			String jsonStr = JSONObject.toJSONString(obj);
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(jsonStr);
			// 改造

//			HashMap<String,Object> retMap = utils.getSlideParams(uuid1, width, height, filePath);
//			String str = retMap.get("getSlideParamsStr") == null?"":String.valueOf(retMap.get("getSlideParamsStr"));
//			SysLog.println("str:" + str);
//			JSONObject obj2 = new JSONObject();
//			obj2.put("data", str);
//			String jsonStr = JSONObject.toJSONString(obj2);
//			response.setHeader("Content-type", "text/html;charset=UTF-8");
//			response.setCharacterEncoding("UTF-8");
//			response.getWriter().write(jsonStr);
		}
		else if(params != null && params.equals("slice_bgimage_o")){
//			//滑动验证码背景图片旧方法,主要用于兼容IE8版本
//			byte[] bts = utils.getSlideBackgroundStream(uuid1, filePath);

			//改造
			CommonDomain commonDomain = new CommonDomain(CommonEnum.Slice_Bgimage_O_Type);
			commonDomain.setUuid(uuid1);
			commonDomain.setFilePath(filePath);
			JSONObject obj = new JSONObject();
			try {
				obj = utils.fetchCaptchaData(commonDomain);
			} catch (BehaviorFailException e) {
				e.printStackTrace();
			}
			byte[] bts = null;
			if (obj != null ) {
				String base64Encoded = jsonObject.getString("data");
				bts = Base64.getDecoder().decode(base64Encoded);
			}
			//改造

			if(bts == null){
				response.setHeader("Content-type", "text/html;charset=UTF-8");
				response.getWriter().write("params_error");
				return;
			}else {
				response.setContentType("image/png");
				OutputStream out = response.getOutputStream();
				out.write(bts);
				out.flush();
				out.close();
				fis.close();
			}

		}
		else if(params != null && params.equals("slice_sliceimage_o")){
//			//滑动验证码抠块图片旧方法,主要用于兼容IE8版本
//			byte[] bts = utils.getSlideBlockImageStream(uuid1, filePath);
//			if(bts == null){
//				response.setHeader("Content-type", "text/html;charset=UTF-8");
//				response.getWriter().write("params_error");
//				return;
//			}else {
//				response.setContentType("image/png");
//				OutputStream out = response.getOutputStream();
//				out.write(bts);
//				out.flush();
//				out.close();
//				fis.close();
//			}
			//改造
			CommonDomain commonDomain = new CommonDomain(CommonEnum.Slice_Sliceimage_O_Type);
			commonDomain.setUuid(uuid1);
			commonDomain.setFilePath(filePath);
			JSONObject obj = new JSONObject();
			try {
				obj = utils.fetchCaptchaData(commonDomain);
			} catch (BehaviorFailException e) {
				e.printStackTrace();
			}
			//改造
		}
		else if (params != null && params.equals("slice_data")) {
			SysLog.println("false false slice_data-下发滑动验证码参数");
			// 滑动验证码参数
			int blockW = jsonObject.getIntValue("sliceW");
			int blockH = jsonObject.getIntValue("sliceH");
			// utils.setEncrypt(1); //设置加密类型
			utils.setBlockSize(blockW, blockH);
			int width = jsonObject.getIntValue("width");
			int height = jsonObject.getIntValue("height");

			// 改造
			CommonDomain commonDomain = new CommonDomain(CommonEnum.Slice_Data_Type);
			commonDomain.setUuid(uuid1);
			commonDomain.setWidth(width);
			commonDomain.setHeight(height);
			commonDomain.setFilePath(filePath);
			JSONObject obj = new JSONObject();
			try {
				obj = utils.fetchCaptchaData(commonDomain);
			} catch (BehaviorFailException e) {
				e.printStackTrace();
			}
			String jsonStr = JSONObject.toJSONString(obj);
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(jsonStr);
			// 改造

//			HashMap<String,Object> retMap = utils.getSlideParams(uuid1, width, height, filePath);
//			String str = retMap.get("getSlideParamsStr") == null?"":String.valueOf(retMap.get("getSlideParamsStr"));
//			SysLog.println("str:" + str);
//			RandomItem item =  (RandomItem) (retMap.get("getSlideParamsItem") == null?null:retMap.get("getSlideParamsItem"));
//			JSONObject obj2 = new JSONObject();
//			//背景图片
//			byte[] bgbts = utils.getSlideBackgroundStream(item, filePath);
//			if (bgbts == null) {
//				response.setHeader("Content-type", "text/html;charset=UTF-8");
//				response.setCharacterEncoding("UTF-8");
//				response.getWriter().write("params_error");
//				return;
//			}
//			String bgbase64bts=EncodeUtils.encode2Base64(bgbts);
//			//抠图
//			byte[] slicebts = utils.getSlideBlockImageStream(item, filePath);
//				if (slicebts == null) {
//				response.setHeader("Content-type", "text/html;charset=UTF-8");
//				response.setCharacterEncoding("UTF-8");
//				response.getWriter().write("params_error");
//				return;
//			}
//			String slicebase64bts=EncodeUtils.encode2Base64(slicebts);
//			obj2.put("data", str);
//			obj2.put("bgimg", bgbase64bts);
//			obj2.put("sliceimg", slicebase64bts);
//			String jsonStr = JSONObject.toJSONString(obj2);
//			response.setHeader("Content-type", "text/html;charset=UTF-8");
//			response.setCharacterEncoding("UTF-8");
//			response.getWriter().write(jsonStr);
		}  
		else if (params != null && params.equals("point_data")) {
			SysLog.println("false 不判断 point_data下发数据");
			// 图文点选验证码参数
			int width = jsonObject.getIntValue("width");
			int height = jsonObject.getIntValue("height");
			System.out.println("width:"+width+"height:"+height);
			String uuidtemp =  jsonObject.getString("uuid");
			if(StringUtils.isEmpty(uuidtemp)){
				uuidtemp = uuid2;
			}
			JSONObject obj2 = new JSONObject();
			//背景图片
			//设置展示字颜色为随机
			utils.setRandomColor(false);
			utils.setColorR(0);
			utils.setColorB(0);
			utils.setColorG(0);
			utils.setFont(localFont);
			//设置展示字颜色为固定值
//			utils.setRandomColor(false);
//			utils.setColorR(169);
//			utils.setColorB(169);
//			utils.setColorG(169);

			// 改造
			CommonDomain commonDomain = new CommonDomain(CommonEnum.Point_Data_Type);
			commonDomain.setUuid(uuidtemp);
			commonDomain.setBgwidth(width);
			commonDomain.setBgheight(height);
			commonDomain.setCountPoint(4);
			commonDomain.setCheckPoint(2);
			commonDomain.setBgfontSize(30);
			commonDomain.setiStream(fis);
			commonDomain.setWidth(100);
			commonDomain.setHeight(30);
			commonDomain.setFontSize(16);
			JSONObject obj = new JSONObject();
			try {
				obj = utils.fetchCaptchaData(commonDomain);
			} catch (BehaviorFailException e) {
				e.printStackTrace();
			}
			String jsonStr = JSONObject.toJSONString(obj);
			//System.out.println("point_canvas:" + jsonStr);
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(jsonStr);
			// 改造

//			try {
//				obj2 = utils.getClickSelectImg(uuidtemp, width, height, 4, 2,
//						30, fis, 100, 30, 16);
//			} catch (BehaviorFailException e) {
//				response.setHeader("Content-type", "text/html;charset=UTF-8");
//				response.setCharacterEncoding("UTF-8");
//				response.getWriter().write("params_error");
//				return;
//			}
//			//-1 是背景图生成失败 -2 提示文字图生成失败 成功生产返回是0
//			if (!"0".equals(obj2.getString("retFlag"))) {
//				response.setHeader("Content-type", "text/html;charset=UTF-8");
//				response.setCharacterEncoding("UTF-8");
//				response.getWriter().write("params_error");
//				return;
//			}
//			String jsonStr = JSONObject.toJSONString(obj2);
//			//System.out.println("point_data:" + jsonStr);
//			response.setHeader("Content-type", "text/html;charset=UTF-8");
//			response.setCharacterEncoding("UTF-8");
//			response.getWriter().write(jsonStr);
		}
		else if (params != null && params.equals("slice_canvas")) {
			SysLog.println("true no slice_canvas-下发滑动验证码参数");
			// 滑动验证码参数
			int blockW = jsonObject.getIntValue("sliceW");
			int blockH = jsonObject.getIntValue("sliceH");
			utils.setBlockSize(blockW, blockH);
			int width = jsonObject.getIntValue("width");
			int height = jsonObject.getIntValue("height");

			// 改造
			CommonDomain commonDomain = new CommonDomain(CommonEnum.Slice_Canvas_Type);
			commonDomain.setUuid(uuid1);
			commonDomain.setWidth(width);
			commonDomain.setHeight(height);
			commonDomain.setFilePath(filePath);
			JSONObject obj = new JSONObject();
			try {
				obj = utils.fetchCaptchaData(commonDomain);
			} catch (BehaviorFailException e) {
				e.printStackTrace();
			}
			String jsonStr = JSONObject.toJSONString(obj);
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(jsonStr);
			// 改造

//			HashMap<String,Object> retMap = utils.getSlideParams(uuid1, width, height, filePath);
//			String str = retMap.get("getSlideParamsStr") == null?"":String.valueOf(retMap.get("getSlideParamsStr"));
//			System.out.println("str:" + str);
//			RandomItem item =  (RandomItem) (retMap.get("getSlideParamsItem") == null?null:retMap.get("getSlideParamsItem"));
//			SysLog.println("item：" + JSON.toJSONString(item));
//			JSONObject obj2 = new JSONObject();
//			//背景图片
//			byte[] bgbts = utils.getSlideBackgroundCanvas(item, filePath);
//			if (bgbts == null) {
//				response.setHeader("Content-type", "text/html;charset=UTF-8");
//				response.setCharacterEncoding("UTF-8");
//				response.getWriter().write("params_error");
//				return;
//			}
//			String bgbase64bts=EncodeUtils.encode2Base64(bgbts);
//			//抠图
//			byte[] slicebts = utils.getSlideBlockImageStream(item, filePath);
//				if (slicebts == null) {
//				response.setHeader("Content-type", "text/html;charset=UTF-8");
//				response.setCharacterEncoding("UTF-8");
//				response.getWriter().write("params_error");
//				return;
//			}
//			String slicebase64bts=EncodeUtils.encode2Base64(slicebts);
//			obj2.put("data", str);
//			obj2.put("bgimg", bgbase64bts);
//			obj2.put("sliceimg", slicebase64bts);
//			String jsonStr = JSONObject.toJSONString(obj2);
//			response.setHeader("Content-type", "text/html;charset=UTF-8");
//			response.setCharacterEncoding("UTF-8");
//			response.getWriter().write(jsonStr);
		}
	    else if (params != null && params.equals("point_canvas")) {
			// 图文点选验证码参数
			SysLog.println("true 不判断 point_canvas--下发数据");
			int width = jsonObject.getIntValue("width");
			int height = jsonObject.getIntValue("height");
			System.out.println("width:"+width+"height:"+height);
			String uuidtemp =  jsonObject.getString("uuid");
			if(StringUtils.isEmpty(uuidtemp)){
				uuidtemp = uuid2;
			}
			JSONObject obj2 = new JSONObject();
			//背景图片
			//设置展示字颜色为随机
			utils.setRandomColor(false);
			utils.setColorR(0);
			utils.setColorB(0);
			utils.setColorG(0);
			utils.setFont(localFont);

			// 改造
			CommonDomain commonDomain = new CommonDomain(CommonEnum.Point_Canvas_Type);
			commonDomain.setUuid(uuidtemp);
			commonDomain.setBgwidth(width);
			commonDomain.setBgheight(height);
			commonDomain.setCountPoint(4);
			commonDomain.setCheckPoint(2);
			commonDomain.setBgfontSize(30);
			commonDomain.setiStream(fis);
			commonDomain.setWidth(100);
			commonDomain.setHeight(30);
			commonDomain.setFontSize(16);
			JSONObject obj = new JSONObject();
			try {
				obj = utils.fetchCaptchaData(commonDomain);
			} catch (BehaviorFailException e) {
				e.printStackTrace();
			}
			String jsonStr = JSONObject.toJSONString(obj);
			System.out.println("point_canvas:" + jsonStr);
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(jsonStr);
			// 改造

//			try {
//				obj2 = utils.getClickSelectImgCanvas(uuidtemp, width, height, 4, 2,
//						30, fis, 100, 30, 16);
//			} catch (BehaviorFailException e) {
//				response.setHeader("Content-type", "text/html;charset=UTF-8");
//				response.setCharacterEncoding("UTF-8");
//				response.getWriter().write("params_error");
//				return;
//			}
//			//-1 是背景图生成失败 -2 提示文字图生成失败 成功生产返回是0
//			if (!"0".equals(obj2.getString("retFlag"))) {
//				response.setHeader("Content-type", "text/html;charset=UTF-8");
//				response.setCharacterEncoding("UTF-8");
//				response.getWriter().write("params_error");
//				return;
//			}
//			String jsonStr = JSONObject.toJSONString(obj2);
//			 //System.out.println("point_canvas:" + jsonStr);
//			response.setHeader("Content-type", "text/html;charset=UTF-8");
//			response.setCharacterEncoding("UTF-8");
//			response.getWriter().write(jsonStr);
		}
	    else if (params != null && params.equals("point_idiom")) {
			SysLog.println("true 不判断 point_idiom--下发数据");
			// 图文点选验证码参数
			int width = jsonObject.getIntValue("width");
			int height = jsonObject.getIntValue("height");
			System.out.println("width:"+width+"height:"+height);
			String uuidtemp =  jsonObject.getString("uuid");
			if(StringUtils.isEmpty(uuidtemp)){
				uuidtemp = uuid2;
			}
			JSONObject obj2 = new JSONObject();
			//背景图片
			//设置展示字颜色为随机
			utils.setRandomColor(false);
			utils.setColorR(0);
			utils.setColorB(0);
			utils.setColorG(0);
			utils.setFont(localFont);

			// 改造
			CommonDomain commonDomain = new CommonDomain(CommonEnum.Point_Idiom_Type);
			commonDomain.setType(2);
			commonDomain.setUuid(uuidtemp);
			commonDomain.setBgwidth(width);
			commonDomain.setBgheight(height);
			commonDomain.setBgfontSize(30);
			commonDomain.setiStream(fis);
			commonDomain.setFontSize(16);
			JSONObject obj = new JSONObject();
			try {
				obj = utils.fetchCaptchaData(commonDomain);
			} catch (BehaviorFailException e) {
				e.printStackTrace();
			}
			String jsonStr = JSONObject.toJSONString(obj);
			System.out.println("point_canvas:" + jsonStr);
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(jsonStr);
			// 改造

//			try {
//				obj2 = utils.getClickSelectIdiom(2, uuidtemp, width, height, 30, fis, 16);
//			} catch (BehaviorFailException e) {
//				response.setHeader("Content-type", "text/html;charset=UTF-8");
//				response.setCharacterEncoding("UTF-8");
//				response.getWriter().write("params_error");
//				return;
//			}
//			//-1 是背景图生成失败 -2 提示文字图生成失败 成功生产返回是0
//			if (!"0".equals(obj2.getString("retFlag"))) {
//				response.setHeader("Content-type", "text/html;charset=UTF-8");
//				response.setCharacterEncoding("UTF-8");
//				response.getWriter().write("params_error");
//				return;
//			}
//			String jsonStr = JSONObject.toJSONString(obj2);
////			 System.out.println("point_canvas:" + jsonStr);
//			response.setHeader("Content-type", "text/html;charset=UTF-8");
//			response.setCharacterEncoding("UTF-8");
//			response.getWriter().write(jsonStr);
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		SysLog.println("------>post");

		String ip = request.getRemoteAddr();
		ip = ip.replace(".", "");
		SysLog.logCon(0);
		CaptchaCommonBehaviorRNUtils utils = new CaptchaCommonBehaviorRNUtils(DataBase.getInstans(), false);
		initJKSKeyPair();
		utils.setKeyPairParams(keyPairGenerator);
		utils.setEncrypt(0);
		String data = request.getParameter("Data");
		if (data == null) {
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write("params_error");
			return;
		}

		String[] strs = data.split("\\|\\|");
		String type = strs[1];
		data = strs[0];
		if (StringUtils.isEmpty(type)) {
			utils = null;
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write("params_error");
			return;
		} else if(type.equals("get_uuid")){
			String uuid= UUID.randomUUID().toString().replace("-", "");
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(uuid);
			System.out.println("11111");
		}else if (type.equals("slice_check")) {

			// 改造
			VerifyDomain verifyDomain = new VerifyDomain(CommonEnum.Slice_Check_Type);
			verifyDomain.setUuid(uuid1);
			verifyDomain.setData(data);
			String str = utils.verifyCaptchaData(verifyDomain);
			// 改造

//			utils.setEncrypt(1);
//            String str = utils.verifySlideData(uuid1, data);
			utils = null;
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(str);
			return;
		} else if (type.equals("point_check")) {
			SysLog.println("point_check");
			utils.setRangeValue(25);
			//System.out.println("...>"+data);

			// 改造
			VerifyDomain verifyDomain = new VerifyDomain(CommonEnum.Point_Check_Type);
			verifyDomain.setUuid(uuid2);
			verifyDomain.setData(data);
			String str = utils.verifyCaptchaData(verifyDomain);
			// 改造

//			String str = utils.verifyClickSelect(uuid2, data);
			if("ERROR_990".equals(str)){
				str = "ERROR_990"+"@@"+uuid2+"@@"+data+"@@";
			}
			
			System.out.println("pint_check = " + str);
			utils = null;
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(str);
			System.out.println("33333");
			return;
		} else {
			utils = null;
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write("type_error");
			System.out.println("44444");
			return;
		}
	}
	
	protected static Font initOneFont(String path)
	  {
	    BufferedInputStream fb = null;
	    try {
//	      String testpath = new Object()
//	      .getClass().getResource(path).getPath();
	      File fontfile = new File(path);
	      if (!fontfile.exists()) {
	    	  System.out.println(new StringBuilder().append("字体初始化失败，找不到字体文件filepath=").append(path).toString());
	      }
	      fb = new BufferedInputStream(new FileInputStream(fontfile));
	      Font nf = Font.createFont(0, fb);
	      if (path.indexOf("ALGER.TTF") != -1)
	        nf = nf.deriveFont(2, 36.0F);
	      else {
	        nf = nf.deriveFont(1, 33.0F);
	      }
	      System.out.println(new StringBuilder().append("初始化字体：").append(nf.getFontName()).append(",").append(nf.getSize()).toString());
	      Font localFont1 = nf;
	      return localFont1;
	    } catch (Exception e) {
	    	 System.out.println(new StringBuilder().append("字体初始化失败, filepath=").append(path).toString());
	    	 SysLog.println(e.toString());
	    } finally {
	      try {
	        if (fb != null)
	          fb.close();
	      }
	      catch (Exception e) {
	    	  System.out.println("关闭BufferedInputStream异常");
	    	  SysLog.println(e.toString());
	      }
	    }
	    return null;
	  }
}
