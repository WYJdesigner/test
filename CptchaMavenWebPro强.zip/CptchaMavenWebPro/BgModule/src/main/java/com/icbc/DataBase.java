package com.icbc;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


import cn.com.icbc.ms.behavior.component.IMUniCerInterface;

/**
 * Created with IntelliJ IDEA. User: luke lee Date: 2021/1/13 Time: 23:50
 * Chinese Description: English description:
 */
public class DataBase implements IMUniCerInterface {

	private static DataBase dataBase = new DataBase();
	private Map<String, String> map = new HashMap<String, String>();

	private DataBase() {

	}

	public static DataBase getInstans() {
		return dataBase;
	}
	@Override
	public String IMSaveStorage(String key, String value) {
		// TODO Auto-generated method stub
		System.out.println("---->redis存");
		map.put(key, value);
		System.out.println("k = " + key);
		System.out.println("v = " + value);
		String result = SUCCESS;
		
		return result;
		//return SUCCESS;
	}

	/**
	 * 失败返回ERROR_1
	 */
	@Override
	public String IMGetStorage(String key) {
		// TODO Auto-generated method stub
		System.out.println("---->redis取");
		String value = (String)map.get(key);;
		
		
		
		if("".equals(value) || null == value){
			System.out.println("取异常：--------------");
			return ERROR_1;
		}
		System.out.println("k = " + key);
		System.out.println("v = " + value);
		return value;
	}

	@Override
	public String IMCleanStorage(String key) {
		// TODO Auto-generated method stub
		System.out.println("---->redis删");
		map.remove(key);
		return SUCCESS;
	}



}
